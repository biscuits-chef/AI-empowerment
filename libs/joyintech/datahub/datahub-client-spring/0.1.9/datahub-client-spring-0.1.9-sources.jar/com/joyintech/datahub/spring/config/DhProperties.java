package com.joyintech.datahub.spring.config;


/**
 * @author ChenHao
 * @date 11/14/25 10:14
 */
public class DhProperties {
    private Boolean enable = Boolean.TRUE;
    private String accessKey;
    private String secretKey;
    private String endpoint;
    private String bucketName;
    private String objectPath;

    /**
     * 作用：appCode + serverName 组成kafka consumer group id，标识唯一的服务实例
     */
    private String serverName;
    
    /**
     * 配置文件url 连接超时、读取超时使用此处配置
     */
    private String confUrl;
    /**
     * 配置文件密钥
     */
    private String confKey;
    private int connectTimeoutSec = 5;
    private int readTimeoutSec = 5;

    private String apiKey;
    private String appCode;

    /**
     * 临时目录
     */
    private String tempDirectory;

    /**
     * 心跳url
     */
    private String healthUrl;

    /**
     * 启动后多久开始发送心跳
     */
    private long initialDelay = 10;

    /**
     * 心跳间隔时间
     */
    private long period = 30;


    /**
     * 异常堆栈跟踪深度限制
     */
    private Integer stackTraceLimit = 5;

    private ObsUploadConf obsUploadConf;

    /**
     * 空文件通知
     */
    private String notifyIfEmpty = "N";

    public static class ObsUploadConf {
        /**
         * 并发数
         */
        private Integer taskNum = 4;
        /**
         * 分片大小
         */
        private Long partSize = 50L;
        /**
         * 是否开启分片上传进度监控
         */
        private Boolean listener = false;
        /**
         * 断点续传
         */
        private Boolean enableCheckpoint = true;

        public Integer getTaskNum() {
            return taskNum;
        }

        public void setTaskNum(Integer taskNum) {
            this.taskNum = taskNum;
        }

        public Long getPartSize() {
            return partSize;
        }

        public Long getPartSizeInBytes() {
            return partSize * 1024 * 1024;
        }

        public void setPartSize(Long partSize) {
            this.partSize = partSize;
        }

        public Boolean getListener() {
            return listener;
        }

        public void setListener(Boolean listener) {
            this.listener = listener;
        }

        public Boolean getEnableCheckpoint() {
            return enableCheckpoint;
        }

        public void setEnableCheckpoint(Boolean enableCheckpoint) {
            this.enableCheckpoint = enableCheckpoint;
        }

        @Override
        public String toString() {
            return "ObsUploadConf{" +
                    "taskNum=" + taskNum +
                    ", partSize=" + partSize +
                    ", listener=" + listener +
                    ", enableCheckpoint=" + enableCheckpoint +
                    '}';
        }
    }

    public String getNotifyIfEmpty() {
        return notifyIfEmpty;
    }

    public void setNotifyIfEmpty(String notifyIfEmpty) {
        this.notifyIfEmpty = notifyIfEmpty;
    }

    public ObsUploadConf getObsUploadConf() {
        return obsUploadConf;
    }

    public void setObsUploadConf(ObsUploadConf obsUploadConf) {
        this.obsUploadConf = obsUploadConf;
    }

    public Integer getStackTraceLimit() {
        return stackTraceLimit;
    }

    public void setStackTraceLimit(Integer stackTraceLimit) {
        this.stackTraceLimit = stackTraceLimit;
    }

    public String getTempDirectory() {
        return tempDirectory;
    }

    public int getConnectTimeoutSec() {
        return connectTimeoutSec;
    }

    public void setConnectTimeoutSec(int connectTimeoutSec) {
        this.connectTimeoutSec = connectTimeoutSec;
    }

    public int getReadTimeoutSec() {
        return readTimeoutSec;
    }

    public void setReadTimeoutSec(int readTimeoutSec) {
        this.readTimeoutSec = readTimeoutSec;
    }

    public void setTempDirectory(String tempDirectory) {
        this.tempDirectory = tempDirectory;
    }

    public String getHealthUrl() {
        return healthUrl;
    }

    public void setHealthUrl(String healthUrl) {
        this.healthUrl = healthUrl;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectPath() {
        return objectPath;
    }

    public void setObjectPath(String objectPath) {
        this.objectPath = objectPath;
    }

    public String getConfUrl() {
        return confUrl;
    }

    public String getConfKey() {
        return confKey;
    }

    public void setConfKey(String confKey) {
        this.confKey = confKey;
    }

    public void setConfUrl(String confUrl) {
        this.confUrl = confUrl;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public long getInitialDelay() {
        return initialDelay;
    }

    public void setInitialDelay(long initialDelay) {
        this.initialDelay = initialDelay;
    }

    public long getPeriod() {
        return period;
    }

    public void setPeriod(long period) {
        this.period = period;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    @Override
    public String toString() {
        return "DhProperties{" +
                "enable=" + enable +
                ", accessKey='******'" +
                ", secretKey='******'" +
                ", endpoint='" + endpoint + '\'' +
                ", bucketName='" + bucketName + '\'' +
                ", objectPath='" + objectPath + '\'' +
                ", serverName='" + serverName + '\'' +
                ", confUrl='" + confUrl + '\'' +
                ", confKey='******'" +
                ", connectTimeoutSec=" + connectTimeoutSec +
                ", readTimeoutSec=" + readTimeoutSec +
                ", apiKey='******'" +
                ", appCode='" + appCode + '\'' +
                ", tempDirectory='" + tempDirectory + '\'' +
                ", healthUrl='" + healthUrl + '\'' +
                ", initialDelay=" + initialDelay +
                ", period=" + period +
                ", stackTraceLimit=" + stackTraceLimit +
                ", obsUploadConf=" + obsUploadConf +
                ", notifyIfEmpty='" + notifyIfEmpty + '\'' +
                '}';
    }
}
