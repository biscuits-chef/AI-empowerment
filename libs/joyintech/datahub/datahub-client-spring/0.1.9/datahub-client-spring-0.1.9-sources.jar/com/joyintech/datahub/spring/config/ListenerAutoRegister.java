package com.joyintech.datahub.spring.config;

import com.joyintech.datahub.sdk.FileConsumerRecord;
import com.joyintech.datahub.sdk.InsMsgLogServerLoad;
import com.joyintech.datahub.sdk.InstMsgConsumerRecord;
import com.joyintech.datahub.sdk.InstMsgSendRecord;
import com.joyintech.datahub.subscribe.*;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.Map;

/**
 * @author ChenHao
 * @date 11/14/25 14:38
 */
public class ListenerAutoRegister implements ApplicationContextAware, InitializingBean {
    
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ListenerAutoRegister.class);

    private ApplicationContext ctx;

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("开始注册 DataHub 监听器...");
        Map<String, DhSubscribeBatchDataListener<?>> listeners = ctx.getBeansOfType(DhSubscribeBatchDataListener.class);
        if (MapUtils.isNotEmpty(listeners)) {
            log.info("发现 {} 个 DhSubscribeBatchDataListener 监听器，正在注册...【{}】", listeners.size(), listeners.keySet());
            listeners.forEach((key, listener) -> SubscribeRegister.register(listener));
        }
        Map<String, DhFileListener> dhFileListenerMap = ctx.getBeansOfType(DhFileListener.class);
        if (MapUtils.isNotEmpty(dhFileListenerMap)) {
            log.info("发现 {} 个 DhFileListener 监听器，正在注册...【{}】", dhFileListenerMap.size(), dhFileListenerMap.keySet());
            dhFileListenerMap.forEach((key, listener) -> SubscribeRegister.register(listener));
        }
        Map<String, DhInstantMsgListener<?>> dhInstantMsgListenerMap = ctx.getBeansOfType(DhInstantMsgListener.class);
        if (MapUtils.isNotEmpty(dhInstantMsgListenerMap)) {
            log.info("发现 {} 个 DhInstantMsgListener 监听器，正在注册...【{}】", dhInstantMsgListenerMap.size(), dhInstantMsgListenerMap.keySet());
            dhInstantMsgListenerMap.forEach((key, listener) -> SubscribeRegister.register(listener));
        }

        Map<String, DhAttachListener<?>> dhAttachListenerMap = ctx.getBeansOfType(DhAttachListener.class);
        if (MapUtils.isNotEmpty(dhAttachListenerMap)) {
            log.info("发现 {} 个 DhAttachListener 监听器，正在注册...【{}】", dhAttachListenerMap.size(), dhAttachListenerMap.keySet());
            dhAttachListenerMap.forEach((key, listener) -> SubscribeRegister.register(listener));
        }

        Map<String, DhSubscribeDataListener<?>> dhSubscribeDataListenerMap = ctx.getBeansOfType(DhSubscribeDataListener.class);
        if (MapUtils.isNotEmpty(dhSubscribeDataListenerMap)) {
            log.info("发现 {} 个 DhSubscribeDataListener 监听器，正在注册...【{}】", dhSubscribeDataListenerMap.size(), dhSubscribeDataListenerMap.keySet());
            dhSubscribeDataListenerMap.forEach((key, listener) -> SubscribeRegister.register(listener));
        }
        Map<String, DhBatchMapDataListener> dhBatchMapDataListenerMap =
                ctx.getBeansOfType(DhBatchMapDataListener.class);
        if (MapUtils.isNotEmpty(dhBatchMapDataListenerMap)) {
            log.info("发现 {} 个 DhBatchMapDataListener 监听器，正在注册...【{}】", dhBatchMapDataListenerMap.size(), dhSubscribeDataListenerMap.keySet());
            dhBatchMapDataListenerMap.forEach((key, listener) -> SubscribeRegister.register(listener));
        }

        Map<String, InstMsgConsumerRecord> instantMsgLogMap = ctx.getBeansOfType(InstMsgConsumerRecord.class);
        instantMsgLogMap.values().stream().findFirst()
                .ifPresent(InsMsgLogServerLoad.getInstance()::setInsMsgLog);
        Map<String, InstMsgSendRecord> instMsgSendMap = ctx.getBeansOfType(InstMsgSendRecord.class);
        instMsgSendMap.values().stream().findFirst()
                .ifPresent(InsMsgLogServerLoad.getInstance()::setInstMsgSendRecord);

        Map<String, FileConsumerRecord> fileConsumerRecordMap = ctx.getBeansOfType(FileConsumerRecord.class);
        fileConsumerRecordMap.values().stream().findFirst()
                .ifPresent(InsMsgLogServerLoad.getInstance()::setFileConsumerRecord);
        
        log.info("DataHub 监听器注册完成！");
        String logMsg = String.format(
                "\n" +
                        "================== DataHub 监听器注册完成 ==================\n" +
                        " %-35s : %d\n" +
                        " %-35s : %d\n" +
                        " %-35s : %d\n" +
                        " %-35s : %d\n" +
                        " %-35s : %d\n" +
                        "===========================================================\n",
                "DhSubscribeBatchDataListener 数量", MapUtils.size(listeners),
                "DhFileListener  数量", MapUtils.size(dhFileListenerMap),
                "DhInstantMsgListener  数量", MapUtils.size(dhInstantMsgListenerMap),
                "DhAttachListener  数量", MapUtils.size(dhAttachListenerMap),
                "DhSubscribeDataListener  数量", MapUtils.size(dhSubscribeDataListenerMap)
        );

        log.info(logMsg);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.ctx = applicationContext;
    }
    
}