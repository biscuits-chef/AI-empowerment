package com.joyintech.datahub.spring.config;

import com.joyintech.datahub.api.DataHubSdk;
import com.joyintech.datahub.model.URL;
import com.joyintech.datahub.conf.DataHubInitializer;
import com.joyintech.datahub.refresh.ConfRefreshListener;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JarVersionUtil;
import com.joyintech.datahub.util.UrlBuilder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

/**
 * @author ChenHao
 * @date 11/14/25 10:14
 */
public class DhSpringConfig implements InitializingBean, DisposableBean {

    private final DhProperties properties;

    /**
     * 自动初始化的对象
     */
    private DataHubInitializer initializer;
    private DataHubSdk sdk;

    public DhSpringConfig(DhProperties properties) {
        this.properties = properties;
        JarVersionUtil.collectVersion(DhSpringConfig.class);
    }

    /**
     * 初始化 DataHubInitializer
     */
    private DataHubInitializer createInitializer() {

        URL url = UrlBuilder.builder(properties.getHealthUrl());
        URL config = UrlBuilder.builder(properties.getConfUrl());

        ConfHolder instance = ConfHolder.getInstance();
        if (StringUtils.isNotBlank(properties.getServerName())) {
            instance.setServerName(properties.getServerName());
        }
        instance.setStackTraceLimit(properties.getStackTraceLimit());

        DhProperties.ObsUploadConf obsUploadConf = properties.getObsUploadConf();
        if (obsUploadConf == null) {
            obsUploadConf = new DhProperties.ObsUploadConf();
        }
        ConfHolder.ObsUploadConf obsUploadConf1 = new ConfHolder.ObsUploadConf();
        obsUploadConf1.setListener(obsUploadConf.getListener());
        obsUploadConf1.setPartSize(obsUploadConf.getPartSize());
        obsUploadConf1.setEnableCheckpoint(obsUploadConf.getEnableCheckpoint());
        obsUploadConf1.setTaskNum(obsUploadConf.getTaskNum());
        instance.setObsUploadConf(obsUploadConf1);
        
        String tempDirectory = properties.getTempDirectory();
        if (StringUtils.isNotEmpty(tempDirectory)) {
            ConfHolder.getInstance().setTempDirectory(tempDirectory);
        }
        int connectTimeoutSec = properties.getConnectTimeoutSec();
        ConfHolder.getInstance().setConnectTimeout(connectTimeoutSec);
        int readTimeoutSec = properties.getReadTimeoutSec();
        ConfHolder.getInstance().setReadIdleTimeout(readTimeoutSec);
        ConfHolder.getInstance().setNotifyIfEmpty(properties.getNotifyIfEmpty());
        
        return new DataHubInitializer(
                properties.getAccessKey(),
                properties.getSecretKey(),
                properties.getEndpoint(),
                properties.getBucketName(),
                properties.getObjectPath(),
                config,
                properties.getConfKey(), 
                properties.getApiKey(),
                properties.getAppCode(), url
        );
    }
    
    /**
     * 初始化 DataHubSdk 并启动
     */
    private DataHubSdk createSdk(DataHubInitializer initializer) {
        DataHubSdk sdk = new DataHubSdk(initializer);
        sdk.start();
        return sdk;
    }
    

    @Override
    public void afterPropertiesSet() {
        // Bean 初始化时自动创建 DataHub 相关对象
        this.initializer = createInitializer();
        ConfHolder.getInstance().setInitialDelay(properties.getInitialDelay());
        ConfHolder.getInstance().setPeriod(properties.getPeriod());
        this.sdk = createSdk(this.initializer);
        ConfRefreshListener.getInstance().start();
    }

    @Override
    public void destroy() {
        if (sdk != null) {
            sdk.shutdown();
        }
    }
    

    // Getter 方法供其他 Bean 使用
    public DataHubInitializer getInitializer() {
        return initializer;
    }

    public DataHubSdk getSdk() {
        return sdk;
    }

}