package com.joyintech.datahub.model;

import java.io.File;
import java.io.Serializable;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: MultipartReqDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/3/24 19:52 <br/>
 * Description: 分片上传文件对象  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class MultipartReqDTO implements Serializable {

    // 桶名称
    private String bucketName;
    //objectKey
    private String objectKey;
    //接口编码
    private String dataCode;
    //版本
    private String version;
    //链路ID
    private String traceId;
    //文件
    private File file;

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
