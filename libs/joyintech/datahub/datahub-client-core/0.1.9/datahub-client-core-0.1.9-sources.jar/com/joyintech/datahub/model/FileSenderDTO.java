package com.joyintech.datahub.model;

import java.io.File;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: SenderDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 19:43 <br/>
 * Description: 文件发送对象  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileSenderDTO extends SendBaseDTO {

    /**
     * 文件
     */
    private final File file;
     /**
     * 数据行数
     */
    private final long rowCount;

    public FileSenderDTO (Builder builder) {
        super.setDataCode( builder.dataCode);
        super.setDataVersion(builder.dataVersion);
        this.file = builder.file;
        this.rowCount = builder.rowCount;
    }

    public File getFile() {
        return file;
    }
     public long getRowCount() {
        return rowCount;
    }

    @Override
    public void validate() {

        super.validate();
        if (file == null || !file.exists()) {
            throw new IllegalArgumentException("File must exist");
        }
    }

    public static class Builder {
        private String dataCode;
        private  String dataVersion;
        private File file;

        private long rowCount;

        public Builder dataCode(String dataCode) {
            this.dataCode = dataCode;
            return this;
        }
        public Builder dataVersion(String dataVersion) {
            this.dataVersion = dataVersion;
            return this;
        }
        public Builder file(File file) {
            this.file = file;
            return this;
        }
        public Builder rowCount(long rowCount) {
            this.rowCount = rowCount;
            return this;
        }
        public FileSenderDTO build() {
            return new FileSenderDTO(this);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
