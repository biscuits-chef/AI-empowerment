package com.joyintech.datahub.purview;

import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.util.LocalConfigKeyUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 消费者权限控制类（支持 destroy / reinit）
 *
 * 1、持有消费配置信息
 * 2、提供线程安全的获取和刷新
 *
 * @author ChenHao
 * @date 11/19/25
 */
public class ConsumerPurview {

    private static final Logger log = LoggerFactory.getLogger(ConsumerPurview.class);

    private ConsumerPurview() {
    }

    private static volatile ConsumerPurview INSTANCE;

    public static ConsumerPurview getInstance() {
        if (INSTANCE == null) {
            synchronized (ConsumerPurview.class) {
                if (INSTANCE == null) {
                    INSTANCE = new ConsumerPurview();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 强制重新初始化（destroy + init）
     */
    public static synchronized void reinit() {
        if (INSTANCE != null) {
            INSTANCE.destroyInternal();
        }
        INSTANCE = new ConsumerPurview();
    }

    // ==================== 成员变量 ====================
    private final Map<String, ConfDto.ConsumerConfig> consumersConfigMap = new ConcurrentHashMap<>();
    private final ReadWriteLock consumersConfigLock = new ReentrantReadWriteLock();
    private volatile boolean destroyed = false;

    // ==================== API ====================

    /**
     * 获取消费者配置
     */
    public ConfDto.ConsumerConfig getConsumerConfig(String dataCode, String version) {
        if (destroyed) return null;
        String key = LocalConfigKeyUtil.generateKey(dataCode, version);
        consumersConfigLock.readLock().lock();
        try {
            return consumersConfigMap.get(key);
        } finally {
            consumersConfigLock.readLock().unlock();
        }
    }

    /**
     * 清空所有配置
     */
    public void clearConsumerConfig() {
        if (destroyed) return;
        consumersConfigLock.writeLock().lock();
        try {
            consumersConfigMap.clear();
            log.info("[ConsumerPurview] All consumer configs cleared.");
        } finally {
            consumersConfigLock.writeLock().unlock();
        }
    }

    /**
     * 全量刷新消费者配置
     */
    public void consumerConfigRefresh(List<ConfDto.ConsumerConfig> consumerConfigs) {
        if (destroyed) {
            log.warn("[ConsumerPurview] Ignored refresh because instance is destroyed.");
            return;
        }
        consumersConfigLock.writeLock().lock();
        try {
            consumersConfigMap.clear();

            Optional.ofNullable(consumerConfigs)
                    .orElse(Collections.emptyList())
                    .forEach(conf -> {
                        String key = LocalConfigKeyUtil.generateKey(conf.getDataCode(), conf.getVersion());
                        consumersConfigMap.put(key, conf);
                    });
            
            log.info("=================ConsumerPurview refresh====================");
            log.info("refresh Consumer config map success, size={}", consumersConfigMap.size());
            log.info("Consumer Configs: {}", consumersConfigMap.keySet());
            log.info("Consumer Configs: {}", consumersConfigMap);
            log.info("========================================================");
        } catch (Exception e) {
            log.error("Consumer init error consumerConfigList: {}", consumerConfigs, e);
            throw e;
        } finally {
            consumersConfigLock.writeLock().unlock();
        }
    }

    // ==================== 销毁 ====================
    public static synchronized void shutdown() {
        if (INSTANCE == null) {
            return;
        }
        INSTANCE.destroyInternal();
        INSTANCE = null;
    }

    private void destroyInternal() {
        if (destroyed) {
            return;
        }
        consumersConfigLock.writeLock().lock();
        try {
            if (destroyed) {
                return;
            }
            destroyed = true;
            consumersConfigMap.clear();
            log.info("[ConsumerPurview] Destroyed");
        } finally {
            consumersConfigLock.writeLock().unlock();
        }
    }
}
