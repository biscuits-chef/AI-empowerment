package com.joyintech.datahub.delayed;

import com.joyintech.datahub.util.ConfHolder;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.DelayQueue;

/**
 * 全局延迟文件删除器
 * <p>
 * 特点：
 * 1. 多线程 submit
 * 2. 单线程消费
 * 3. 支持 shutdown 后重新 init（JVM 不重启）
 *
 * @author ChenHao
 */
public final class GlobalFileDeleter {

    private static final Logger log = LoggerFactory.getLogger(GlobalFileDeleter.class);

    /**
     * 延迟 5 分钟删除
     */
    private static final long DELETE_DELAY_MS = 5 * 60 * 1000;

    /**
     * 运行状态
     */
    private static volatile boolean running = false;

    /**
     * 延迟队列（非 final，支持重建）
     */
    private static volatile DelayQueue<DelayedFile> queue;

    /**
     * 工作线程（非 final，支持重建）
     */
    private static volatile Thread workerThread;

    private GlobalFileDeleter() {
    }

    /* ======================= 生命周期 ======================= */

    /**
     * 初始化（可重复调用，幂等）
     */
    public static synchronized void init() {
        if (running) {
            log.info("GlobalFileDeleter already running");
            return;
        }

        queue = new DelayQueue<>();
        running = true;

        workerThread = new Thread(GlobalFileDeleter::run, "global-file-deleter");
        workerThread.setDaemon(true);
        workerThread.start();

        log.info("GlobalFileDeleter started");
    }



    /* ======================= 主循环 ======================= */

    private static void run() {
        while (running) {
            try {
                // 阻塞直到到期
                DelayedFile task = queue.take();
                deleteFile(task.getFile());
            } catch (InterruptedException e) {
                if (!running) {
                    break;
                }
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                // 防止线程异常退出
                log.error("Error in GlobalFileDeleter thread", e);
            }
        }

        log.info("GlobalFileDeleter worker thread exit");
    }

    /**
     * 销毁（可重复调用，幂等）
     */
    public static synchronized void shutdown() {
        if (!running) {
            log.info("GlobalFileDeleter already stopped");
            return;
        }

        running = false;

        if (workerThread != null) {
            workerThread.interrupt();
        }

        if (queue != null) {
            queue.clear();
        }

        workerThread = null;
        queue = null;

        try {
            cleanupTempDir();
        } catch (Exception e) {
            log.warn("Error during GlobalFileDeleter cleanupTempDir", e);
        }

        log.info("GlobalFileDeleter shutdown completed");
    }


    /**
     * shutdown 时清理临时目录
     */
    private static void cleanupTempDir() {
        String tempDirPath = ConfHolder.getInstance().getAttachTempDirectory();
        if (tempDirPath == null || tempDirPath.isEmpty()) {
            return;
        }

        File tempDir = new File(tempDirPath);
        if (!tempDir.exists() || !tempDir.isDirectory()) {
            return;
        }

        File[] files = tempDir.listFiles();
        if (files == null || files.length == 0) {
            return;
        }

        for (File file : files) {
            try {
                if (file.isFile()) {
                    Files.deleteIfExists(file.toPath());
                    log.info("Shutdown cleanup deleted file: {}", file.getAbsolutePath());
                }
            } catch (Exception e) {
                // 关闭阶段不要抛异常
                log.warn("Shutdown cleanup failed for file: {}", file.getAbsolutePath(), e);
            }
        }
    }


    private static void deleteFile(File file) {
        if (file == null) {
            return;
        }
        try {
            if (file.exists()) {
                Files.deleteIfExists(file.toPath());
                log.info("Deleted file: {}", file.getAbsolutePath());
            }
        } catch (Exception e) {
            log.warn("Failed to delete file: {}", file.getAbsolutePath(), e);
        }
    }

    /**
     * 提交一个 5 分钟后删除的文件
     */
    public static void submit(File file) {
        if (file == null) {
            return;
        }
        if (!running || queue == null) {
            log.warn("GlobalFileDeleter is not running, ignore submit: {}", file.getAbsolutePath());
            return;
        }

        queue.offer(new DelayedFile(file, DELETE_DELAY_MS));
    }

    /**
     * 提交多个 5 分钟后删除的文件
     */
    public static void submit(List<File> files) {
        if (CollectionUtils.isEmpty(files)) {
            return;
        }
        for (File file : files) {
            submit(file);
        }
    }

}