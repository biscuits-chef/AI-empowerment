package com.joyintech.datahub.model;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileGenStats.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 9:13 <br/>
 * Description: 文件生成统计  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileGenStats {
    /**
     * 总大小（字节）
     */
    private  long totalSize;
    /**
     * 行数
     */
    private  long lineCount;
    private int chunkCount;

    public FileGenStats(long totalSize, long lineCount) {
        this.totalSize = totalSize;
        this.lineCount = lineCount;
    }

    public FileGenStats(){

    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    public void setLineCount(long lineCount) {
        this.lineCount = lineCount;
    }

    public long getTotalSize() { return totalSize; }
    public long getLineCount() { return lineCount; }

    public int getChunkCount() {
        return chunkCount;
    }

    public void setChunkCount(int chunkCount) {
        this.chunkCount = chunkCount;
    }
}
