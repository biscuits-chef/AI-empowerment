package com.joyintech.datahub.common.enums;

/**
 * 通用错误码枚举
 * 此处为通用错误码，当前定义成功、未知异常、参数错误三种错误码
 *
 * @author ZY22350
 */
public enum DataHubErrorEnum implements ErrorCodeEnum {
    SUCCESS("000", "处理成功"),
    EXCEPTION("500", "处理异常"),
    PARAM_ERROR("400", "参数错误"),
    
    HTTP_ERROR("510","http调用异常"),
    FILE_ERROR("DH0500","文件操作异常"),
    FILE_FORMAT_ERROR("DH0501","文件格式错误"),
    
    RESPONSE_DATA_ERROR("DH0600","响应数据异常"),
    OBS_SERVER_ERROR("DH0502","OBS服务异常，重试达到最大次数")
    ;

    /**
     * 错误码
     */
    private final String code;
    /**
     * 错误描述
     */
    private final String desc;

    DataHubErrorEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
