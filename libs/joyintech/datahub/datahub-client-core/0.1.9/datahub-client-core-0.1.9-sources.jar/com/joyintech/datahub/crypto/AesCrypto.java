package com.joyintech.datahub.crypto;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

/**
 * @author ChenHao
 * @date 11/4/25 17:07
 */
public class AesCrypto {
    
    private static final String ALGO = "AES";
    private static final String TRANS = "AES/CBC/PKCS5Padding";
    private static final int IV_SIZE = 16;

    private AesCrypto() {
    }

    /**
     * 生成 Base64 密钥（128 bit）
     */
    public static String generateKey() {
        KeyGenerator keyGen;
        try {
            keyGen = KeyGenerator.getInstance(ALGO);
        } catch (NoSuchAlgorithmException e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,"Error generating AES key", e);
        }
        keyGen.init(128, new SecureRandom());
        SecretKey key = keyGen.generateKey();
        return Base64.getEncoder().encodeToString(key.getEncoded());
    }

    /**
     * 加密：返回 Base64( IV + CipherText )
     */
    public static String encrypt(String plain, String base64Key) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec key = keyFromBase64(base64Key);

        byte[] iv = randomIV();
        IvParameterSpec ivSpec = new IvParameterSpec(iv);  // NOSONAR

        Cipher cipher = Cipher.getInstance(TRANS);  // NOSONAR
        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);

        byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));

        byte[] result = new byte[IV_SIZE + encrypted.length];
        System.arraycopy(iv, 0, result, 0, IV_SIZE);
        System.arraycopy(encrypted, 0, result, IV_SIZE, encrypted.length);

        return Base64.getEncoder().encodeToString(result);
    }

    /**
     * 解密：输入 Base64(IV + CipherText)
     */
    public static String decrypt(String cipherBase64, String base64Key) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] allBytes = Base64.getDecoder().decode(cipherBase64);
        if (allBytes.length < IV_SIZE) {
            throw new IllegalArgumentException("Invalid encrypted data");
        }

        SecretKeySpec key = keyFromBase64(base64Key);

        byte[] iv = Arrays.copyOfRange(allBytes, 0, IV_SIZE);
        byte[] cipherBytes = Arrays.copyOfRange(allBytes, IV_SIZE, allBytes.length);

        Cipher cipher = Cipher.getInstance(TRANS);  // NOSONAR
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));

        byte[] plainBytes = cipher.doFinal(cipherBytes);
        return new String(plainBytes, StandardCharsets.UTF_8);
    }

    /* -------------------- private helpers -------------------- */

    private static SecretKeySpec keyFromBase64(String base64Key) {
        return new SecretKeySpec(Base64.getDecoder().decode(base64Key), ALGO);
    }

    private static byte[] randomIV() {
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        return iv;
    }
}