package com.joyintech.datahub.util;


import com.joyintech.datahub.model.MultipartReqDTO;
import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.UploadFileRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;


/**
 *
 * @author ChenHao
 * @date 1/8/26 19:44
 */
public class ObsUploader {

    private static final Logger log = LoggerFactory.getLogger(ObsUploader.class);

    /**
     * 单例实例
     */
    private static final ObsUploader INSTANCE = new ObsUploader();

    /**
     * 私有化构造
     */
    private ObsUploader() {
    }

    public static ObsUploader getInstance() {
        return INSTANCE;
    }
    
    /**
     * 上传本地文件到 OBS，支持断点续传和进度监听
     *
     * @param reqDTO 请求对象
     * @throws ObsException
     */
    public CompleteMultipartUploadResult uploadFile(MultipartReqDTO reqDTO)  {

        return uploadFileProcess(reqDTO,false);
    }

    /**
     * 上传本地文件到 OBS，支持断点续传和进度监听
     *
     * @param reqDTO 请求数据
     * @param isAttachFile 是否附件
     * @throws ObsException
     */
    public CompleteMultipartUploadResult uploadFileProcess(MultipartReqDTO reqDTO,
                                                           boolean isAttachFile)  {
        if(reqDTO == null ){
            throw new IllegalArgumentException("MultipartReqDTO is null");
        }
        if (!reqDTO.getFile().exists() || !reqDTO.getFile().isFile()) {
            throw new IllegalArgumentException("File does not exist: " + reqDTO.getFile().getAbsolutePath());
        }

        ConfHolder.ObsUploadConf obsUploadConf = ConfHolder.getInstance().getObsUploadConf();

        UploadFileRequest request = new UploadFileRequest(reqDTO.getBucketName(), reqDTO.getObjectKey());

        // 本地文件
        request.setUploadFile(reqDTO.getFile().getAbsolutePath());

        // 开启断点续传
        request.setEnableCheckpoint(obsUploadConf.getEnableCheckpoint());

        File orCreateTempDir = null;
        try {
            orCreateTempDir = getOrCreateTempDir();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        String absolutePath = orCreateTempDir.getAbsolutePath();
        // 可选：自定义 checkpoint 文件路径（默认同目录 .filename.upload）
        request.setCheckpointFile(absolutePath + File.separator + reqDTO.getFile().getName() + ".upload");

        // 并发上传线程数
        request.setTaskNum(obsUploadConf.getTaskNum());

        // 分片大小 50MB
        request.setPartSize(obsUploadConf.getPartSizeInBytes());
        //非附件要求进行特殊处理
        if(!isAttachFile){
            OBSMetadataUtil.applyFileUploadMetadata(reqDTO.getDataCode(),reqDTO.getVersion(),reqDTO.getTraceId(),request);
        }
        // 进度监听
        if (obsUploadConf.getListener()) {
            request.setProgressListener(status -> {
                long total = status.getTotalBytes();
                long transferred = status.getTransferredBytes();
                long delta = status.getNewlyTransferredBytes();

                double avgSpeed = status.getAverageSpeed() / 1024.0 / 1024.0;
                double instantSpeed = status.getInstantaneousSpeed() / 1024.0 / 1024.0;

                int percent = status.getTransferPercentage();

                DecimalFormat df = new DecimalFormat("0.00");

                log.info("[UPLOAD] {}% | {} / {} MB | +{} KB | avg={} MB/s | now={} MB/s",
                        percent,
                        df.format(transferred / 1024.0 / 1024.0),
                        df.format(total / 1024.0 / 1024.0),
                        delta / 1024,
                        df.format(avgSpeed),
                        df.format(instantSpeed)
                );
            });
        }

        ObsClient writer = ObsClientHolder.getInstance().getWriter();
        // 执行上传
        CompleteMultipartUploadResult result = writer.uploadFile(request);
        log.info("UPLOAD SUCCESS, etag={}", result.getEtag());
        return result;
    }
    /**
     * 获取或创建临时目录
     */
    private File getOrCreateTempDir() throws IOException {
        String baseTempDir = ConfHolder.getInstance().getTempDirectory();
        String appTempDir = baseTempDir + File.separator + "obs";

        File dir = new File(appTempDir);

        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new IOException("无法创建临时目录: " + appTempDir);
            }
            log.info("创建临时目录: {}", appTempDir);
        }

        // 验证目录是否可访问
        if (!dir.isDirectory()) {
            throw new IOException("临时路径不是目录: " + appTempDir);
        }
        if (!dir.canWrite()) {
            throw new IOException("临时目录不可写: " + appTempDir);
        }

        return dir;
    }

}