package com.joyintech.datahub.model;

import com.joyintech.datahub.common.constant.DataHubConstant;

import java.util.List;

/**
 * @author ChenHao
 * @date 11/12/25 09:10
 */
public class MsgHeader {

    private String traceId;
    private String toAppCode;
    private String fromAppCode;
    private String version;
    private String dataCode;
    // 数据日期
    private String dataDate;
    private String sendType;
    /**
     * 是否跳过第一行
     */
    private String skipLineOneFlag = DataHubConstant.Y_OR_N_N;
    //附件列表
    private List<AttachFile> attachFiles;

    public String getSkipLineOneFlag() {
        return skipLineOneFlag;
    }

    public void setSkipLineOneFlag(String skipLineOneFlag) {
        this.skipLineOneFlag = skipLineOneFlag;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getToAppCode() {
        return toAppCode;
    }

    public void setToAppCode(String toAppCode) {
        this.toAppCode = toAppCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getFromAppCode() {
        return fromAppCode;
    }

    public void setFromAppCode(String fromAppCode) {
        this.fromAppCode = fromAppCode;
    }

    public List<AttachFile> getAttachFiles() {
        return attachFiles;
    }

    public void setAttachFiles(List<AttachFile> attachFiles) {
        this.attachFiles = attachFiles;
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType;
    }

    @Override
    public String toString() {
        return "MsgHeader{" +
                "traceId='" + traceId + '\'' +
                ", toAppCode='" + toAppCode + '\'' +
                ", fromAppCode='" + fromAppCode + '\'' +
                ", version='" + version + '\'' +
                ", dataCode='" + dataCode + '\'' +
                ", dataDate='" + dataDate + '\'' +
                ", sendType='" + sendType + '\'' +
                ", skipLineOneFlag='" + skipLineOneFlag + '\'' +
                ", attachFiles=" + attachFiles +
                '}';
    }
}