package com.joyintech.datahub.handler;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import com.obs.services.ObsClient;
import com.obs.services.model.HttpMethodEnum;
import com.obs.services.model.TemporarySignatureRequest;
import com.obs.services.model.TemporarySignatureResponse;
import org.apache.commons.lang3.StringUtils;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: TempUrlHandler.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 15:57 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class TempUrlHandler {

    private TempUrlHandler(){
        //防止外部实例化
    }
    /**
     *功能描述: 生成临时授权下载URL
     * @param obsClient obsClient信息
     * @param bucketName 桶名称
     * @param objectKey 对象key
     * @return  java.lang.String 临时文件url
     *
     */
    public static String buildTempUrl(ObsClient obsClient,String bucketName,String objectKey){
        if(obsClient == null){
            throw new IllegalArgumentException("obcClient对象未传");
        }
        if(StringUtils.isBlank(bucketName)){
            throw new IllegalArgumentException("bucketName未传");
        }
        if(StringUtils.isBlank(objectKey)){
            throw new IllegalArgumentException("objectKey未传");
        }
        return generateTempAccessUrl(obsClient,bucketName,objectKey,3600*24);
    }
    /**
     *功能描述: 生成临时授权下载URL
     * @param obsClient obsClient信息
     * @param bucketName 桶名称
     * @param objectKey 对象key
     * @param expireSeconds 过期秒---默认为24H
     * @return  java.lang.String 临时文件url
     *
     */
    public static String generateTempAccessUrl(ObsClient obsClient,String bucketName, String objectKey,
                                          Integer expireSeconds) {
        if (expireSeconds == null || expireSeconds <= 0) {
            expireSeconds = 3600 * 24; // 默认1小时
        }

        try {
            // 使用OBS SDK生成预签名URL
            TemporarySignatureRequest request = new TemporarySignatureRequest();
            request.setMethod(HttpMethodEnum.GET);
            request.setBucketName(bucketName);
            request.setObjectKey(objectKey);
            request.setExpires(expireSeconds);

            TemporarySignatureResponse response = obsClient.createTemporarySignature(request);
            return response.getSignedUrl();

        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,"生成临时访问URL异常", e);
        }
    }

}
