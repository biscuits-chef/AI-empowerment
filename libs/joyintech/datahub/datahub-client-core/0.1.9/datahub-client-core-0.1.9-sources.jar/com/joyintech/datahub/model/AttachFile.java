package com.joyintech.datahub.model;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AttachFile.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 16:10 <br/>
 * Description: 附件文件信息  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AttachFile {
    /**
     * 文件源名称
     */
    private String fileSourceName;
    /**
     * 文件临时下载地址
     */
    private String fileTmpUrl;

    public String getFileSourceName() {
        return fileSourceName;
    }

    public void setFileSourceName(String fileSourceName) {
        this.fileSourceName = fileSourceName;
    }

    public String getFileTmpUrl() {
        return fileTmpUrl;
    }

    public void setFileTmpUrl(String fileTmpUrl) {
        this.fileTmpUrl = fileTmpUrl;
    }
}
