package com.joyintech.datahub.transporter;


import com.joyintech.datahub.model.ConfDto;


/**
 * 配置管理：拉取、读本地缓存、写本地缓存
 *
 * @author ChenHao
 * @date 11/4/25 17:07
 */
public interface ConfigTransporter {

    /**
     * 拉取配置
     * 
     * @return 配置对象
     */
    ConfDto fetchConf();
    
}