package com.joyintech.datahub.transporter;


import com.joyintech.datahub.crypto.AesCrypto;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.URL;
import com.joyintech.datahub.refresh.heart.VertxTransporter;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JsonUtil;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;

/**
 * 配置管理：拉取、读本地缓存、写本地缓存
 *
 * @author ChenHao
 * @date 11/4/25 17:07
 */
public class HttpConfigTransporter implements ConfigTransporter {

    private static final Logger log = LoggerFactory.getLogger(HttpConfigTransporter.class);

    @Override
    public ConfDto fetchConf() {
        ConfDto confDto;
        try {

            String response;
            try {
                VertxTransporter transporter = VertxTransporter.getInstance();
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("appCode", ConfHolder.getInstance().getAppCode());
                hashMap.put("apiKey", ConfHolder.getInstance().getApiKey());

                URL confUrl = ConfHolder.getInstance().getConfUrl();
                
                response = transporter.post(confUrl, hashMap, String.class)
                        .toCompletableFuture()
                        .get();
                
            } catch (InterruptedException e) {
                log.error("Request interrupted", e);
                return null;
            } catch (ExecutionException e) {
                log.error("Request execution failed", e);
                return null;
            }

            if (response == null || response.isEmpty()) {
                return null;
            }
            
            // Content type 'application/x-www-form-urlencoded;charset=UTF-8' not supported
            JsonObject jsonObject = new JsonObject(response);
            // 获取 data 对象
            String dataObj = jsonObject.getString("data");
            String encrypt = null;
            try {
                encrypt = AesCrypto.decrypt(dataObj, ConfHolder.getInstance().getConfKey());
            } catch (Exception e) {
                log.error("Decrypt configuration failed", e);
                return null;
            }
            confDto = JsonUtil.fromJson(encrypt, ConfDto.class);
            log.info("HTTP configuration pulled successfully");
        } catch (Exception e) {
            log.error("Request to server failed", e);
            return null;
        }
        ConfHolder.getInstance().init(confDto);
        return confDto;
    }

}
