package com.joyintech.datahub.common.enums;


import java.util.Objects;

/**
 * 日志级别
 *
 * @author 
 * @since 12/20/20
 */
public enum LogLevel {

    DEBUG(1),
    INFO(2),
    WARN(3),
    ERROR(4),
    OFF(99);

    private final int v;

    LogLevel(int v) {
        this.v = v;
    }

    public int getV() {
        return v;
    }

    public static String genLogLevelString(Integer v) {

        for (LogLevel logLevel : values()) {
            if (Objects.equals(logLevel.v, v)) {
                return logLevel.name();
            }
        }
        return "UNKNOWN";
    }
}
