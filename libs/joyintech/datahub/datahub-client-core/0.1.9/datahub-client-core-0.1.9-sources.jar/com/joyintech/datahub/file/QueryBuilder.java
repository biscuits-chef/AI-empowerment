package com.joyintech.datahub.file;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: QueryBuilder.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/17 14:57 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class QueryBuilder<T> {

    private final Map<String, Object> conditions = new HashMap<>();
    private String orderBy;
    private boolean ascending = true;
    private Integer page;
    private Integer size;

    public QueryBuilder<T> addCondition(String field, Object value) {
        conditions.put(field, value);
        return this;
    }

    public QueryBuilder<T> orderBy(String field, boolean ascending) {
        this.orderBy = field;
        this.ascending = ascending;
        return this;
    }

    public QueryBuilder<T> putMap(Map<String,Object> maps) {
       this.conditions.putAll(maps);
       return this;
    }

    public QueryBuilder<T> page(int page, int size) {
        this.page = page;
        this.size = size;
        return this;
    }
    public int getOffset() {
        return page != null && size != null ? page * size : 0;
    }

    public Integer getPage() { return page; }
    public Integer getSize() { return size; }

    public Map<String, Object> getConditions() {
        return conditions;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public boolean isAscending() {
        return ascending;
    }

    // 清空分页信息（用于复用 QueryBuilder）
    public QueryBuilder<T> clearPagination() {
        this.page = null;
        this.size = null;
        return this;
    }
}
