package com.joyintech.datahub.model;

import com.joyintech.datahub.file.FieldExtractor;

import java.util.Iterator;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileSenderDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 13:49 <br/>
 * Description: 文件发送DTO -用于通过此处进行文件发送处理接口 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DataSenderDTO<T> extends SendBaseDTO {

    /**
     * 数据迭代器
     */
    private final Iterator<T> dataIterator;
    /**
     * 字段提取器
     */
    private final FieldExtractor<T> fieldExtractor;

    public DataSenderDTO(Builder<T> builder) {
        super.setDataCode(builder.dataCode);
        super.setDataVersion(builder.dataVersion);
        this.dataIterator = builder.dataIterator;
        this.fieldExtractor = builder.fieldExtractor;
    }

    public Iterator<T> getDataIterator() {
        return dataIterator;
    }

    public FieldExtractor<T> getFieldExtractor() {
        return fieldExtractor;
    }

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }
    /**
     * 构建者
     * @param <T>
     */
    public static class Builder<T> {
        private String dataCode;
        private  String dataVersion;
        private  Iterator<T> dataIterator;
        private  FieldExtractor<T> fieldExtractor;
        public Builder<T> dataCode(String dataCode) {
            this.dataCode = dataCode;
            return this;
        }

        public Builder<T> dataVersion(String dataVersion) {
            this.dataVersion = dataVersion;
            return this;
        }

        public Builder<T> dataIterator(Iterator<T> dataIterator) {
            this.dataIterator = dataIterator;
            return this;
        }

        public Builder<T> fieldExtractor(FieldExtractor<T> fieldExtractor) {
            this.fieldExtractor = fieldExtractor;
            return this;
        }
        public DataSenderDTO<T> build() {
            return new DataSenderDTO<>(this);
        }
    }
    public void validate() {

        super.validate();
        if (fieldExtractor == null ) {
            throw new IllegalArgumentException("fieldExtractor is required");
        }
        if (dataIterator == null ) {
            throw new IllegalArgumentException("dataIterator is required");
        }
    }

}
