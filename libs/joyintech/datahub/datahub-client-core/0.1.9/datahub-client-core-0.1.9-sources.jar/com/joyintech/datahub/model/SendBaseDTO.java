package com.joyintech.datahub.model;

import org.apache.commons.lang3.StringUtils;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileSend.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/20 13:53 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class SendBaseDTO {
    
    private String partitionKey;
    /**
     * 数据编码
     */
    private String dataCode;
    /**
     * 数据版本
     */
    private String dataVersion;

    public String getDataCode() {
        return dataCode;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getPartitionKey() {
        return partitionKey;
    }

    public void setPartitionKey(String partitionKey) {
        this.partitionKey = partitionKey;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }
    public void validate() {

        if (StringUtils.isBlank(dataCode)) {
            throw new IllegalArgumentException("DataCode is required");
        }
        if (StringUtils.isBlank(dataVersion)) {
            throw new IllegalArgumentException("DataVersion is required");
        }
    }

}
