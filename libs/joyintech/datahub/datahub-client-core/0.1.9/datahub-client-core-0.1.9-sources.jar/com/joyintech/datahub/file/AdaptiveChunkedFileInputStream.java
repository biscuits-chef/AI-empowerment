package com.joyintech.datahub.file;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AdaptiveChunkedFileInputStream.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 13:25 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */

import com.joyintech.datahub.model.FileGenStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

/**
 * 自适应分块文件输入流 - 独立实现，支持动态分块大小调整
 */
public class AdaptiveChunkedFileInputStream<T> extends InputStream {
    private static final Logger log = LoggerFactory.getLogger(AdaptiveChunkedFileInputStream.class);

    private final Iterator<T> dataIterator;
    private final EnhancedLineConverter<T> lineConverter;
    private final Charset charset;

    // 分块大小配置
    private final int initialChunkSize;
    private final int minChunkSize;
    private final int maxChunkSize;
    private int currentChunkSize;

    // 当前块状态
    private byte[] currentChunk;
    private int currentPosition = 0;
    private boolean hasMoreData = true;

    // 统计信息
    private long totalBytesGenerated = 0;
    private long lineCount = 0;
    private int chunkCount = 0;
    private final FileGenStats fileGenStats = new FileGenStats();

    // 性能监控与自适应调整
    private long lastChunkLoadTime;
    private double averageChunkLoadTime = 100.0; // 初始估值(ms)
    private double averageChunkSize = 0; // 平均分块大小
    private final double smoothingFactor = 0.8; // 平滑因子
    // 添加暂存队列
    private final Queue<T> pendingQueue = new LinkedList<>();
    private static final long MIN_ADJUSTMENT_INTERVAL = 2000; // 最小调整间隔2秒

    // 同步锁
    private final Object lock = new Object();
    private boolean closed = false;

    // 缓冲区
    private final StringBuilder chunkBuffer = new StringBuilder();

    public AdaptiveChunkedFileInputStream(Iterator<T> dataIterator,
                                          EnhancedLineConverter<T> lineConverter,
                                          Charset charset) {
        this(dataIterator, lineConverter, charset,
                512 * 1024,    // 初始512KB
                64 * 1024,     // 最小64KB
                8 * 1024 * 1024 // 最大8MB
        );
    }

    public AdaptiveChunkedFileInputStream(Iterator<T> dataIterator,
                                          EnhancedLineConverter<T> lineConverter,
                                          Charset charset,
                                          int initialChunkSize,
                                          int minChunkSize,
                                          int maxChunkSize) {
        this.dataIterator = dataIterator;
        this.lineConverter = lineConverter;
        this.charset = charset;
        this.initialChunkSize = initialChunkSize;
        this.minChunkSize = minChunkSize;
        this.maxChunkSize = maxChunkSize;
        this.currentChunkSize = initialChunkSize;
        this.lastChunkLoadTime = System.currentTimeMillis();

        log.info("初始化自适应分块流 - 初始大小: {}KB, 范围: {}-{}KB",
                initialChunkSize/1024, minChunkSize/1024, maxChunkSize/1024);

        // 预加载第一个分块
        loadNextChunk();
    }

    /**
     * 智能加载下一个数据分块
     */
    private void loadNextChunk() {
        synchronized (lock) {
            long startTime = System.currentTimeMillis();

            try {
                chunkBuffer.setLength(0); // 清空缓冲区
                int estimatedSize = 0;
                int linesInChunk = 0;

                // 构建分块，直到达到指定大小或没有更多数据
                while ((dataIterator.hasNext() || !pendingQueue.isEmpty()) && estimatedSize < currentChunkSize) {
                    T data;
                    if (!pendingQueue.isEmpty()) {
                        // 先处理暂存的数据
                        data = pendingQueue.poll();
                    } else {
                        // 从迭代器获取新数据
                        data = dataIterator.next();
                    }

                    String line = lineConverter.convertToLine(data) + "\n";
                    int lineSize = line.getBytes(charset).length;

                    // 检查添加后是否超过分块大小
                    if (estimatedSize + lineSize > currentChunkSize && chunkBuffer.length() > 0) {
                        // 暂存当前数据到下一个分块
                        pendingQueue.offer(data);
                        break;
                    }

                    // 添加行数据
                    chunkBuffer.append(line);
                    estimatedSize += lineSize;
                    linesInChunk++;
                    lineCount++;
                }

                if (chunkBuffer.length() > 0) {
                    currentChunk = chunkBuffer.toString().getBytes(charset);
                    currentPosition = 0;
                    totalBytesGenerated += currentChunk.length;
                    chunkCount++;

                    // 更新平均分块大小
                    averageChunkSize = averageChunkSize * smoothingFactor +
                            currentChunk.length * (1 - smoothingFactor);

                    long loadTime = System.currentTimeMillis() - startTime;
                    updatePerformanceMetrics(loadTime, currentChunk.length, linesInChunk);

                    if (log.isDebugEnabled()) {
                        log.debug("分块 {} - 大小: {}KB, 行数: {}, 加载时间: {}ms, 当前分块大小: {}KB",
                                chunkCount, currentChunk.length/1024, linesInChunk, loadTime, currentChunkSize/1024);
                    }

                } else {

                    close();
                    log.info("所有分块加载完成 - 总分块: {}, 总行数: {}, 总大小: {}, 最终分块大小: {}KB",
                            chunkCount, lineCount, totalBytesGenerated > 1024*1024 ? totalBytesGenerated/(1024*1024) +
                                    "MB" : totalBytesGenerated/1024 + "KB",
                            currentChunkSize/1024);
                }

            } catch (Exception e) {
                log.error("加载分块失败", e);
                throw new RuntimeException("分块加载失败", e);
            }
        }
    }

    /**
     * 更新性能指标并调整分块大小
     */
    private void updatePerformanceMetrics(long loadTime, int chunkSize, int linesInChunk) {
        // 更新平均加载时间（指数加权移动平均）
        averageChunkLoadTime = averageChunkLoadTime * smoothingFactor +
                loadTime * (1 - smoothingFactor);

        // 智能调整分块大小（考虑时间间隔）
        adjustChunkSizeWithInterval(loadTime, chunkSize, linesInChunk);

        lastChunkLoadTime = System.currentTimeMillis();
    }

    /**
     * 带时间间隔控制的智能调整分块大小策略
     */
    private void adjustChunkSizeWithInterval(long loadTime, int actualChunkSize, int linesInChunk) {
        long currentTime = System.currentTimeMillis();
        long timeSinceLastAdjustment = currentTime - lastChunkLoadTime;

        // 检查是否达到最小调整间隔
        if (timeSinceLastAdjustment < MIN_ADJUSTMENT_INTERVAL) {
            if (log.isDebugEnabled()) {
                log.debug("跳过调整 - 距离上次调整仅 {}ms，小于最小间隔 {}ms",
                        timeSinceLastAdjustment, MIN_ADJUSTMENT_INTERVAL);
            }
            return;
        }

        // 只在处理了足够数据后才开始调整
        if (chunkCount < 3) {
            log.debug("跳过调整 - 分块数 {} 小于最小阈值 3", chunkCount);
            return;
        }

        int oldSize = currentChunkSize;
        double loadTimePerKB = actualChunkSize > 0 ? loadTime / (actualChunkSize / 1024.0) : 0;
        double utilizationRate = currentChunkSize > 0 ? (double) actualChunkSize / currentChunkSize : 0;

        // 基于多个因素的智能调整策略
        boolean adjusted = false;

        if (loadTime < 50 && loadTimePerKB < 0.1 && utilizationRate > 0.8) {
            // 情况1：性能优秀且利用率高，大幅增加分块大小
            currentChunkSize = Math.min(currentChunkSize * 2, maxChunkSize);
            adjusted = true;
            log.info("性能优秀，大幅增加分块大小: {}KB -> {}KB (利用率: {}%, 加载时间: {}ms)",
                    oldSize/1024, currentChunkSize/1024,
                    String.format("%.1f", utilizationRate*100), loadTime);

        } else if (loadTime < 200 && loadTimePerKB < 0.3 && utilizationRate > 0.7) {
            // 情况2：性能良好，适度增加
            currentChunkSize = Math.min((int)(currentChunkSize * 1.5), maxChunkSize);
            adjusted = true;
            log.info("↑ 性能良好，适度增加分块大小: {}KB -> {}KB (利用率: {}%)",
                    oldSize/1024, currentChunkSize/1024,
                    String.format("%.1f", utilizationRate*100));

        } else if (loadTime > 1000 || loadTimePerKB > 2.0) {
            // 情况3：加载过慢，大幅减少分块大小
            currentChunkSize = Math.max(currentChunkSize / 2, minChunkSize);
            adjusted = true;
            log.info("加载较慢，大幅减少分块大小: {}KB -> {}KB (加载时间: {}ms, 每KB: {}ms)",
                    oldSize/1024, currentChunkSize/1024, loadTime,
                    String.format("%.2f", loadTimePerKB));

        } else if (loadTime > 500 || loadTimePerKB > 1.0) {
            // 情况4：加载偏慢，适度减少
            currentChunkSize = Math.max((int)(currentChunkSize * 0.7), minChunkSize);
            adjusted = true;
            log.info("加载偏慢，适度减少分块大小: {}KB -> {}KB",
                    oldSize/1024, currentChunkSize/1024);

        } else if (utilizationRate < 0.5) {
            // 情况5：利用率过低，适度减少
            currentChunkSize = Math.max((int)(currentChunkSize * 0.8), minChunkSize);
            adjusted = true;
            log.info("利用率低，减少分块大小: {}KB -> {}KB (利用率: {}%)",
                    oldSize/1024, currentChunkSize/1024,
                    String.format("%.1f", utilizationRate*100));
        }

        // 防止频繁振荡
        if (adjusted && Math.abs(currentChunkSize - oldSize) < minChunkSize) {
            currentChunkSize = oldSize;
            log.debug("取消调整 - 变化太小，防止振荡");
        }

        // 记录调整时间
        if (adjusted) {
            lastChunkLoadTime = currentTime;
        }
    }

    @Override
    public int read() throws IOException {
        synchronized (lock) {
            if (!hasMoreData && (currentChunk == null || currentPosition >= currentChunk.length)) {
                return -1;
            }

            // 如果当前分块已读完，加载下一个
            if (currentChunk == null || currentPosition >= currentChunk.length) {
                loadNextChunk();
                if (currentChunk == null) {
                    return -1;
                }
            }

            // 读取当前字节
            return currentChunk[currentPosition++] & 0xFF;
        }
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        } else if (off < 0 || len < 0 || len > b.length - off) {
            throw new IndexOutOfBoundsException();
        } else if (len == 0) {
            return 0;
        }

        synchronized (lock) {
            return doRead(b, off, len);
        }
    }

    private int doRead(byte[] b, int off, int len) {
        int totalRead = 0;

        while (len > 0 && hasMoreData) {
            // 如果当前分块已读完，加载下一个
            if (currentChunk == null || currentPosition >= currentChunk.length) {
                loadNextChunk();
                if (currentChunk == null) {
                    break;
                }
            }

            // 计算当前分块剩余字节数
            int remainingInChunk = currentChunk.length - currentPosition;
            if (remainingInChunk <= 0) {
                continue;
            }

            // 复制数据
            int bytesToCopy = Math.min(remainingInChunk, len);
            System.arraycopy(currentChunk, currentPosition, b, off, bytesToCopy);

            currentPosition += bytesToCopy;
            off += bytesToCopy;
            len -= bytesToCopy;
            totalRead += bytesToCopy;
        }

        return totalRead == 0 && !hasMoreData ? -1 : totalRead;
    }

    @Override
    public int available() throws IOException {
        synchronized (lock) {
            if (currentChunk == null || currentPosition >= currentChunk.length) {
                return 0;
            }
            return currentChunk.length - currentPosition;
        }
    }

    @Override
    public void close() throws IOException {
        if (closed) {
            if (log.isDebugEnabled()) {
                log.debug("流已经关闭，跳过重复关闭操作");
            }
            return;
        }

        synchronized (lock) {
            if (closed) {
                if (log.isDebugEnabled()) {
                    log.debug("流已经关闭，跳过重复关闭操作");
                }
                return;
            }

            closed = true;

            try {
                // 清理所有资源
                hasMoreData = false;
                currentChunk = null;
                currentPosition = 0;
                chunkBuffer.setLength(0);

                // 清理迭代器引用（帮助GC）
                if (dataIterator != null) {
                    // 如果迭代器有close方法，调用它
                    if (dataIterator instanceof AutoCloseable) {
                        try {
                            ((AutoCloseable) dataIterator).close();
                        } catch (Exception e) {
                            log.debug("关闭数据迭代器时发生异常", e);
                        }
                    }
                }

                // 必须调用父类close()来确保InputStream正确关闭
                super.close();

                log.info("AdaptiveChunkedFileInputStream  已关闭 - 总分块: {}, 总行数: {}, 总大小: {}",
                         chunkCount, lineCount, totalBytesGenerated > 1024 *1024 ? totalBytesGenerated/(1024*1024) +
                                "MB" :
                            totalBytesGenerated/1024 + "KB");

            } catch (IOException e) {
                log.error("实例关闭时发生IO异常",e);
                throw e;
            } catch (Exception e) {
                log.error("实例关闭过程中发生未预期异常", e);
                // 即使发生异常，也要确保标记为已关闭
                throw new IOException("关闭流时发生异常", e);
            }
        }
    }

    /**
     * 获取文件统计信息
     */
    public FileGenStats getFileStats() {
        fileGenStats.setTotalSize(totalBytesGenerated);
        fileGenStats.setLineCount(lineCount);
        fileGenStats.setChunkCount(chunkCount);
        return fileGenStats;
    }

    /**
     * 获取性能指标
     */
    public PerformanceMetrics getPerformanceMetrics() {
        synchronized (lock) {
            return new PerformanceMetrics(
                    currentChunkSize,
                    averageChunkLoadTime,
                    averageChunkSize,
                    chunkCount,
                    getCurrentChunkInfo(),
                    lastChunkLoadTime
            );
        }
    }

    /**
     * 获取当前分块信息
     */
    public ChunkInfo getCurrentChunkInfo() {
        synchronized (lock) {
            int currentChunkSize = currentChunk != null ? currentChunk.length : 0;
            int remainingInChunk = currentChunk != null ? currentChunk.length - currentPosition : 0;

            return new ChunkInfo(chunkCount, currentChunkSize, currentPosition,
                    remainingInChunk, hasMoreData);
        }
    }

    /**
     * 获取当前动态分块大小
     */
    public int getCurrentChunkSize() {
        return currentChunkSize;
    }

    /**
     * 重置分块大小为初始值
     */
    public void resetChunkSize() {
        synchronized (lock) {
            int oldSize = currentChunkSize;
            currentChunkSize = initialChunkSize;
            lastChunkLoadTime = System.currentTimeMillis();
            log.info("重置分块大小: {}KB -> {}KB", oldSize/1024, currentChunkSize/1024);
        }
    }

    /**
     * 获取上次调整时间
     */
    public long getLastAdjustmentTime() {
        return lastChunkLoadTime;
    }

    /**
     * 性能指标
     */
    public static class PerformanceMetrics {
        private final int currentChunkSize;
        private final double averageLoadTime;
        private final double averageChunkSize;
        private final int totalChunks;
        private final ChunkInfo currentChunkInfo;
        private final long lastAdjustmentTime;

        public PerformanceMetrics(int currentChunkSize, double averageLoadTime,
                                  double averageChunkSize, int totalChunks,
                                  ChunkInfo currentChunkInfo, long lastAdjustmentTime) {
            this.currentChunkSize = currentChunkSize;
            this.averageLoadTime = averageLoadTime;
            this.averageChunkSize = averageChunkSize;
            this.totalChunks = totalChunks;
            this.currentChunkInfo = currentChunkInfo;
            this.lastAdjustmentTime = lastAdjustmentTime;
        }

        public int getCurrentChunkSize() { return currentChunkSize; }
        public double getAverageLoadTime() { return averageLoadTime; }
        public double getAverageChunkSize() { return averageChunkSize; }
        public int getTotalChunks() { return totalChunks; }
        public ChunkInfo getCurrentChunkInfo() { return currentChunkInfo; }
        public long getLastAdjustmentTime() { return lastAdjustmentTime; }

        @Override
        public String toString() {
            return String.format(
                    "PerformanceMetrics{当前分块: %dKB, 平均加载: %.2fms, 平均分块: %.2fKB, 总分块: %d, 上次调整: %dms前}",
                    currentChunkSize/1024, averageLoadTime, averageChunkSize/1024, totalChunks,
                    System.currentTimeMillis() - lastAdjustmentTime
            );
        }
    }

    /**
     * 当前分块信息
     */
    public static class ChunkInfo {
        private final int chunkNumber;
        private final int chunkSize;
        private final int currentPosition;
        private final int remainingBytes;
        private final boolean hasMoreData;

        public ChunkInfo(int chunkNumber, int chunkSize, int currentPosition,
                         int remainingBytes, boolean hasMoreData) {
            this.chunkNumber = chunkNumber;
            this.chunkSize = chunkSize;
            this.currentPosition = currentPosition;
            this.remainingBytes = remainingBytes;
            this.hasMoreData = hasMoreData;
        }

        public int getChunkNumber() { return chunkNumber; }
        public int getChunkSize() { return chunkSize; }
        public int getCurrentPosition() { return currentPosition; }
        public int getRemainingBytes() { return remainingBytes; }
        public boolean isHasMoreData() { return hasMoreData; }

        @Override
        public String toString() {
            return String.format("ChunkInfo{#%d, 大小: %dKB, 位置: %d, 剩余: %dKB, 还有数据: %s}",
                    chunkNumber, chunkSize/1024, currentPosition,
                    remainingBytes/1024, hasMoreData);
        }
    }
}