package com.joyintech.datahub.model;

import java.util.Arrays;

/**
 * @author ChenHao
 * @date 1/14/26 11:01
 */
public class DhcLogContext {

    private String traceId;
    private String logType;
    private String dataDate;
    private String fromAppCode;
    private String dataCode;
    private String version;
    private String level;
    private String headers;
    private String logPhase;
    private String message;
    private Long durationMs;
    private String[] args;
    private String recordContents;
    private Throwable throwable;

    private DhcLogContext() {}

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private final DhcLogContext ctx = new DhcLogContext();

        public Builder traceId(String traceId) {
            ctx.traceId = traceId;
            return this;
        }

        public Builder logType(String logType) {
            ctx.logType = logType;
            return this;
        }

        public Builder dataDate(String dataDate) {
            ctx.dataDate = dataDate;
            return this;
        }

        public Builder fromAppCode(String fromAppCode) {
            ctx.fromAppCode = fromAppCode;
            return this;
        }

        public Builder dataCode(String dataCode) {
            ctx.dataCode = dataCode;
            return this;
        }

        public Builder version(String version) {
            ctx.version = version;
            return this;
        }

        public Builder message(String message) {
            ctx.message = message;
            return this;
        }

        public Builder durationMs(Long durationMs) {
            ctx.durationMs = durationMs;
            return this;
        }

        public Builder args(String... args) {
            ctx.args = args;
            return this;
        }

        public Builder recordContents(String recordContents) {
            ctx.recordContents = recordContents;
            return this;
        }
        
        public Builder level(String level) {
            ctx.level = level;
            return this;
        }
        
        public Builder logPhase(String logPhase) {
            ctx.logPhase = logPhase;
            return this;
        }
        
        public Builder throwable(Throwable throwable) {
            ctx.throwable = throwable;
            return this;
        }
        
        public Builder headers(String headers) {
            ctx.headers = headers;
            return this;
        }
        
        public DhcLogContext build() {
            return ctx;
        }
        
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getFromAppCode() {
        return fromAppCode;
    }

    public void setFromAppCode(String fromAppCode) {
        this.fromAppCode = fromAppCode;
    }

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Long durationMs) {
        this.durationMs = durationMs;
    }

    public String[] getArgs() {
        return args;
    }

    public void setArgs(String[] args) {
        this.args = args;
    }

    public String getRecordContents() {
        return recordContents;
    }

    public void setRecordContents(String recordContents) {
        this.recordContents = recordContents;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getLogPhase() {
        return logPhase;
    }

    public void setLogPhase(String logPhase) {
        this.logPhase = logPhase;
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers;
    }

    public Throwable getThrowable() {
        return throwable;
    }
    
    @Override
    public String toString() {
        return "DhcLogContext{" +
                "traceId='" + traceId + '\'' +
                ", logType=" + logType +
                ", dataDate='" + dataDate + '\'' +
                ", fromAppCode='" + fromAppCode + '\'' +
                ", dataCode='" + dataCode + '\'' +
                ", version='" + version + '\'' +
                ", level='" + level + '\'' +
                ", logPhase='" + logPhase + '\'' +
                ", message='" + message + '\'' +
                ", durationMs=" + durationMs +
                ", args=" + Arrays.toString(args) +
                ", recordContents='" + recordContents + '\'' +
                '}';
    }
}