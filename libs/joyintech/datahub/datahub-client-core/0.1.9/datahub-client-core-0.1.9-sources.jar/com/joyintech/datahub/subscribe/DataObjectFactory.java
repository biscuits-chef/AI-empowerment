package com.joyintech.datahub.subscribe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DataObjectFactory.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 20:08 <br/>
 * Description: 数据对象工厂 - 高性能创建和映射  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DataObjectFactory {
    private static final Logger log = LoggerFactory.getLogger(DataObjectFactory.class);

    /**
     * 创建并映射数据对象
     */
    public static <T extends DhBaseDTO> T createAndMap(Class<T> clazz, String[] fields) {
        try {
            T instance = clazz.getDeclaredConstructor().newInstance();
            instance.mapFromFields(fields);
            return instance;
        } catch (Exception e) {
            log.error("创建数据对象失败: {}", clazz.getSimpleName(), e);
            return null;
        }
    }

    /**
     * 批量创建和映射
     */
    public static <T extends DhBaseDTO> List<T> batchCreateAndMap(Class<T> clazz, List<String[]> fieldsList) {
        List<T> result = new ArrayList<>(fieldsList.size());
        for (String[] fields : fieldsList) {
            T obj = createAndMap(clazz, fields);
            if (obj != null) {
                result.add(obj);
            }
        }
        return result;
    }
}