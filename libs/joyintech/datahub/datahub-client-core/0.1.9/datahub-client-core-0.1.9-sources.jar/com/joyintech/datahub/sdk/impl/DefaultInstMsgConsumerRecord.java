package com.joyintech.datahub.sdk.impl;

import com.joyintech.datahub.sdk.InstMsgConsumerRecord;
import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DefaultInstantMsgLog.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 14:16 <br/>
 * Description: 即时消息记录默认实现 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DefaultInstMsgConsumerRecord implements InstMsgConsumerRecord {
    private static final Logger log = LoggerFactory.getLogger(DefaultInstMsgConsumerRecord.class);
    @Override
    public void startLog(InstantMsgLogDTO logDTO) {
        log.info("接收即时消息为：{}",logDTO);
    }

    @Override
    public void endLog(String traceId, String result, String errorMsg) {
        log.info("即时消息接收：{}，处理结果：{}，错误消息：{}",traceId,result,errorMsg);
    }
}
