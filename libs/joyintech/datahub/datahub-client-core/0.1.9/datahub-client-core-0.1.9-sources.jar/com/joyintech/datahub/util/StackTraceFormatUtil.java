package com.joyintech.datahub.util;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/**
 * @author ChenHao
 * @date 12/2/25 20:33
 */
public class StackTraceFormatUtil {

    /** 默认打印行数（全局配置） */
    private static volatile int defaultLines = 5;

    private StackTraceFormatUtil() {
    }

    /** 启动时调用，修改全部地方的打印行数 */
    public static void setDefaultLines(int n) {
        defaultLines = n;
    }

    /**
     * 获取异常堆栈（使用 DEFAULT_LINES）
     */
    public static String getStackTrace(Throwable t) {
        if (t == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        Set<Throwable> dejaVu = Collections.newSetFromMap(new IdentityHashMap<>());
        appendStackTrace(sb, t, null, defaultLines, dejaVu);
        return sb.toString();
    }

    private static void appendStackTrace(StringBuilder sb,
                                         Throwable t,
                                         String caption,
                                         int n,
                                         Set<Throwable> dejaVu) {

        if (dejaVu.contains(t)) {
            sb.append(nonNull(caption))
                    .append("[CIRCULAR REFERENCE: ").append(t).append("]\n");
            return;
        }
        dejaVu.add(t);

        // 异常头
        if (caption != null) {
            sb.append(caption).append(t).append("\n");
        } else {
            sb.append(t).append("\n");
        }

        // 前 n 行
        StackTraceElement[] trace = t.getStackTrace();
        int limit = Math.min(n, trace.length);

        for (int i = 0; i < limit; i++) {
            sb.append("\tat ").append(trace[i]).append("\n");
        }

        // suppressed
        for (Throwable se : t.getSuppressed()) {
            appendStackTrace(sb, se, "\tSuppressed: ", n, dejaVu);
        }

        // cause
        Throwable cause = t.getCause();
        if (cause != null) {
            appendStackTrace(sb, cause, "Caused by: ", n, dejaVu);
        }
    }

    private static String nonNull(String s) {
        return s == null ? "" : s;
    }
}