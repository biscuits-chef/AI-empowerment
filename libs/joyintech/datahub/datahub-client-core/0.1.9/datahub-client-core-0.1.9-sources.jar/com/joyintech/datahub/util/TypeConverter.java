package com.joyintech.datahub.util;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: TypeConverter.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 20:14 <br/>
 * Description: 类型转化工具  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class TypeConverter {

    private TypeConverter(){

    }

    /**
     * 字符串转Integer
     */
    public static Integer toInteger(String value) {
        return toInteger(value, null);
    }

    public static Integer toInteger(String value, Integer defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        int result = NumberUtils.toInt(value.trim(), Integer.MIN_VALUE);
        return result != Integer.MIN_VALUE ? result : defaultValue;
    }

    /**
     * 字符串转Long
     */
    public static Long toLong(String value) {
        return toLong(value, null);
    }

    public static Long toLong(String value, Long defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        try {
            return NumberUtils.createLong(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * 字符串转Double
     */
    public static Double toDouble(String value) {
        return toDouble(value, null);
    }

    public static Double toDouble(String value, Double defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        double result = NumberUtils.toDouble(value.trim(), Double.NaN);
        return !Double.isNaN(result) ? result : defaultValue;
    }

    /**
     * 字符串转Float
     */
    public static Float toFloat(String value) {
        return toFloat(value, null);
    }

    public static Float toFloat(String value, Float defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        float result = NumberUtils.toFloat(value.trim(), Float.NaN);
        return !Float.isNaN(result) ? result : defaultValue;
    }

    /**
     * 字符串转Boolean
     */
    public static Boolean toBoolean(String value) {
        return toBoolean(value, null);
    }

    public static Boolean toBoolean(String value, Boolean defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        return BooleanUtils.toBooleanObject(value.trim());
    }

    /**
     * 字符串转BigDecimal
     */
    public static java.math.BigDecimal toBigDecimal(String value) {
        return toBigDecimal(value, null);
    }

    public static java.math.BigDecimal toBigDecimal(String value, java.math.BigDecimal defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;
        try {
            return new java.math.BigDecimal(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * 日期解析 - Commons Lang 3 没有内置，需要自定义
     */
    public static java.util.Date toDate(String value) {
        return toDate(value, null);
    }

    public static java.util.Date toDate(String value, java.util.Date defaultValue) {
        if (StringUtils.isBlank(value)) return defaultValue;

        String[] patterns = {
                "yyyy-MM-dd",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy/MM/dd",
                "yyyy/MM/dd HH:mm:ss",
                "yyyy-MM-dd HH:mm:ss.SSS",
                "yyyy/MM/dd HH:mm:ss.SSS"
        };

        for (String pattern : patterns) {
            try {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(pattern);
                sdf.setLenient(false); // 严格模式
                return sdf.parse(value.trim());
            } catch (Exception e) {
                // 继续尝试下一个格式
            }
        }
        return defaultValue;
    }
}
