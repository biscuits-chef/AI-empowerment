package com.joyintech.datahub.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.util.LocalConfigKeyUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 对应 conf.json 的 POJO
 *
 * @author ChenHao
 * @date 11/4/25 17:07
 */

public class ConfDto {

    private String version;
    private ObsConfig obs;
    private KafkaConfig kafka;
    private List<ProducerConfig> producerConfigs;
    private List<ConsumerConfig> consumerConfigs;

    public static class ObsConfig {

        private String endPoint;

        @JsonProperty("obs-w")
        private ObsDetail obsW;

        @JsonProperty("obs-r")
        private ObsDetail obsR;

        public String getEndPoint() {
            return endPoint;
        }

        public void setEndPoint(String endPoint) {
            this.endPoint = endPoint;
        }

        public ObsDetail getObsW() {
            return obsW;
        }

        public void setObsW(ObsDetail obsW) {
            this.obsW = obsW;
        }

        public ObsDetail getObsR() {
            return obsR;
        }

        public void setObsR(ObsDetail obsR) {
            this.obsR = obsR;
        }

        @Override
        public String toString() {
            return "ObsConfig{" +
                    "serviceUrl='" + endPoint + '\'' +
                    ", obsW=" + obsW +
                    ", obsR=" + obsR +
                    '}';
        }
    }

    public static class ObsDetail {
        private String ak;
        private String sk;
        private String bucketName;

        public String getAk() {
            return ak;
        }

        public void setAk(String ak) {
            this.ak = ak;
        }

        public String getSk() {
            return sk;
        }

        public void setSk(String sk) {
            this.sk = sk;
        }

        public String getBucketName() {
            return bucketName;
        }

        public void setBucketName(String bucketName) {
            this.bucketName = bucketName;
        }

        @Override
        public String toString() {
            return "ObsDetail{" +
                    "ak='******'" +
                    ", bucketName='" + bucketName + '\'' +
                    '}';
        }
    }

    public static class KafkaConfig {

        private KafkaProps kafkaProps;
        private InternalKafkaConfig internalKafkaConfig;

        public KafkaProps getKafkaProps() {
            return kafkaProps;
        }

        public void setKafkaProps(KafkaProps kafkaProps) {
            this.kafkaProps = kafkaProps;
        }

        public InternalKafkaConfig getInternalKafkaConfig() {
            return internalKafkaConfig;
        }

        public void setInternalKafkaConfig(InternalKafkaConfig internalKafkaConfig) {
            this.internalKafkaConfig = internalKafkaConfig;
        }

        public static class InternalKafkaConfig {
            private String fileTopic;
            private String logTopic;

            public String getFileTopic() {
                return fileTopic;
            }

            public void setFileTopic(String fileTopic) {
                this.fileTopic = fileTopic;
            }

            public String getLogTopic() {
                return logTopic;
            }

            public void setLogTopic(String logTopic) {
                this.logTopic = logTopic;
            }

            @Override
            public String toString() {
                return "InternalKafkaConfig{" +
                        "fileTopic='" + fileTopic + '\'' +
                        ", logTopic='" + logTopic + '\'' +
                        '}';
            }
        }

        public static class KafkaProps {
            @JsonProperty("bootstrap.servers")
            private String bootstrapServers;
            @JsonProperty("security.protocol")
            private String securityProtocol;
            @JsonProperty("sasl.mechanism")
            private String saslMechanism;

            private String username;

            private String password;

            @Override
            public boolean equals(Object o) {
                if (this == o) {
                    return true;
                }
                if (o == null || getClass() != o.getClass()) {
                    return false;
                }
                KafkaProps that = (KafkaProps) o;
                return Objects.equals(bootstrapServers, that.bootstrapServers)
                        && Objects.equals(securityProtocol, that.securityProtocol)
                        && Objects.equals(saslMechanism, that.saslMechanism)
                        && Objects.equals(username, that.username)
                        && Objects.equals(password, that.password);
            }

            @Override
            public int hashCode() {
                return Objects.hash(bootstrapServers, securityProtocol,
                        saslMechanism, username, password);
            }

            public String getBootstrapServers() {
                return bootstrapServers;
            }

            public void setBootstrapServers(String bootstrapServers) {
                this.bootstrapServers = bootstrapServers;
            }

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getSecurityProtocol() {
                return securityProtocol;
            }

            public void setSecurityProtocol(String securityProtocol) {
                this.securityProtocol = securityProtocol;
            }

            public String getSaslMechanism() {
                return saslMechanism;
            }

            public void setSaslMechanism(String saslMechanism) {
                this.saslMechanism = saslMechanism;
            }

            public String getPassword() {
                return password;
            }

            public void setPassword(String password) {
                this.password = password;
            }

            @Override
            public String toString() {
                return "KafkaProps{" +
                        "bootstrapServers='" + bootstrapServers + '\'' +
                        ", securityProtocol='" + securityProtocol + '\'' +
                        ", saslMechanism='" + saslMechanism + '\'' +
                        ", username='" + username + '\'' +
                        ", password='******'" +
                        '}';
            }
        }

        @Override
        public String toString() {
            return "KafkaConfig{" +
                    "kafkaProps=" + kafkaProps +
                    ", internalKafkaConfig=" + internalKafkaConfig +
                    '}';
        }
    }

    public static class ProducerConfig {
        private String dataType;
        private String dataCode;
        private String directory;
        private String filenameConventions;
        private String fileSeparator;
        private String topic;
        private String version;
        private String fileType;
        private Boolean storeInRoot;
        private String datePathMode;
        private String fileEncoding = DataHubConstant.DEFAULT_FILE_ENCODING;
        private String metaData;
        /**
         * 是否覆盖标识 Y:覆盖 N:不覆盖
         */
        private String overwriteFlag = DataHubConstant.Y_OR_N_N;

        /**
         * 是否跳过第一行
         */
        private String skipLineOneFlag = DataHubConstant.Y_OR_N_Y;

        public String getSkipLineOneFlag() {
            return skipLineOneFlag;
        }

        public void setSkipLineOneFlag(String skipLineOneFlag) {
            this.skipLineOneFlag = skipLineOneFlag;
        }

        public String getOverwriteFlag() {
            return overwriteFlag;
        }

        public void setOverwriteFlag(String overwriteFlag) {
            this.overwriteFlag = overwriteFlag;
        }

        public String getVersion() {
            return version;
        }

        public String getIntVer() {
            if (StringUtils.isEmpty(version)) {
                return dataCode;
            }
            return LocalConfigKeyUtil.generateKey(dataCode, version);
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getFilenameConventions() {
            return filenameConventions;
        }

        public void setFilenameConventions(String filenameConventions) {
            this.filenameConventions = filenameConventions;
        }

        public String getFileSeparator() {
            return fileSeparator;
        }

        public void setFileSeparator(String fileSeparator) {
            this.fileSeparator = fileSeparator;
        }

        public String getDataType() {
            return dataType;
        }

        public void setDataType(String dataType) {
            this.dataType = dataType;
        }

        public String getDataCode() {
            return dataCode;
        }

        public void setDataCode(String dataCode) {
            this.dataCode = dataCode;
        }

        public String getDirectory() {
            return directory;
        }

        public void setDirectory(String directory) {
            this.directory = directory;
        }

        public String getTopic() {
            return topic;
        }

        public void setTopic(String topic) {
            this.topic = topic;
        }

        public String getMetaData() {
            return metaData;
        }

        public void setMetaData(String metaData) {
            this.metaData = metaData;
        }

        public String getFileType() {
            return fileType;
        }

        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public Boolean getStoreInRoot() {
            return storeInRoot;
        }

        public void setStoreInRoot(Boolean storeInRoot) {
            this.storeInRoot = storeInRoot;
        }

        public String getDatePathMode() {
            return datePathMode;
        }

        public void setDatePathMode(String datePathMode) {
            this.datePathMode = datePathMode;
        }

        public String getFileEncoding() {
            if (StringUtils.isBlank(fileEncoding)) {
                return DataHubConstant.DEFAULT_FILE_ENCODING;
            }
            return fileEncoding;
        }

        public void setFileEncoding(String fileEncoding) {
            this.fileEncoding = fileEncoding;
        }

        @Override
        public String toString() {
            return "ProducerConfig{" +
                    "dataType='" + dataType + '\'' +
                    ", dataCode='" + dataCode + '\'' +
                    ", directory='" + directory + '\'' +
                    ", filenameConventions='" + filenameConventions + '\'' +
                    ", fileSeparator='" + fileSeparator + '\'' +
                    ", topic='" + topic + '\'' +
                    ", version='" + version + '\'' +
                    ", fileType='" + fileType + '\'' +
                    ", storeInRoot=" + storeInRoot +
                    ", datePathMode='" + datePathMode + '\'' +
                    ", fileEncoding='" + getFileEncoding() + '\'' +
                    ", metaData='" + metaData + '\'' +
                    ", overwriteFlag='" + overwriteFlag + '\'' +
                    '}';
        }
    }

    public static class ConsumerConfig {
        private String dataType;
        private String dataCode;
        private String version;
        private String fileSeparator;
        private String metaData;
        private String topic;
        private String fileType;
        private String fileEncoding = DataHubConstant.DEFAULT_FILE_ENCODING;
        private String failFast = DataHubConstant.Y_OR_N_Y;

        /**
         * 是否跳过第一行
         */
        private String skipLineOneFlag = DataHubConstant.Y_OR_N_Y;

        public String getSkipLineOneFlag() {
            return skipLineOneFlag;
        }

        public void setSkipLineOneFlag(String skipLineOneFlag) {
            this.skipLineOneFlag = skipLineOneFlag;
        }


        public String getIntVer() {
            if (StringUtils.isEmpty(version)) {
                return dataCode;
            }
            return dataCode + "@" + version;
        }


        public String getDataType() {
            return dataType;
        }

        public void setDataType(String dataType) {
            this.dataType = dataType;
        }

        public String getDataCode() {
            return dataCode;
        }

        public void setDataCode(String dataCode) {
            this.dataCode = dataCode;
        }

        public String getFileType() {
            return fileType;
        }

        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public String getFileEncoding() {
            if (StringUtils.isBlank(fileEncoding)) {
                return DataHubConstant.DEFAULT_FILE_ENCODING;
            }
            return fileEncoding;
        }

        public void setFileEncoding(String fileEncoding) {
            this.fileEncoding = fileEncoding;
        }

        public String getFailFast() {
            return failFast;
        }

        public void setFailFast(String failFast) {
            this.failFast = failFast;
        }

        public String getTopic() {
            return topic;
        }

        public void setTopic(String topic) {
            this.topic = topic;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getFileSeparator() {
            return fileSeparator;
        }

        public void setFileSeparator(String fileSeparator) {
            this.fileSeparator = fileSeparator;
        }

        public String getMetaData() {
            return metaData;
        }

        public void setMetaData(String metaData) {
            this.metaData = metaData;
        }

        @Override
        public String toString() {
            return "ConsumerConfig{" +
                    "dataType='" + dataType + '\'' +
                    ", dataCode='" + dataCode + '\'' +
                    ", version='" + version + '\'' +
                    ", fileSeparator='" + fileSeparator + '\'' +
                    ", metaData='" + metaData + '\'' +
                    ", topic='" + topic + '\'' +
                    ", fileType='" + fileType + '\'' +
                    ", fileEncoding='" + getFileEncoding() + '\'' +
                    ", errorInterrupt='" + failFast + '\'' +
                    '}';
        }
    }

    public ObsConfig getObs() {
        return obs;
    }

    public void setObs(ObsConfig obs) {
        this.obs = obs;
    }

    public KafkaConfig getKafka() {
        return kafka;
    }

    public void setKafka(KafkaConfig kafka) {
        this.kafka = kafka;
    }

    public List<ProducerConfig> getProducerConfigs() {
        return producerConfigs;
    }

    public List<ConsumerConfig> getConsumerConfigs() {
        return consumerConfigs;
    }

    public void setProducerConfigs(List<ProducerConfig> producerConfigList) {
        this.producerConfigs = producerConfigList;
    }

    public void setConsumerConfigs(List<ConsumerConfig> consumerConfigList) {
        this.consumerConfigs = consumerConfigList;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "ConfDto{" +
                "version='" + version + '\'' +
                ", obs=" + obs +
                ", kafka=" + kafka +
                ", producerConfigs=" + producerConfigs +
                ", consumerInfos=" + consumerConfigs +
                '}';
    }
}
