package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileSendNotify;
import com.joyintech.datahub.model.MsgHeader;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JsonUtil;
import com.joyintech.datahub.util.KafkaProducerHolder;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;

import java.nio.charset.StandardCharsets;

/**
 * 文件通知发送
 *
 * @author ChenHao
 * @date 11/11/25 09:07
 */
public class FileSendNotifyHelper {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(FileSendNotifyHelper.class);

    private static volatile FileSendNotifyHelper fileSendNotifyHelper;

    private FileSendNotifyHelper() {
    }

    public static FileSendNotifyHelper getInstance() {
        if (fileSendNotifyHelper == null) {
            synchronized (FileSendNotifyHelper.class) {
                if (fileSendNotifyHelper == null) {
                    fileSendNotifyHelper = new FileSendNotifyHelper();
                }
            }
        }
        return fileSendNotifyHelper;
    }

    public void notify(FileSendNotify notify, MsgHeader msgHeader) {
        KafkaProducer<String, String> producer = KafkaProducerHolder.getInstance().getProducer();

        // 发送通知逻辑
        ConfDto.ProducerConfig producerConfig = SendPurview
                .getInstance()
                .sendCheck(ConfHolder.getInstance().getDefFileNotifyDataCode(), ConfHolder.getInstance().getDefFileNotifyVersion());

        if (producerConfig == null) {
            log.error("FileSendNotifyHelper notify error, no producerConfig found for file notify.");
            return;
        }

        String formAppCode = notify.getFormAppCode();

        String topic = producerConfig.getTopic();
        String json = JsonUtil.toJson(notify);
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, json);

        String traceId = notify.getTraceId();
        String appCode = ConfHolder.getInstance().getAppCode();
        Header fromAppCodeHeader = new RecordHeader(DataHubConstant.APP_CODE_FROM, formAppCode.getBytes(StandardCharsets.UTF_8));
        Header sendFileTypeHeader = new RecordHeader(DataHubConstant.SEND_TYPE_FILE, DataHubConstant.Y_OR_N_Y.getBytes(StandardCharsets.UTF_8));
        Header traceHeader = new RecordHeader(DataHubConstant.TRACE_ID, traceId.getBytes(StandardCharsets.UTF_8));
        Header dataCodeHeader = new RecordHeader(DataHubConstant.DATA_CODE, (notify.getDataCode()).getBytes(StandardCharsets.UTF_8));
        Header versionHeader = new RecordHeader(DataHubConstant.VERSION, (notify.getDataVersion()).getBytes(StandardCharsets.UTF_8));
        Header dataDateHeader = new RecordHeader(DataHubConstant.DATA_DATE, (notify.getDataDate()).getBytes(StandardCharsets.UTF_8));
        Header skipLineFlagHeader = new RecordHeader(DataHubConstant.SKIP_LINE_ONE_FLAG, (msgHeader.getSkipLineOneFlag()).getBytes(StandardCharsets.UTF_8));
        String fileEncoding = notify.getFileEncoding() == null
                ? DataHubConstant.DEFAULT_FILE_ENCODING
                : notify.getFileEncoding();
        Header fileEncodingHeader = new RecordHeader(DataHubConstant.FILE_ENCODING, fileEncoding.getBytes(StandardCharsets.UTF_8));
        record.headers().add(fromAppCodeHeader);
        record.headers().add(sendFileTypeHeader);
        record.headers().add(traceHeader);
        record.headers().add(dataCodeHeader);
        record.headers().add(versionHeader);
        record.headers().add(dataDateHeader);
        record.headers().add(skipLineFlagHeader);
        record.headers().add(fileEncodingHeader);
        try {
            producer.send(record);
            log.info("FileSendNotifyHelper notify success, traceId: {}; appCode: {}; dataCode: {}; version: {}; topic: {}"
                    , traceId, appCode, ConfHolder.getInstance().getDefFileNotifyDataCode(), ConfHolder.getInstance().getDefFileNotifyVersion(), topic);
        } catch (Exception e) {
            log.error("FileSendNotifyHelper notify error, notify: {}; topic: {}", json, topic);
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "FileSendNotifyHelper notify error", e);
        }

    }

}
