package com.joyintech.datahub.refresh;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.crypto.AesCrypto;
import com.joyintech.datahub.conf.ConfigManager;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.DhClientHeartbeat;
import com.joyintech.datahub.model.ObsConfContent;
import com.joyintech.datahub.refresh.heart.VertxTransporter;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.IdUtil;
import com.joyintech.datahub.util.JarVersionUtil;
import com.joyintech.datahub.util.JsonUtil;
import com.joyintech.datahub.util.NetUtils;
import com.joyintech.datahub.util.ObsClientHolder;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import com.joyintech.datahub.util.TimeUtils;
import com.obs.services.ObsClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;


/**
 * 监听 conf 更新 topic，自动刷新系统； 默认实现类 spring项目不使用不注册即可
 *
 * @author ChenHao
 * @date 11/4/25 17:08
 */
public class ConfRefreshListener {

    private static final Logger log = LoggerFactory.getLogger(ConfRefreshListener.class);

    private static volatile ConfRefreshListener instance;

    private long initialDelay;

    private long period;

    private TimeUnit unit;
    private String objectKey;

    private ScheduledFuture<?> scheduledFuture;

    private final ReentrantLock refreshLock = new ReentrantLock();

    /**
     * 应用名称
     */
    private String serverName;

    /**
     * 连续失败次数
     */
    private int failureCount = 0;

    /**
     * 下一次允许执行的时间戳
     */
    private volatile long backoffUntil = 0;
    /**
     * 连续BACKOFF_THRESHOLD次失败后 再心跳间隔 分钟
     */
    private static final long BACKOFF_TIME = 2;

    /**
     * 日志限流，连续失败超过次数才记录
     */
    private static final int BACKOFF_THRESHOLD = 3;
    /**
     * 前BACKOFF_THRESHOLD次失败日志上传
     * 连续BACKOFF_THRESHOLD次无法同步server后 每失败10次 上传一次心跳异常日志
     */
    private static final int LOG_INTERVAL = 10;


    public ConfRefreshListener(String objectKey) {
        this.objectKey = objectKey;
        this.initialDelay = ConfHolder.getInstance().getInitialDelay();
        this.period = ConfHolder.getInstance().getPeriod();
        this.unit = ConfHolder.getInstance().getUnit();
        log.info("using default ConfRefreshListener params: initialDelay={}, period={}, unit={}",
                initialDelay, period, unit);

    }

    public ConfRefreshListener(String objectKey, long initialDelay, long period, TimeUnit unit) {
        this.initialDelay = initialDelay;
        this.period = period;
        this.unit = unit;
        this.objectKey = objectKey;
    }

    /**
     * 定时线程池
     */
    private ScheduledExecutorService scheduler;

    public static ConfRefreshListener getInstance(String objectKey, long initialDelay,
                                                  long period,
                                                  TimeUnit unit) {
        if (instance == null) {
            synchronized (ConfRefreshListener.class) {
                if (instance == null) {
                    instance = new ConfRefreshListener(objectKey, initialDelay, period, unit);
                }
            }
        }
        return instance;
    }

    public static ConfRefreshListener getInstance(String objectKey) {
        if (instance == null) {
            synchronized (ConfRefreshListener.class) {
                if (instance == null) {
                    instance = new ConfRefreshListener(objectKey);
                }
            }
        }
        return instance;
    }

    public static ConfRefreshListener getInstance() {
        if (instance == null) {
            throw new IllegalStateException("ConfRefreshListener is not initialized. Please use getInstance(String objectKey) or getInstance(String objectKey, long initialDelay, long period, TimeUnit unit) first.");
        }
        return instance;
    }

    /**
     * 启动监听器
     */
    public void start() {
        
        ObsConfContent obsConfContent = ConfHolder.getInstance().getObsConfContent();

        // 待上报的应用名称
        serverName = ConfHolder.getInstance().getServerName();
        log.info("ConfRefreshListener started with serverName: {}", serverName);

        scheduler = Executors.newSingleThreadScheduledExecutor();

        // 每 30 秒执行一次刷新任务
        scheduledFuture = scheduler.scheduleAtFixedRate(() -> {

//            long now = System.currentTimeMillis();
//            // Backoff 检查
//            if (now < backoffUntil) {
//                String nextTime = Instant.ofEpochMilli(backoffUntil)
//                        .atZone(ZoneId.systemDefault())
//                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
//                log.warn("[ConfRefreshListener] In BACKOFF mode, skip refresh. Next execute at {}", nextTime);
//                return;
//            }


            if (!refreshLock.tryLock()) {
                log.warn("[ConfRefreshListener] Refresh is already in progress. Skip this cycle.");
                return;
            }

            ConfDto confDto = null;
            try {
                boolean updated = checkAndRefresh();
                if (updated) {
                    log.info("[ConfRefreshListener] Checking for configuration updates...");
                    
                    ObsClient obsClient = ObsClientHolder.getInstance().getObsConfInternal();

                    // 流式下载，使用 try-with-resources 自动关闭 InputStream
                    try (InputStream input = obsClient.getObject(obsConfContent.getBucketName(), objectKey).getObjectContent();
                         ByteArrayOutputStream bos = new ByteArrayOutputStream(input.available() > 0 ? input.available() : 1024 * 8)) {

                        // 8KB 缓冲
                        byte[] buffer = new byte[8 * 1024];
                        int len;
                        while ((len = input.read(buffer)) != -1) {
                            bos.write(buffer, 0, len);
                        }

                        String s = bos.toString(StandardCharsets.UTF_8.name());
                        if (StringUtils.isBlank(s)) {
                            throw new DataHubException(DataHubErrorEnum.RESPONSE_DATA_ERROR, "Downloaded OBS content is empty");
                        }

                        String decrypt = null;
                        try {
                            decrypt = AesCrypto.decrypt(s, ConfHolder.getInstance().getConfKey());
                        } catch (Exception e) {
                            log.error("Decrypt configuration failed", e);
                            throw new RuntimeException(e);
                        }

                        if (StringUtils.isBlank(decrypt)) {
                            throw new DataHubException(DataHubErrorEnum.RESPONSE_DATA_ERROR, "Decrypted content is empty");
                        }

                        confDto = JsonUtil.fromJson(decrypt, ConfDto.class);
                        if (confDto == null) {
                            throw new DataHubException(DataHubErrorEnum.RESPONSE_DATA_ERROR, "Parsed configuration is null");
                        }

                        log.info("[ConfRefreshListener] Configuration updated successfully from OBS: bucketName={}; objectKey={}",
                                obsConfContent.getBucketName(), objectKey);
                        ConfigManager.getInstance().refresh(confDto);

                    }
                }

                // 成功一次就清零
                failureCount = 0;

                // 解除 BACKOFF
                backoffUntil = 0;

            } catch (Exception e) {
                String traceId = IdUtil.generateStrId();

                failureCount++;

                // 连续失败达到 Backoff 阈值
                if (failureCount >= BACKOFF_THRESHOLD) {
                    backoffUntil = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(BACKOFF_TIME);
                    String nextTime = Instant.ofEpochMilli(backoffUntil)
                            .atZone(ZoneId.systemDefault())
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    log.error("[ConfRefreshListener] Enter BACKOFF mode until {} due to {} consecutive errors", nextTime, failureCount);
                }

                // 日志限流：每 LOG_INTERVAL 次打印一次
                if (failureCount % LOG_INTERVAL == 0 || failureCount <= BACKOFF_THRESHOLD) {
                    log.error("[ConfRefreshListener] Error while checking for configuration updates; traceId = {} bucketName={}; objectKey={}",
                            traceId, obsConfContent.getBucketName(), objectKey, e);
                    DhcLog.getInstance().error(
                            traceId,
                            LogType.INTERNAL_SDK,
                            TimeUtils.today(),
                            "dataHub-heartbeat-refresh",
                            ConfHolder.getInstance().getConfDto().getVersion(),
                            "检查配置更新时出错; bucketName=" + obsConfContent.getBucketName() + "; objectKey=" + objectKey,
                            0L,
                            StackTraceFormatUtil.getStackTrace(e)
                    );
                }
            } finally {
                refreshLock.unlock();
            }
        }, initialDelay, period, unit);
    }

    /**
     * 停止监听
     */
    public static synchronized void shutdown() {
        try {
            // 1. 先取消任务
            if (instance.scheduledFuture != null) {
                // 尝试中断正在运行的任务
                boolean cancelled = instance.scheduledFuture.cancel(false);
                log.info("ConfRefreshListener scheduled task cancelled: {}", cancelled);
                instance.scheduledFuture = null;
            }
            instance.scheduler.shutdown();
        } catch (Exception e) {
            log.error("Error shutting down ConfRefreshListener: ", e);
        }
    }

    /**
     * 待确认心跳传输格式
     * <p>
     * 检查并刷新配置
     */
    private boolean checkAndRefresh() {
        Map<String, String> allCollectedVersions = JarVersionUtil.getAllCollectedVersions();
        String sdkVersion = JsonUtil.toJson(allCollectedVersions);

        DhClientHeartbeat build = DhClientHeartbeat.builder()
                .setAppCode(ConfHolder.getInstance().getAppCode())
                .setHeartbeatTime(TimeUtils.now())
                .setSdkVersion(sdkVersion)
                .setServerAddress(NetUtils.getLocalHost())
                .setServerName(serverName)
                .build();

        VertxTransporter transporter = VertxTransporter.getInstance();

        String response;
        try {
            response = transporter.post(ConfHolder.getInstance().getUrl(), build, String.class)
                    .toCompletableFuture()
                    .get();
        } catch (InterruptedException e) {
            log.error("[ConfRefreshListener] Interrupted while checking for configuration updates", e);
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            log.error("[ConfRefreshListener] Execution error while checking for configuration updates", e);
            throw new RuntimeException(e);
        }

        if (response == null || response.isEmpty()) {
            log.warn("[ConfRefreshListener] Empty response received while checking for configuration updates");
            return false;
        }

        String version;
        try {
            io.vertx.core.json.JsonObject json = new io.vertx.core.json.JsonObject(response);
            version = json.getJsonObject("data").getString("version");
        } catch (Exception e) {
            // 无法解析到version
            log.error("[ConfRefreshListener] Error parsing response JSON while checking for configuration updates", e);
            return false;
        }

        if (ConfHolder.getInstance().getConfDto().getVersion().equalsIgnoreCase(version)) {
            log.debug("[ConfRefreshListener] No configuration update needed; current version is up-to-date: {}",
                    ConfHolder.getInstance().getConfDto().getVersion());
            return false;
        }

        log.info("[ConfRefreshListener] Configuration update detected; old version: {}, new version: {}",
                ConfHolder.getInstance().getConfDto().getVersion(), version);
        return true;
    }
}
