package com.joyintech.datahub.file;

import com.joyintech.datahub.enums.FileFormat;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: EnhancedLineConverter.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 16:29 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class EnhancedLineConverter<T> {

    private static final Logger log = LoggerFactory.getLogger(EnhancedLineConverter.class);
    /**
     * 字段提取器
     */
    private final FieldExtractor<T> fieldExtractor;
     /**
     * 分隔符
     */
    private final String delimiter ;
    /**
     * 文本限定符
     */
    private static final char TEXT_QUALIFIER = '"';

    public EnhancedLineConverter(FieldExtractor<T> fieldExtractor,
                                 FileFormat fileFormat, String delimiter) {
        this.fieldExtractor = fieldExtractor;
        if(fileFormat == FileFormat.CSV){
            if(StringUtils.isBlank(delimiter)){
                delimiter = ",";
            }else{
                if(delimiter.length() > 1){
                    log.warn("csv分隔符长度不能大于1，开始使用默认,进行分割");
                    delimiter = ",";
                }
            }
        }
        this.delimiter = delimiter;
    }

    public String convertToLine(T data) {
        List<String> fields = fieldExtractor.extractFields(data);
        return formatLine(fields);
    }

    /**
     *功能描述: 转化fields 为一行数据
     * 2026-01-04 ghostp 修改
     */
    private String formatLine(List<String> fields) {
        return formatCsvLine( fields);
    }

    /**
     * 核心：CSV格式自动转义处理
     */
    private String formatCsvLine(List<String> fields) {
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) {
                line.append(delimiter);
            }

            String field = fields.get(i);
            if (field == null) {
                field = "";
            }
            if (field.contains("\n") || field.contains("\r")) {
               field = field.replace("\n", "\\n").replace("\r", "\\r");
            }

            // 判断是否需要引号包围
            boolean needsQuotes = needsQuotes(field);

            if (needsQuotes) {
                line.append(TEXT_QUALIFIER);
                line.append(escapeField(field));
                line.append(TEXT_QUALIFIER);
            } else {
                line.append(field);
            }
        }

        return line.toString();
    }

    /**
     * 判断字段是否需要引号包围
     */
    private boolean needsQuotes(String field) {
        // 包含以下情况需要引号：
        return field.contains(delimiter) ||    // 包含分隔符
                field.contains(",") || //特殊,处理
                field.contains(String.valueOf(TEXT_QUALIFIER)) || // 包含引号本身
                field.isEmpty();                                // 空字段（可选）
    }

    /**
     * 转义字段内容：将字段内的引号转义为两个引号
     */
    private String escapeField(String field) {
        // CSV规则：字段内的引号用两个引号表示
        return field.replace(
                String.valueOf(TEXT_QUALIFIER),
                TEXT_QUALIFIER + String.valueOf(TEXT_QUALIFIER)
        );
    }


}
