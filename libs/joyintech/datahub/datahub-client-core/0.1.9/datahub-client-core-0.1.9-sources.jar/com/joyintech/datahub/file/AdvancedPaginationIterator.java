package com.joyintech.datahub.file;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Function;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AdvancedPaginationIterator.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/17 14:57 <br/>
 * Description: 带条件查询迭代器  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AdvancedPaginationIterator<T> implements Iterator<T> {
    private final int pageSize;
    private final Function<QueryBuilder<T>, List<T>> dataLoader;
    private final QueryBuilder<T> queryBuilder;
    private int currentPage = 1;
    private List<T> currentBatch;
    private int currentIndex = 0;
    private boolean hasMore = true;

    public AdvancedPaginationIterator(int pageSize, QueryBuilder<T> queryBuilder,
                                      Function<QueryBuilder<T>, List<T>> dataLoader) {
        this.pageSize = pageSize;
        this.queryBuilder = queryBuilder;
        this.dataLoader = dataLoader;
        loadNextPage();
    }

    private void loadNextPage() {

        // 每次创建新的 QueryBuilder 或复制基础条件，并设置当前分页
        QueryBuilder<T> currentQuery = copyQueryBuilder(queryBuilder)
                .page(currentPage, pageSize);
        currentBatch = dataLoader.apply(currentQuery);
        currentIndex = 0;
        currentPage++;

        if (currentBatch == null || currentBatch.isEmpty()) {
            hasMore = false;
            currentBatch = Collections.emptyList();
        }
    }

    private QueryBuilder<T> copyQueryBuilder(QueryBuilder<T> original) {
        QueryBuilder<T> copy = new QueryBuilder<T>();
        // 复制条件
        original.getConditions().forEach(copy::addCondition);
        // 复制排序
        if (original.getOrderBy() != null) {
            copy.orderBy(original.getOrderBy(), original.isAscending());
        }
        return copy;
    }

    @Override
    public boolean hasNext() {
        if (currentIndex < currentBatch.size()) {
            return true;
        }
        if (!hasMore) {
            return false;
        }
        loadNextPage();
        return currentIndex < currentBatch.size();
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return currentBatch.get(currentIndex++);
    }
}
