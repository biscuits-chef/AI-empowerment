package com.joyintech.datahub.model;


import java.io.Serializable;

/**
 * 地址
 *
 * @author 
 * @since 2022/12/31
 */
public class Address implements Serializable {
    private String host;
    private int port;

    public String toFullAddress() {
        return toFullAddress(host, port);
    }

    public static Address fromIpv4(String ipv4) {
        String[] split = ipv4.split(":");
        return Address.builder()
                .setHost(split[0])
                .setPort(Integer.parseInt(split[1])).build();
    }

    public static String toFullAddress(String host, int port) {
        return String.format("%s:%d", host, port);
    }

    @Override
    public String toString() {
        return "Address{" +
                "host='" + host + '\'' +
                ", port=" + port +
                '}';
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public static class Builder {
        private String host;
        private int port;

        public Builder setHost(String host) {
            this.host = host;
            return this;
        }

        public Builder setPort(int port) {
            this.port = port;
            return this;
        }

        public Address build() {
            Address address = new Address();
            address.setHost(host);
            address.setPort(port);
            return address;
        }
    }
    
    public static Address.Builder builder() {
        return new Address.Builder();
    }
}
