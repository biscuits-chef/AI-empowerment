package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.enums.FileFormat;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.exception.NoAccessException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileGenStats;
import com.joyintech.datahub.model.StreamSenderDTO;
import com.joyintech.datahub.obs.ObsClientHandler;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.*;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.PutObjectResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: StreamFileSender.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 14:32 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 * 从0.1.1版本开始弃用，使用FileDataSender和FileSender--弃用原因：无法处理大文件
 */
@Deprecated
public class StreamFileSender extends FileAbstractSender{
    private static final Logger log = LoggerFactory.getLogger(StreamFileSender.class);
    private static final StreamFileSender instance;
    private StreamFileSender(){}

    static {
        try {
            instance = new StreamFileSender();
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,"初始化StreamFileSender异常",e);
        }
    }
    public static StreamFileSender getInstance(){
        return instance;
    }

    /**
     * 流式数据发送入口
     * @param fileDate 业务日期格式为：yyyy-mm-dd
     * @param streamSenderDTO 流式数据发送参数
     * @return 发送结果
     */
    public SendResult sendData(String fileDate,StreamSenderDTO streamSenderDTO) throws DataHubException,NoAccessException {
        if(StringUtils.isBlank(fileDate)){
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"业务日期不能为空");
        }
        if(streamSenderDTO == null){
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"streamSenderDTO不能为空");
        }
        streamSenderDTO.validate();
        ConfDto.ProducerConfig producerConfig = SendPurview.getInstance().sendCheck(streamSenderDTO.getDataCode(),
                streamSenderDTO.getDataVersion());
        if (StringUtils.equalsIgnoreCase(FileFormat.JSON.name(), producerConfig.getFileType())) {
            return new SendResult("500", "JSON 文件类型必须使用 FileSender 发送", false);
        }
        String objectKey;
        String traceId = IdUtil.generateStrId();
        if(StringUtils.isNotBlank(streamSenderDTO.getFileName())) {
            checkFileType(streamSenderDTO.getFileName(), producerConfig);
            objectKey = FileUtil.objectKeyBuilder(producerConfig.getDirectory(), streamSenderDTO.getFileName(),
                    producerConfig.getStoreInRoot(), producerConfig.getDatePathMode());
            if(org.apache.commons.codec.binary.StringUtils.equals(DataHubConstant.Y_OR_N_N,producerConfig.getOverwriteFlag() )){
                if(ObsClientHandler.objectKeyExists(ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName() , objectKey)){
                    DhcLog.getInstance().warn(traceId,
                            LogType.FILE_PROCESSING,
                            fileDate,
                            producerConfig.getDataCode(),
                            producerConfig.getVersion(),
                            "配置文件不覆盖，文件名相同：",0L,
                            streamSenderDTO.getFileName() );
                    return SendResult.failure("500", "配置不可覆盖，但文件名:"+streamSenderDTO.getFileName()+"已存在");
                }

            }
        }else{
            objectKey = FileUtil.simpleFilename(streamSenderDTO.getDataCode(),streamSenderDTO.getDataVersion(),
                    producerConfig.getDirectory(),FileFormat.valueOf(producerConfig.getFileType().toUpperCase()),
                    producerConfig.getStoreInRoot(), producerConfig.getDatePathMode());
        }
        long startTime = System.currentTimeMillis();
        PutObjectRequest putRequest = new PutObjectRequest(
                ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(),
                objectKey,
                streamSenderDTO.getStream()
        );

        FileGenStats fgs = new FileGenStats();
        fgs.setTotalSize(streamSenderDTO.getFileSize());
        fgs.setLineCount(streamSenderDTO.getRowCount());
        OBSMetadataUtil.applyMetadata(streamSenderDTO.getDataCode(),streamSenderDTO.getDataVersion(),traceId,putRequest);
        try {
            PutObjectResult result = ObsClientHandler.putObject(putRequest);
            FileSenderComplete.sendFileSendCompleteMsg(fileDate,streamSenderDTO.getDataCode(),
                    streamSenderDTO.getDataVersion(), traceId, fgs, result.getEtag(), result.getObjectKey(),
                    result.getBucketName(), producerConfig.getSkipLineOneFlag(), producerConfig.getFileEncoding());
            long endTime = System.currentTimeMillis();
            DhcLog.getInstance().info(traceId,
                    LogType.FILE_PROCESSING,
                    fileDate,
                    streamSenderDTO.getDataCode(),
                    streamSenderDTO.getDataVersion(),
                    "文件发送成功", endTime - startTime, "文件发送成功，文件名：" + streamSenderDTO.getFileName());
            return new SendResult("200", "发送成功", true, buildFileResultInfo(result, fgs));
        }catch(Throwable e){//NOSONAR
            long endTime = System.currentTimeMillis();
            log.error("发送异常",e);
            DhcLog.getInstance().error(traceId,
                    LogType.FILE_PROCESSING,
                    fileDate,
                    streamSenderDTO.getDataCode(),
                    streamSenderDTO.getDataVersion(),
                    "文件发送异常", endTime - startTime, "文件发送异常，文件名：" + streamSenderDTO.getFileName() + "，异常信息：" , StackTraceFormatUtil.getStackTrace(e));
            return new SendResult("500", "流式文件发送异常"+e.getMessage(), false);
        }
    }

}
