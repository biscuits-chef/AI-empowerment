package com.joyintech.datahub.delayed;

import java.io.File;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * @author ChenHao
 * @date 1/15/26 20:25
 */
public class DelayedFile implements Delayed {

    private final File file;
    private final long deleteAt;

    public DelayedFile(File file, long delayMs) {
        this.file = file;
        this.deleteAt = System.currentTimeMillis() + delayMs;
    }

    public File getFile() {
        return file;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long diff = deleteAt - System.currentTimeMillis();
        return unit.convert(diff, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        return Long.compare(this.deleteAt, ((DelayedFile) o).deleteAt);
    }
}