package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.model.AttachConFile;

import java.util.List;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhAttachListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 17:11 <br/>
 * Description: 附件类消息监听接口 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhAttachListener<T> extends DhGenericTypeListener<T> {

    /**
     * 业务具体处理消息
     */
    void onProcess(T msg, List<AttachConFile> attachConFiles) throws RuntimeException;
}
