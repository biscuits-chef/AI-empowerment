package com.joyintech.datahub.conf;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.kafka.ConsumerWrapper;
import com.joyintech.datahub.log.handler.DhcLogHandler;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.purview.ConsumerPurview;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.KafkaProducerHolder;
import com.joyintech.datahub.util.LocalConfigKeyUtil;
import com.joyintech.datahub.util.ObsClientHolder;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.security.auth.SecurityProtocol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * ConfigManager: Producer/Consumer 注册
 *
 * @author chenhao
 */
public class ConfigManager {

    private static final Logger log = LoggerFactory.getLogger(ConfigManager.class);

    private static volatile ConfigManager instance;

    private static AtomicInteger CLIENT_ID_SEQ;

    /**
     * 初次启动时赋值
     */
    private ConfDto confDto;

    private ReadWriteLock rwLock;

    private ExecutorService executor;

    private ConfigManager() {
        CLIENT_ID_SEQ = new AtomicInteger(1);
        rwLock = new ReentrantReadWriteLock();
        this.executor = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r);
            t.setName("dh-kafka-consumer-thread-" + t.getId());
            return t;
        });
    }

    public static ConfigManager getInstance(ConfDto confDto) {
        ConfigManager manager = getInstance();
        manager.confDto = confDto;
        return manager;
    }


    /**
     * 获取单例实例（DCL）
     */
    public static ConfigManager getInstance() {
        if (instance == null) {
            synchronized (ConfigManager.class) {
                if (instance == null) {
                    instance = new ConfigManager();
                }
            }
        }
        return instance;
    }

    /**
     * 启动执行 读取confDto中的配置，刷新生产者和消费者
     */
    public void start() {
        reloadProducer(confDto.getProducerConfigs(), confDto.getKafka().getKafkaProps());
        log.info("[ConfigManager] Refreshing consumers with new configuration.");
        reloadConsumer(confDto.getConsumerConfigs(), confDto.getKafka().getKafkaProps());

        // 日志上传producer、文件通知[consumer/producer]
        loadInternalConfiguration(confDto);

        DhcLogHandler.getInstance();

        printLoggerInfo();
    }

    private void printLoggerInfo() {
        Map<String, ConfDto.ProducerConfig> producerConfigMap = SendPurview.getInstance().getProducerConfigMap();
        log.info("===============producers===============");
        log.info("[ConfigManager] Current producers. Total producers: {}", producerConfigMap.size());
        log.info("[ConfigManager] Current complete. Producers: {}", producerConfigMap.keySet());
        log.info("[ConfigManager] Current complete. Producers: {}", producerConfigMap);
        log.info("===============producers===============");

        ConsumerManager consumerManager = ConsumerManager.getInstance();
        log.info("===============consumers===============");
        Set<String> consumerThreadKeys = consumerManager.getConsumerThreadKeys();
        log.info("[ConfigManager] Current consumer. Total producers: {}", consumerThreadKeys.size());
        log.info("[ConfigManager] Current complete. Producers: {}", consumerThreadKeys);
        log.info("===============consumers===============");
    }

    /**
     * 刷新 Kafka 配置
     *
     * @param newConf 新的配置对象
     */
    public void refresh(ConfDto newConf) {
        reloadProducer(newConf.getProducerConfigs(), newConf.getKafka().getKafkaProps());
        reloadConsumer(newConf.getConsumerConfigs(), newConf.getKafka().getKafkaProps());
        loadInternalConfiguration(newConf);

        DhcLogHandler.getInstance().refreshConfig(
                newConf.getKafka().getInternalKafkaConfig().getLogTopic()
        );

        // 最后更新全局配置
        ConfHolder.getInstance().getConfDto().setVersion(newConf.getVersion());
        this.confDto = newConf;
        ConfHolder.getInstance().init(newConf);

        printLoggerInfo();
    }

    /**
     * 初始化所有生产者
     */
    public void initProducers() {
        if (confDto.getProducerConfigs() == null) {
            log.warn("[ConfigManager] No publish interfaces configured.");
            return;
        }
        Properties props = getProducersProp(confDto.getKafka().getKafkaProps());
        // 注册producer
        KafkaProducerHolder.getInstance().init(new KafkaProducer<>(props), confDto.getKafka().getKafkaProps());
        SendPurview.getInstance().reloadProducer(confDto.getProducerConfigs());
    }

    private Properties getProducersProp(ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaProps.getBootstrapServers());
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        // 重试配置 - 核心配置 todo 提供可选配置
        // 重试次数
        props.put(ProducerConfig.RETRIES_CONFIG, 3);
        // 重试间隔1秒
        props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, 1000);
        // 请求超时时间
        props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, 30000);
        // 交付超时时间
        props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 60000);

        // 其他推荐配置
        // 确保消息持久化
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        // 启用幂等性
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        // 保证顺序
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1);
        setSaslConfig(kafkaProps.getSecurityProtocol(), kafkaProps.getSaslMechanism(), kafkaProps.getUsername(), kafkaProps.getPassword(), props);
        return props;
    }

    /**
     * 初始化/更新 通用 以传入为准 刷新配置
     *
     * @param producerInterfaces
     * @param kafkaProps
     */
    public void reloadProducer(List<ConfDto.ProducerConfig> producerInterfaces, ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        // 初次加载必须初始化producer，后续刷新判断purview
        if (CollectionUtils.isEmpty(producerInterfaces) && !SendPurview.getInstance().getProducerConfigMap().isEmpty()) {
            // 只清空purview，producer 保留发日志
            SendPurview.getInstance().clearProducerMappings();
            log.warn("[ConfigManager] No publish interfaces configured.");
            return;
        }

        SendPurview.getInstance().reloadProducer(producerInterfaces);

        if (Objects.equals(kafkaProps, KafkaProducerHolder.getInstance().getKafkaProps())) {
            log.info("[ConfigManager] Kafka bootstrap servers unchanged, skipping producer reload.");
        } else {
            // 此处需传入新的 更新连接地址
            Properties props = getProducersProp(kafkaProps);
            KafkaProducerHolder.getInstance().reload(new KafkaProducer<>(props), kafkaProps);
        }

    }

    /**
     * private 方法 锁在上层
     *
     * @param consumerConfigs
     */
    private void setConfDtoConsumers(List<ConfDto.ConsumerConfig> consumerConfigs) {
        ConsumerPurview.getInstance().consumerConfigRefresh(consumerConfigs);
    }

    /**
     * 初始化/更新 消费者 以传入为准 刷新配置
     *
     * @param consumerInterfaces
     */
    public void reloadConsumer(List<ConfDto.ConsumerConfig> consumerInterfaces, ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        if (CollectionUtils.isEmpty(consumerInterfaces)) {
            // 清除producer+purview
            ConsumerManager.getInstance().closeAllConsumerThreads();
            ConsumerPurview.getInstance().clearConsumerConfig();
            log.warn("[ConfigManager] No consumer interfaces configured.");
            return;
        }
        rwLock.writeLock().lock();
        try {
            ConsumerManager consumerManager = ConsumerManager.getInstance();
            // 刷新configMap（本地维护全删全插）处理consumer config
            setConfDtoConsumers(consumerInterfaces);

            // 以下为寻找差异 刷新 threadMap（差异比对停止/启动）
            // 将新配置转为 Map（key 为 topic）
            Map<String, ConfDto.ConsumerConfig> newMap = new HashMap<>();
            for (ConfDto.ConsumerConfig conf : consumerInterfaces) {
                if (isFileInterfaceType(conf.getDataType())) {
                    // 跳过文件类型的配置
                    log.info("[ConfigManager] Skipping file type consumer config: {}", conf);
                    continue;
                }
                newMap.put(conf.getTopic(), conf);
            }
            // 处理consumer thread
            Set<String> consumerThreadKeys = consumerManager.getConsumerThreadKeys();

            // 1️⃣ 找出需要停止的 consumer（旧的有、新的没有）
            Set<String> toStop = new HashSet<>(consumerThreadKeys);
            toStop.removeAll(newMap.keySet());

            // 2️⃣ 找出需要新增的 consumer（新的有、旧的没有）
            Set<String> toAdd = new HashSet<>(newMap.keySet());
            toAdd.removeAll(consumerThreadKeys);

            // 3️⃣ 停止被移除的 consumer
            for (String oldKey : toStop) {
                String fileTopic = ConfHolder.getInstance().getConfDto().getKafka().getInternalKafkaConfig().getFileTopic();
                if (oldKey.equalsIgnoreCase(fileTopic)) {
                    // 文件通知的thread不在这里处理
                    continue;
                }
                ConsumerWrapper wrapper = consumerManager.removeConsumerThread(oldKey);
                if (wrapper != null) {
                    try {
                        wrapper.close();
                        log.info("[ConfigManager] Stopped consumer: {}", oldKey);
                    } catch (Exception e) {
                        log.warn("[ConfigManager] Failed to stop consumer {}: {}", oldKey, e.getMessage());
                    }
                }
            }

            // 4️⃣ 已存在的 consumer 保持不变
            for (String key : newMap.keySet()) {
                if (consumerManager.containsConsumerThread(key)) {
                    log.info("[ConfigManager] Consumer {} already running, skipped reload.", key);
                }
            }

            // 5️⃣ 启动新增的 consumer
            for (String newKey : toAdd) {
                ConfDto.ConsumerConfig conf = newMap.get(newKey);
                try {
                    String topic = conf.getTopic();
                    Properties props = getProperties(kafkaProps);
                    log.info("[ConfigManager] Reloading Consumer: 【{}】；", conf);
                    ConsumerWrapper consumer = new ConsumerWrapper(props, conf.getTopic(), executor);
                    consumerManager.putConsumerThread(topic, consumer);
                    log.info("[ConfigManager] Started new consumer for: {}", newKey);
                } catch (Exception e) {
                    log.error("[ConfigManager] Failed to start consumer {}: {}", newKey, e.getMessage(), e);
                }
            }
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    /**
     * 启动指定 consumer
     */
    public void startConsumer(String dataCode, String version, String topic, ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        ConsumerManager consumerManager = ConsumerManager.getInstance();
        String dcv = LocalConfigKeyUtil.generateKey(dataCode, version);
        ConfDto.ConsumerConfig sub = findConsumerConfig(dcv);
        if (sub == null) {
            log.warn("[ConfigManager] Cannot start consumer: {}, config or listener missing;configInfo is null",
                    dcv);
            return;
        }
        if (consumerManager.containsConsumerThread(topic)) {
            log.warn("[ConfigManager] Consumer {} already running. current consumer topics [{}]", topic, consumerManager.getConsumerThreadKeys());
            return;
        }
        Properties props = getProperties(kafkaProps);
        ConsumerWrapper consumer = new ConsumerWrapper(props, sub.getTopic(), executor);
        consumerManager.putConsumerThread(topic, consumer);
        log.info("[ConfigManager] Started consumer {} on topic {}", dcv, sub.getTopic());

    }

    private Properties getProperties(ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaProps.getBootstrapServers());
        props.put("group.id", ConfHolder.getInstance().getAppCode() + DataHubConstant.GROUP_SEPARATOR + ConfHolder.getInstance().getServerName());
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("auto.offset.reset", "latest");
        props.put("enable.auto.commit", "false");

        // 给每个 Consumer 一个唯一但规律的 client.id
        String clientId = ConfHolder.getInstance().getAppCode() + "-consumer-" + CLIENT_ID_SEQ.getAndIncrement();
        props.put("client.id", clientId);

        // ---------- SASL 认证配置 ----------
        setSaslConfig(kafkaProps.getSecurityProtocol(), kafkaProps.getSaslMechanism(), kafkaProps.getUsername(), kafkaProps.getPassword(), props);
        return props;
    }

    /**
     * 停止指定 consumer
     */
    public void stopConsumer(String dcv) {
        ConsumerWrapper wrapper = ConsumerManager.getInstance().removeConsumerThread(dcv);
        if (wrapper != null) {
            log.info("[ConfigManager] Stopping consumer for {}...", dcv);
            wrapper.close();
            log.info("[ConfigManager] Consumer {} stopped...", dcv);
        } else {
            log.warn("[ConfigManager] Consumer {} not found...", dcv);
        }

    }

    private ConfDto.ConsumerConfig findConsumerConfig(String dcv) {
        if (confDto.getConsumerConfigs() == null) {
            return null;
        }
        for (ConfDto.ConsumerConfig sub : confDto.getConsumerConfigs()) {
            if (dcv.equalsIgnoreCase(sub.getIntVer())) {
                return sub;
            }
        }
        return null;
    }

    /**
     * 内置配置加载
     *
     * @param confDto
     */
    private void loadInternalConfiguration(ConfDto confDto) {
        loadInternalConsumer(confDto);
        loadInternalProducer(confDto);

        // 以下多次调用数据覆盖

        // 日志上传生产者配置
        // 在purview注册一个默认的日志上传生产者 可以走通用判断逻辑无需特殊发送处理
        ConfDto.ProducerConfig logProducer = new ConfDto.ProducerConfig();
        logProducer.setDataCode(ConfHolder.getInstance().getDefLogUploadDataCode());
        logProducer.setVersion(ConfHolder.getInstance().getDefLogUploadVersion());
        logProducer.setTopic(confDto.getKafka().getInternalKafkaConfig().getLogTopic());
        SendPurview.getInstance().addProducerMapping(
                ConfHolder.getInstance().getDefLogUploadDataCode(),
                ConfHolder.getInstance().getDefLogUploadVersion(),
                logProducer);
        log.info("[ConfigManager] Internal log upload producer configured on topic: {}", logProducer.getTopic());

        // 文件通知生产者配置
        // 在purview注册一个默认的文件通知生产者 可以走通用判断逻辑无需特殊发送处理
        ConfDto.ProducerConfig fileProducer = new ConfDto.ProducerConfig();
        fileProducer.setDataCode(ConfHolder.getInstance().getDefFileNotifyDataCode());
        fileProducer.setVersion(ConfHolder.getInstance().getDefFileNotifyVersion());
        fileProducer.setTopic(confDto.getKafka().getInternalKafkaConfig().getFileTopic());
        SendPurview.getInstance().addProducerMapping(
                ConfHolder.getInstance().getDefFileNotifyDataCode(),
                ConfHolder.getInstance().getDefFileNotifyVersion(),
                fileProducer);

        log.info("[ConfigManager] Internal configurations loaded: log producer topic = {}, file notification producer topic = {}",
                logProducer.getTopic(), fileProducer.getTopic());
    }

    /**
     * 内置生产者加载/停止
     * 起停 obsW client
     *
     * @param confDto
     */
    private void loadInternalProducer(ConfDto confDto) {
        List<ConfDto.ProducerConfig> producerConfigs = confDto.getProducerConfigs();

        boolean hasFileProducer = Optional.ofNullable(producerConfigs)
                .orElse(Collections.emptyList())
                .stream()
                .anyMatch(pc -> isFileInterfaceType(pc.getDataType()));

        if (hasFileProducer && ObsClientHolder.getInstance().getWriter() == null) {
            // v1 没有obs生产者 v2 有obs生产者
            ObsClientHolder.getInstance().startObsWriterClient(confDto.getObs());
            log.info("[ConfigManager] OBS file upload producer detected, OBS Writer client remains active.");
            return;
        }

        if (!hasFileProducer) {
            // v2 有obs生产者 v3 没有生产者 停止
            ObsClientHolder.getInstance().closeObsWriter();
            log.info("[ConfigManager] No OBS file upload producer detected, OBS Writer client has been shut down.");
        }
    }

    /**
     * 内置消费者加载/停止
     * 起停 kafka consumer file thread
     *
     * @param confDto
     */
    private void loadInternalConsumer(ConfDto confDto) {
        ConsumerManager consumerManager = ConsumerManager.getInstance();

        boolean hasFileConsumer = Optional.ofNullable(confDto.getConsumerConfigs())
                .orElse(Collections.emptyList())
                .stream()
                .anyMatch(cc -> isFileInterfaceType(cc.getDataType()));

        // kafka 连接/认证参数变更，或 fileTopic 变更时，需要重启 fileConsumerThread（用旧 topic 停止）
        if (this.confDto != null) {
            String oldFileTopic = this.confDto.getKafka().getInternalKafkaConfig().getFileTopic();
            String newFileTopic = confDto.getKafka().getInternalKafkaConfig().getFileTopic();
            boolean kafkaPropsChanged = !Objects.equals(confDto.getKafka().getKafkaProps(), this.confDto.getKafka().getKafkaProps());
            boolean fileTopicChanged = !Objects.equals(newFileTopic, oldFileTopic);
            if (kafkaPropsChanged || fileTopicChanged) {
                consumerManager.stopConsumerThread(oldFileTopic);
            }
        }

        // v1 没有obs消费者 v2 有obs消费者 启动
        if (hasFileConsumer && !consumerManager.containsConsumerThread(confDto.getKafka().getInternalKafkaConfig().getFileTopic())) {
            Properties props = getProperties(confDto.getKafka().getKafkaProps());
            ConsumerWrapper consumer = new ConsumerWrapper(props, confDto.getKafka().getInternalKafkaConfig().getFileTopic(), executor);
            consumerManager.putConsumerThread(confDto.getKafka().getInternalKafkaConfig().getFileTopic(), consumer);

            log.info("[ConfigManager] Internal file notification consumer configured on topic: {}",
                    confDto.getKafka().getInternalKafkaConfig().getFileTopic());

            return;
        }

        if (!hasFileConsumer) {
            // v2 有obs消费者 v3 没有消费者 停止
            consumerManager.stopConsumerThread(confDto.getKafka().getInternalKafkaConfig().getFileTopic());
        }
    }

    private static boolean isFileInterfaceType(String dataType) {
        return DataHubConstant.INTERFACE_TYPE_OBS.equalsIgnoreCase(dataType)
                || DataHubConstant.INTERFACE_TYPE_JSON.equalsIgnoreCase(dataType);
    }

    /**
     * 为 Kafka 客户端配置 SASL（简单身份验证和安全层）设置。
     *
     * @param securityProtocol 要使用的安全协议（例如 PLAINTEXT、SSL、SASL_PLAINTEXT、SASL_SSL）。
     * @param saslMechanism    要使用的 SASL 机制（例如 SCRAM-SHA-256、SCRAM-SHA-512、PLAIN）。
     * @param username         The username for SASL authentication.
     * @param password         The password for SASL authentication.
     * @param props            The properties object to which the SASL configuration will be added.
     */
    public static void setSaslConfig(String securityProtocol,
                                     String saslMechanism,
                                     String username,
                                     String password,
                                     Properties props) {

        Objects.requireNonNull(securityProtocol, "securityProtocol cannot be null");
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityProtocol);

        // 1. 如果不是 SASL 协议（PLAINTEXT/SSL），不配置任何 SASL 相关内容
        if (SecurityProtocol.PLAINTEXT.name.equalsIgnoreCase(securityProtocol) ||
                SecurityProtocol.SSL.name.equalsIgnoreCase(securityProtocol)) {
            return;
        }


        // 2. 必须保证使用 SASL 时提供 mechanism
        if (StringUtils.isBlank(saslMechanism)) {
            throw new IllegalArgumentException("saslMechanism is required when using SASL protocol");
        }
        props.put(SaslConfigs.SASL_MECHANISM, saslMechanism);

        // 3. 根据机制选择 LoginModule
        final String loginModule;
        switch (saslMechanism) {
            case "SCRAM-SHA-256":
            case "SCRAM-SHA-512":
                loginModule = "org.apache.kafka.common.security.scram.ScramLoginModule";
                break;
            case "PLAIN":
                loginModule = "org.apache.kafka.common.security.plain.PlainLoginModule";
                break;
            default:
                throw new IllegalArgumentException("Unsupported SASL mechanism: " + saslMechanism);
        }

        // 4. SCRAM & PLAIN 均需 username/password
        if (StringUtils.isAnyBlank(username, password)) {
            throw new IllegalArgumentException("username/password must not be empty for SASL " + saslMechanism);
        }

        // 5. 构造 JAAS 配置
        //   - 明确指定 required
        //   - 结构完整，不留参数空位
        String jaasConfig = String.format(
                "%s required username=\"%s\" password=\"%s\";",
                loginModule, username, password
        );

        props.put(SaslConfigs.SASL_JAAS_CONFIG, jaasConfig);
    }

    public synchronized void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow();
                log.warn("[DhConsumerThreadProcess] Thread pool forced shutdown");
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            log.warn("[DhConsumerThreadProcess] Interrupted when thread pool is closed", e);
        } finally {
            instance = null;
            executor = null;
        }
        log.info("[ConfigManager] All producers and consumers closed.");
    }

}
