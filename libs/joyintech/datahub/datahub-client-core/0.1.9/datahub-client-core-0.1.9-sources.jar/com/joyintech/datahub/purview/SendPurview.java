package com.joyintech.datahub.purview;

import com.joyintech.datahub.exception.NoAccessException;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.util.LocalConfigKeyUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 发送权限校验
 * KafkaProducerHolder 中维护了有发送权限的数据编码列表
 *
 * @author ChenHao
 * @date 11/7/25 16:21
 */
public class SendPurview {

    private static final Logger log = LoggerFactory.getLogger(SendPurview.class);

    private SendPurview() {
    }

    private static volatile SendPurview INSTANCE;

    public static SendPurview getInstance() {
        if (INSTANCE == null) {
            synchronized (SendPurview.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SendPurview();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 强制重新初始化（destroy + init）
     */
    public static synchronized void reinit() {
        if (INSTANCE != null) {
            INSTANCE.destroyInternal();
        }
        INSTANCE = new SendPurview();
    }

    // ==================== 成员变量 ====================
    private final Map<String, ConfDto.ProducerConfig> producerConfigMap = new ConcurrentHashMap<>();
    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
    private volatile boolean destroyed = false;

    // ==================== 配置操作 ====================

    /**
     * 全量刷新 Producer 映射配置
     */
    public synchronized void reloadProducer(List<ConfDto.ProducerConfig> list) {
        if (destroyed) {
            log.warn("[SendPurview] Ignored reload because instance is destroyed.");
            return;
        }
        rwLock.writeLock().lock();
        try {
            producerConfigMap.clear();

            Optional.ofNullable(list)
                    .orElse(Collections.emptyList())
                    .forEach(conf ->
                            producerConfigMap.put(conf.getIntVer(), conf)
                    );

            log.info("=================SendPurview refresh====================");
            log.info("refresh producer config map success, size={}", producerConfigMap.size());
            log.info("Producer Configs: {}", producerConfigMap.keySet());
            log.info("Producer Configs: {}", producerConfigMap);
            log.info("========================================================");
        } catch (Exception e) {
            log.error("[SendPurview] Reload error, list={}", list, e);
            throw e;
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    /**
     * 清空 Producer 映射配置
     */
    public void clearProducerMappings() {
        if (destroyed) return;
        rwLock.writeLock().lock();
        try {
            producerConfigMap.clear();
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    /**
     * 添加单个 Producer 映射（写锁）
     */
    public void addProducerMapping(String dataCode, String version,
                                   ConfDto.ProducerConfig producerInfo) {
        if (destroyed) return;
        rwLock.writeLock().lock();
        try {
            producerConfigMap.put(LocalConfigKeyUtil.generateKey(dataCode, version), producerInfo);
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    /**
     * 权限校验 + 获取配置（读锁）
     */
    public ConfDto.ProducerConfig sendCheck(String dataCode, String version)
            throws NoAccessException {
        if (destroyed) {
            throw new NoAccessException("SendPurview is destroyed");
        }
        rwLock.readLock().lock();
        try {
            ConfDto.ProducerConfig producerConfig =
                    producerConfigMap.get(LocalConfigKeyUtil.generateKey(dataCode, version));

            if (producerConfig == null) {
                log.warn("DataCode[{}] no send permission", dataCode);
                throw new NoAccessException("DataCode[" + dataCode + "] no send permission");
            }
            return producerConfig;
        } finally {
            rwLock.readLock().unlock();
        }
    }

    /**
     * 获取不可修改的 Producer 配置副本
     */
    public Map<String, ConfDto.ProducerConfig> getProducerConfigMap() {
        if (destroyed) {
            return Collections.emptyMap();
        }
        rwLock.readLock().lock();
        try {
            return Collections.unmodifiableMap(new HashMap<>(producerConfigMap));
        } finally {
            rwLock.readLock().unlock();
        }
    }

    // ==================== 销毁 ====================
    public static synchronized void shutdown() {
        if (INSTANCE == null) {
            return;
        }
        INSTANCE.destroyInternal();
        INSTANCE = null;
    }

    private void destroyInternal() {
        if (destroyed) {
            return;
        }
        rwLock.writeLock().lock();
        try {
            if (destroyed) {
                return;
            }
            destroyed = true;
            producerConfigMap.clear();
            log.info("[SendPurview] Destroyed");
        } finally {
            rwLock.writeLock().unlock();
        }
    }
}
