package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.model.FileMetadata;

import java.io.File;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhFileListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 17:45 <br/>
 * Description: 处理文件类数据文件监听接口  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhFileListener extends DhListener{
    /**
     * 业务系统文件处理逻辑
     */
    void onFile(File file, FileMetadata  metadata);
}
