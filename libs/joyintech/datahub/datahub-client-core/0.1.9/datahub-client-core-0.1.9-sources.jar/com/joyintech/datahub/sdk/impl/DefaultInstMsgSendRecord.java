package com.joyintech.datahub.sdk.impl;

import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;
import com.joyintech.datahub.sdk.InstMsgSendRecord;
import com.joyintech.datahub.util.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DefaultInstMsgSendRecord.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/24 17:16 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DefaultInstMsgSendRecord implements InstMsgSendRecord {

    private static final Logger log = LoggerFactory.getLogger(DefaultInstMsgSendRecord.class);
    @Override
    public void preSend(InstantMsgLogDTO logDTO) {
        log.info("即时数据发送记录：{}" , JsonUtil.toJson(logDTO));
    }

    @Override
    public void postSend(String traceId, String result, String errorMsg) {
        log.info("即时消息发送：{}，处理结果：{}，错误消息：{}",traceId,result,errorMsg);
    }
}
