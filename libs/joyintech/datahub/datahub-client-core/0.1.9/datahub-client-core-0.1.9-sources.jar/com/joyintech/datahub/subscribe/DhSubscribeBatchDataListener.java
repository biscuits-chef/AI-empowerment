package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.model.FileMetadata;

import java.util.List;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhSubscribeBatchDataListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 17:49 <br/>
 * Description: 批量数据订阅接口  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhSubscribeBatchDataListener<T extends DhBaseDTO> extends DhGenericTypeListener<T> {

    /**
     * 返回监听器处理的数据类
     * 实现类必须返回具体的泛型类
     */
    Class<T> getDataClass();
    /**
     * 业务批量对象处理逻辑
     */
    void onBatchData(List<T> dataList, FileMetadata metadata);
    /**
     * 批量数据大小，默认1000
     */
    default int getBatch(){
        return 1000;
    }
}

