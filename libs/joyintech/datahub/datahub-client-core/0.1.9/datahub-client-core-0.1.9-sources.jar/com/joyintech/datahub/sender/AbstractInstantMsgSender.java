package com.joyintech.datahub.sender;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.DhcLogContext;
import com.joyintech.datahub.sdk.InsMsgLogServerLoad;
import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.IdUtil;
import com.joyintech.datahub.util.TimeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeader;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ChenHao
 * @date 1/13/26 17:39
 */
public abstract class AbstractInstantMsgSender {
    
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AbstractInstantMsgSender.class);

    private static final ObjectMapper MAPPER = new ObjectMapper();


    protected static SendResult getSendResult(String dataDate, String dataCode, String version, String value,
                                              KafkaProducer<String, String> producer, ProducerRecord<String, String> record,
                                              LogType logType, String sysCode) {
        String logIdentify = LogType.KAFKA_REALTIME.getDesc();
        if (LogType.KAFKA_ATTACH.equals(logType)) {
            logIdentify = LogType.KAFKA_ATTACH.getDesc();
        }

        String traceId = IdUtil.generateStrId();
        Header traceHeader = new RecordHeader(DataHubConstant.TRACE_ID, traceId.getBytes(StandardCharsets.UTF_8));
        Header fromAppCodeHeader = new RecordHeader(DataHubConstant.APP_CODE_FROM, ConfHolder.getInstance().getAppCode().getBytes(StandardCharsets.UTF_8));
        Header dataCodeHeader = new RecordHeader(DataHubConstant.DATA_CODE, (dataCode).getBytes(StandardCharsets.UTF_8));
        Header versionHeader = new RecordHeader(DataHubConstant.VERSION, (version).getBytes(StandardCharsets.UTF_8));
        Header dataDateHeader = new RecordHeader(DataHubConstant.DATA_DATE, (dataDate).getBytes(StandardCharsets.UTF_8));
        Header logTypeHeader = new RecordHeader(DataHubConstant.SEND_TYPE, (logType.getCode()).getBytes(StandardCharsets.UTF_8));
        record.headers().add(traceHeader);
        record.headers().add(fromAppCodeHeader);
        record.headers().add(dataCodeHeader);
        record.headers().add(versionHeader);
        record.headers().add(dataDateHeader);
        record.headers().add(logTypeHeader);
        if (StringUtils.isNotEmpty(sysCode)) {
            Header toAppCodeHeader = new RecordHeader(DataHubConstant.APP_CODE_TO, sysCode.getBytes(StandardCharsets.UTF_8));
            record.headers().add(toAppCodeHeader);
        }
        preSendRecord(traceId, dataCode, version, value, logIdentify);
        try {
            //异步改为同步，解决数据一致同步问题
            producer.send(record).get();
            String headersJson = headersToJson(record.headers());
            DhcLog.getInstance().info(DhcLogContext.builder().traceId(traceId).logType(logType.getCode()).dataDate(dataDate)
                    .dataCode(dataCode).version(version).message(logIdentify + "数据发送成功").durationMs(0L).recordContents(value)
                    .headers(headersJson).build());
            postRecord(traceId, "S", "处理成功", logIdentify);
            log.info("{}数据发送成功，dataCode:{},dataVersion:{},traceId:{}", logIdentify, dataCode, version, traceId);
        } catch (Exception e) {
            log.error("[InstantMsg] sendData error, traceId: {}; appCode: {}; dataCode: {}; version: {} message: {}"
                    , traceId, ConfHolder.getInstance().getAppCode(), dataCode, version, value, e);
            DhcLog.getInstance().info(DhcLogContext.builder().traceId(traceId).logType(logType.getCode()).dataDate(dataDate)
                    .dataCode(dataCode).version(version).message(logIdentify + "发送异常").durationMs(0L).recordContents(value)
                    .throwable(e).build());
            postRecord(traceId, "E", "发送" + logIdentify + "业务处理发生异常,异常简要信息：" + e.getMessage(), logIdentify);
            return SendResult.failure("500", "Send data error: " + e.getMessage());
        }

        return SendResult.success();
    }

    private static void preSendRecord(String traceId, String dataCode, String version, String value, String logIdentify) {
        InstantMsgLogDTO logDTO = new InstantMsgLogDTO();
        logDTO.setMsg(value);
        logDTO.setDataCode(dataCode);
        logDTO.setTraceId(traceId);
        logDTO.setDataVersion(version);
        logDTO.setSendTime(TimeUtils.now());
        try {
            InsMsgLogServerLoad.getInstance().getInstMsgSendRecord().preSend(logDTO);
        } catch (Exception e) {
            log.error("记录{}：{}发送出现异常", logIdentify, traceId, e);
        }
    }

    private static void postRecord(String traceId, String result, String errorMsg, String logIdentify) {
        try {
            InsMsgLogServerLoad.getInstance().getInstMsgSendRecord().postSend(traceId, result, errorMsg);
        } catch (Exception e) {
            log.error("记录{}：{}发送结果出现异常", logIdentify, traceId, e);
        }
    }

    public static String headersToJson(Headers headers) {
        Map<String, String> map = new HashMap<>();

        for (Header h : headers) {
            map.put(
                    h.key(),
                    h.value() == null
                            ? null
                            : new String(h.value(), StandardCharsets.UTF_8)
            );
        }

        try {
            return MAPPER.writeValueAsString(map);
        } catch (Exception e) {
            throw new RuntimeException("headers to json failed", e);
        }
    }

}