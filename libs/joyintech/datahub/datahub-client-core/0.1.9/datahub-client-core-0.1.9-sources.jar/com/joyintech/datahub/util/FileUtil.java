package com.joyintech.datahub.util;


import com.joyintech.datahub.enums.FileFormat;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 简单文件工具：原子写、读、存在判断
 *
 * @author ChenHao
 * @date 11/4/25 17:09
 */
public class FileUtil {

    private FileUtil() {
    }
    public static final String MARKER_DIRECTORY = "%s/%s";
    
    private static final String PATTERN = "yyyy-MM";
    private static final String PATTERN_YEAR = "yyyy";
    private static final String PATTERN_MONTH = "yyyy-MM";
    private static final String PATTERN_DAY = "yyyy-MM/dd";
    
    public static void writeFile(String path, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(path)) {
            fos.write(data);
        }
    }

    public static byte[] readFile(String path) throws IOException {
        return Files.readAllBytes(Paths.get(path));
    }

    public static boolean exists(String path) {
        return Files.exists(Paths.get(path));
    }


    public static String objectKeyBuilder(String path, String originalFilename){
        return objectKeyBuilder(path, originalFilename, null, null);
    }

    public static String objectKeyBuilder(String path, String originalFilename, Boolean storeInRoot,
                                          String datePathMode){

        if(StringUtils.isBlank(originalFilename)){
            throw new IllegalArgumentException("originalFilename cannot be null or empty");
        }
        String fileName = extractFilenameOnly(originalFilename);
        if (StringUtils.isBlank(fileName)) {
            throw new IllegalArgumentException("fileName cannot be null or empty");
        }
        String fileDirectory = buildDirectory(path, storeInRoot, datePathMode);
        return joinDirectoryAndName(fileDirectory, fileName);
    }
    /**
     * 简单文件名生成
     * 格式为：数据代码_版本_YYYYMMDDHHMMSS.文件格式
     * @param dataCode 数据代码
     * @param version  版本
     * @param path     文件路径
     * @param fileFormat 文件格式
     * @return 文件名
     */
    public static String simpleFilename(String dataCode, String version, String path, FileFormat fileFormat) {
        return simpleFilename(dataCode, version, path, fileFormat, null, null);
    }

    public static String simpleFilename(String dataCode, String version, String path, FileFormat fileFormat,
                                        Boolean storeInRoot, String datePathMode) {
        // 参数校验
        validateParameters(dataCode, version, fileFormat);

        // 获取当前时间并格式化
        LocalDateTime now = LocalDateTime.now();

        // 使用线程安全的DateTimeFormatter
        String timestamp = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String fileDirectory = buildDirectory(path, storeInRoot, datePathMode, now);

        String fileUrlName = String.format("%s_%s_%s.%s",
                normalizeDataCode(dataCode),
                normalizeVersion(version),
                timestamp,
                fileFormat.toString().toLowerCase());
        return joinDirectoryAndName(fileDirectory, fileUrlName);
    }
    /**
     * 简单文件名生成
     * 格式为：数据代码_版本_YYYYMMDD.文件格式
     * @param dataCode 数据代码
     * @param version  版本
     * @param path     文件路径
     * @param fileFormat 文件格式
     * @return 文件名
     */
    public static String dateFilename(String dataCode, String version, String path, FileFormat fileFormat) {
        return dateFilename(dataCode, version, path, fileFormat, null, null);
    }

    public static String dateFilename(String dataCode, String version, String path, FileFormat fileFormat,
                                      Boolean storeInRoot, String datePathMode) {
        // 参数校验
        validateParameters(dataCode, version, fileFormat);

        // 获取当前时间并格式化
        LocalDateTime now = LocalDateTime.now();

        // 使用线程安全的DateTimeFormatter
        String timestamp = now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String fileDirectory = buildDirectory(path, storeInRoot, datePathMode, now);

        String fileUrlName = String.format("%s_%s_%s.%s",
                normalizeDataCode(dataCode),
                normalizeVersion(version),
                timestamp,
                fileFormat.toString().toLowerCase());
        return joinDirectoryAndName(fileDirectory, fileUrlName);
    }

    private static String joinDirectoryAndName(String fileDirectory, String fileName) {
        if (StringUtils.isBlank(fileDirectory)) {
            return fileName;
        }
        return String.format(MARKER_DIRECTORY, fileDirectory, fileName);
    }

    private static String buildDirectory(String path, Boolean storeInRoot, String datePathMode) {
        return buildDirectory(path, storeInRoot, datePathMode, LocalDateTime.now());
    }

    private static String buildDirectory(String path, Boolean storeInRoot, String datePathMode, LocalDateTime now) {
        String fileDirectory = normalizePath(path);
        String dateDirectory = resolveDateDirectory(storeInRoot, datePathMode, now);
        if (StringUtils.isBlank(dateDirectory)) {
            return fileDirectory;
        }
        if (StringUtils.isBlank(fileDirectory)) {
            return dateDirectory;
        }
        return String.format(MARKER_DIRECTORY, fileDirectory, dateDirectory);
    }

    private static String resolveDateDirectory(Boolean storeInRoot, String datePathMode, LocalDateTime now) {
        if (Boolean.TRUE.equals(storeInRoot)) {
            return "";
        }
        if (StringUtils.isBlank(datePathMode)) {
            return now.format(DateTimeFormatter.ofPattern(PATTERN));
        }
        if (StringUtils.equalsIgnoreCase("NONE", datePathMode)) {
            return "";
        }
        if (StringUtils.equalsIgnoreCase("YEAR", datePathMode)) {
            return now.format(DateTimeFormatter.ofPattern(PATTERN_YEAR));
        }
        if (StringUtils.equalsIgnoreCase("MONTH", datePathMode)) {
            return now.format(DateTimeFormatter.ofPattern(PATTERN_MONTH));
        }
        if (StringUtils.equalsIgnoreCase("DAY", datePathMode)) {
            return now.format(DateTimeFormatter.ofPattern(PATTERN_DAY));
        }
        throw new IllegalArgumentException("不支持的datePathMode: " + datePathMode);
    }
    /**
     * 参数校验 - 确保线程安全
     */
    private static void validateParameters(String dataCode, String version, FileFormat fileFormat) {
        if (dataCode == null || dataCode.trim().isEmpty()) {
            throw new IllegalArgumentException("dataCode cannot be null or empty");
        }
        if (version == null || version.trim().isEmpty()) {
            throw new IllegalArgumentException("version cannot be null or empty");
        }
        if (fileFormat == null) {
            throw new IllegalArgumentException("fileFormat cannot be null");
        }
    }

    /**
     * 规范化路径 - 移除开头和结尾的斜杠
     */
    private static String normalizePath(String path) {
        if (path == null) {
            return "";
        }
        return path.trim().replaceAll("^/+|/+$", "");
    }

    /**
     * 规范化数据代码 - 移除特殊字符
     */
    private static String normalizeDataCode(String dataCode) {
        return dataCode.trim().replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    /**
     * 规范化版本号 - 移除特殊字符
     */
    private static String normalizeVersion(String version) {
        return version.trim().replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    /**
     * 从完整文件路径中提取纯文件名
     */
    public static String extractFilenameOnly(String fullPath) {
        if (fullPath == null || fullPath.trim().isEmpty()) {
            return "";
        }

        int lastSlashIndex = fullPath.lastIndexOf('/');
        if (lastSlashIndex >= 0 && lastSlashIndex < fullPath.length() - 1) {
            return fullPath.substring(lastSlashIndex + 1);
        }

        return fullPath; // 如果没有斜杠，直接返回原字符串
    }

    public static String getFileExtension(String fileName){
        if (fileName == null || fileName.isEmpty()) {
            return "";
        }

        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1);
        }

        return "";
    }
    /**
     * 检测文件类型
     */
    public static FileFormat detectFileFormat(String objectKey) {
        if (objectKey == null) {
            return null;
        }

        String extension = getFileExtension(objectKey).toLowerCase();

        if (StringUtils.equalsIgnoreCase("csv",extension)) {
            return FileFormat.CSV;
        } else if (StringUtils.equalsIgnoreCase("txt",extension)) {
            return FileFormat.TXT;
        }else if(StringUtils.equalsIgnoreCase("dat",extension)){
            return FileFormat.DAT;
        }else if(StringUtils.equalsIgnoreCase("json",extension)){
            return FileFormat.JSON;
        } else {
            return null;
        }
    }

    /**
     * 判断文件是否超过 50MB
     */
    public static boolean isFileLargerThanXMB(File tempFile) {

        ConfHolder.ObsUploadConf obsUploadConf = ConfHolder.getInstance().getObsUploadConf();

        if (tempFile == null || !tempFile.isFile()) {
            return false;
        }
        
        // 字节
        long size = tempFile.length();
        return size > obsUploadConf.getPartSizeInBytes();
    }
    
}
