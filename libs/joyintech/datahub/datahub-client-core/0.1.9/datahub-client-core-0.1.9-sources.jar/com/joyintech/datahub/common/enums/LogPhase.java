package com.joyintech.datahub.common.enums;

/**
 * @author ChenHao
 * @date 11/28/25 16:17
 */
public enum LogPhase {
    /**
     * 发送消息时的日志
     */
    SENDER("SENDER", "发送侧日志"),

    /**
     * 消息处理(消费)时的日志
     */
    HANDLER("HANDLER", "处理侧日志"),
    
    ;


    LogPhase(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private final String code;
    
    private final String desc;

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 根据 code 获取枚举
     */
    public static LogPhase fromCode(String code) {
        for (LogPhase type : LogPhase.values()) {
            if (type.code.equalsIgnoreCase(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown LogPhase code: " + code);
    }
    
}