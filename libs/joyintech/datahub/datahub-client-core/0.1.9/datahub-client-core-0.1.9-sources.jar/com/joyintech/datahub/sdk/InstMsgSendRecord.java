package com.joyintech.datahub.sdk;

import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: InstMsgSendRecord.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/24 17:07 <br/>
 * Description: 即时消息发送记录接口 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface InstMsgSendRecord {
    /**
     * 发送消息前记录
     * @param logDTO 日志数据实体
     */
    void preSend(InstantMsgLogDTO logDTO);
    /**
     * 发送消息后记录
     * @param traceId 消息轨迹ID
     * @param result 发送结果
     * @param errorMsg 错误信息
     */
    void postSend(String traceId,String result,String errorMsg);
}
