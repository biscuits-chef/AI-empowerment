package com.joyintech.datahub.util;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import com.obs.services.exception.ObsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: RetryUtil.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/2/5 8:51 <br/>
 * Description: 重试工具  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class RetryUtil {

    private static final Logger log = LoggerFactory.getLogger(RetryUtil.class);
    private static final int MAX_RETRIES = 3;
    private static final long INITIAL_DELAY_MS = 300; // 初始延迟100ms
    private static final long MAX_DELAY_MS = 5000; // 最大延迟5秒

    /**
     * 带指数退避的重试执行
     */
    public static <T> T executeWithRetry(Supplier<T> operation, String operationName) {
        int attempt = 0;
        Exception lastException = null;

        while (attempt <= MAX_RETRIES) {
            try {
                if (attempt > 0) {
                    log.warn("重试 {} 操作，第 {} 次尝试", operationName, attempt);
                }
                return operation.get();

            } catch (ObsException e) {
                lastException = e;
                attempt++;

                if (shouldRetry(e) && attempt <= MAX_RETRIES) {
                    long delay = calculateBackoffDelay(attempt);
                    log.warn("{} 操作失败，{} 秒后重试。错误: {}",
                            operationName, delay / 1000, e.getErrorMessage());

                    try {
                        TimeUnit.MILLISECONDS.sleep(delay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("重试被中断", ie);
                    }
                } else {
                    log.error("{} 操作达到最大重试次数，最终失败", operationName, e);
                    throw e;
                }
            } catch (Exception e) {
                log.error("{} 操作遇到不可重试异常", operationName, e);
                throw new DataHubException(DataHubErrorEnum.OBS_SERVER_ERROR,"遇到不可重试异常",e);
            }
        }

        log.error("{} 操作最终失败，重试 {} 次", operationName, MAX_RETRIES);
        throw new DataHubException(DataHubErrorEnum.OBS_SERVER_ERROR,"操作失败 after " + MAX_RETRIES + " retries",
                lastException);
    }

    /**
     * 判断异常是否可重试
     */
    private static boolean shouldRetry(ObsException e) {
        String errorCode = e.getErrorCode();
        // 网络错误、服务端5xx错误可重试
        return "NetworkError".equals(errorCode) ||
                (errorCode != null && errorCode.startsWith("5"));
    }

    /**
     * 计算指数退避延迟时间
     */
    private static long calculateBackoffDelay(int attempt) {
        long delay = INITIAL_DELAY_MS * (1L << (attempt - 1)); // 指数增长
        return Math.min(delay, MAX_DELAY_MS);
    }

}
