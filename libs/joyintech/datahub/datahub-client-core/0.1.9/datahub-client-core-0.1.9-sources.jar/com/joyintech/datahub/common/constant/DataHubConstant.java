package com.joyintech.datahub.common.constant;

import java.net.NetworkInterface;

/**
 * @author ChenHao
 * @date 11/6/25 10:35
 */
public class DataHubConstant {
    private DataHubConstant() {
    }

    /**
     * OBS服务配置文件后缀
     */
    public static final String OBS_SERVICE_CONFIG_SUFFIX = ".dat";
    
    public static final String Y_OR_N_Y = "Y";
    public static final String Y_OR_N_N = "N";
    public static final String DEFAULT_FILE_ENCODING = "UTF-8";

    // =======================  header 常量 ========================== st

    public static final String TRACE_ID = "traceId";
    
    public static final String SPAN_ID = "spanId";
    
    public static final String APP_CODE = "appCode";

    /**
     * 发送方应用编码
     */
    public static final String APP_CODE_FROM = "appCodeFrom";
    /**
     * 接收方应用编码
     */
    public static final String APP_CODE_TO = "appCodeTo";
    /**
     * 数据编码
     */
    public static final String DATA_CODE = "dataCode";
    /**
     * 附件文件列表
     */
    public static final String ATTACH_FILE_LIST = "attachFileList";
    /**
     * 数据版本
     */
    public static final String VERSION = "version";
    /**
     * 数据日期
     */
    public static final String DATA_DATE="dataDate";
    /**
     * 消息类型 - 文件通知
     * Y/N
     */
    public static final String SEND_TYPE_FILE = "file_notify";
    /**
     * header 中用来标识是 即时消息 还是 附件消息 的标识
     * 当前仅有：KAFKA/ATTACH
     */
    public static final String SEND_TYPE = "send_type";

    /**
     *
     */
    public static final String SKIP_LINE_ONE_FLAG = "skipLineOneFlag";
    public static final String FILE_ENCODING = "fileEncoding";
    
    // =======================  header 常量 ========================== end


    /**
     * 接口类型 消息
     */
    public static final String INTERFACE_TYPE_KAFKA = "Kafka";

    /**
     * 接口类型 文件
     */
    public static final String INTERFACE_TYPE_OBS = "obs";
    public static final String INTERFACE_TYPE_JSON = "json";

    /**
     * 默认的权限分隔符
     */
    public static final String DEFAULT_PURVIEW_DELIMITER = "@";

    /**
     * 上报信息临时分隔符
     */
    public static final String REPORT_INFO_TEMP_DELIMITER = "#@#";
    
    /**
     * The property name for {@link NetworkInterface#getDisplayName() the name of network interface} that the DataHubClient application prefers
     */
    public static final String PREFERRED_NETWORK_INTERFACE = "datahub.network.interface.preferred";

    /**
     * Java regular expressions for network interfaces that will be ignored.
     */
    public static final String IGNORED_NETWORK_INTERFACE_REGEX = "datahub.network.interface.ignored";

    /**
     * 绑定地址，一般填写本机网卡地址
     */
    public static final String BIND_LOCAL_ADDRESS = "datahub.network.local.address";

    /**
     * 组分隔符
     */
    public static final String GROUP_SEPARATOR = "_";
    /**
     * 附件使用文件夹
     */
    public static final String ATTACH_DIR = "edlp_attach";

}
