package com.joyintech.datahub.consumer;

import com.joyintech.datahub.model.FileSendNotify;
import com.joyintech.datahub.sdk.InsMsgLogServerLoad;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileConsumerHandler.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/12/2 16:56 <br/>
 * Description: 数据消费辅助处理 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileConsumerHandler {

    private FileConsumerHandler(){}

    private static final Logger log = LoggerFactory.getLogger(FileConsumerHandler.class);

    /**
     *功能描述: <br>
     * 文件消费前记录
     */
    public static void preFileRecord(FileSendNotify fileSendNotify){
        try{
            InsMsgLogServerLoad.getInstance().getFileConsumerRecord().preFileProcess(fileSendNotify);
        }catch(Exception e){
            log.error("文件消费前记录业务系统异常",e);
        }
    }
    /**
     *功能描述: <br>
     * 文件消费后记录
     */
    public static void postFileRecord(String traceId,String result,String errorMsg){
        try{
            InsMsgLogServerLoad.getInstance().getFileConsumerRecord().endFileProcess(traceId,result,errorMsg);
        }catch(Exception e){
            log.error("文件消费后记录业务系统异常",e);
        }
    }
}
