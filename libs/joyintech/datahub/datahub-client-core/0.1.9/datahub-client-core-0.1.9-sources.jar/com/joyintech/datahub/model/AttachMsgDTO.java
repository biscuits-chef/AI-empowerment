package com.joyintech.datahub.model;

import org.apache.commons.collections4.CollectionUtils;

import java.util.List;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AttachMsgDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 16:28 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AttachMsgDTO<T> extends SendBaseDTO {

    private List<AttachFile> attachFileList;

    private T value;

    public List<AttachFile> getAttachFileList() {
        return attachFileList;
    }

    public void setAttachFileList(List<AttachFile> attachFileList) {
        this.attachFileList = attachFileList;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    @Override
    public void validate() {
        super.validate();
        if (value == null) {
            throw new IllegalArgumentException("发送对象value不能为空");
        }
        if(CollectionUtils.isEmpty(attachFileList)){
            throw new IllegalArgumentException("发送附件不能为空");
        }
    }
}
