package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.exception.NoAccessException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileGenStats;
import com.joyintech.datahub.model.FileSenderDTO;
import com.joyintech.datahub.model.MultipartReqDTO;
import com.joyintech.datahub.obs.ObsClientHandler;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.*;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.PutObjectResult;
import org.apache.commons.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileSender.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 19:42 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileSender extends FileAbstractSender {

    private static final Logger log = LoggerFactory.getLogger(FileSender.class);
    private static final FileSender instance;

    private FileSender() {
    }

    static {
        try {
            instance = new FileSender();
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "初始化FileSender异常", e);
        }
    }

    public static FileSender getInstance() {
        return instance;
    }

    /**
     * 功能描述: <br>
     * 发送文件到OBS存储桶
     * 此处需要注意：文件发送按照本地文件路径进行上传
     *
     * @param fileDate      业务日期格式为：yyyy-mm-dd
     * @param fileSenderDTO 文件发送参数
     * @return com.joyintech.datahub.sender.SendResult
     */
    public SendResult sendFile(String fileDate, FileSenderDTO fileSenderDTO) throws NoAccessException {
        if (org.apache.commons.lang3.StringUtils.isBlank(fileDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        if (fileSenderDTO == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "FileSenderDTO 不能为空");
        }

        fileSenderDTO.validate();
        log.info("开始发送文件:{}", fileSenderDTO.getFile().getAbsolutePath());
        long startTime = System.currentTimeMillis();
        String traceId = IdUtil.generateStrId();
        ConfDto.ProducerConfig producerConfig = SendPurview.getInstance().sendCheck(fileSenderDTO.getDataCode(), fileSenderDTO.getDataVersion());
        checkFileType(fileSenderDTO.getFile().getName(), producerConfig);
        String objectKey = FileUtil.objectKeyBuilder(producerConfig.getDirectory(), fileSenderDTO.getFile().getName(),
                producerConfig.getStoreInRoot(), producerConfig.getDatePathMode());
        if (StringUtils.equals(DataHubConstant.Y_OR_N_N, producerConfig.getOverwriteFlag())) {
            if (ObsClientHandler.objectKeyExists(ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(), objectKey)) {
                DhcLog.getInstance().warn(traceId,
                        LogType.FILE_PROCESSING,
                        fileDate,
                        fileSenderDTO.getDataCode(),
                        fileSenderDTO.getDataVersion(),
                        "配置文件不覆盖，文件名相同：", 0L,
                        fileSenderDTO.getFile().getName());
                return SendResult.failure("500", "配置不可覆盖，但文件名:" + fileSenderDTO.getFile().getName() + "已存在");
            }

        }

        FileGenStats fgs = buildFileGenStats(fileSenderDTO.getFile().length(), fileSenderDTO.getRowCount());

        try {

            // 抽象类中无此属性。。。
            String eTage;
            String bucketName;

            // 判断文件大小，选择上传方式
            if (FileUtil.isFileLargerThanXMB(fileSenderDTO.getFile())) {
                MultipartReqDTO reqDTO = new MultipartReqDTO();
                reqDTO.setBucketName(ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName());
                reqDTO.setFile(fileSenderDTO.getFile());
                reqDTO.setObjectKey(objectKey);
                reqDTO.setDataCode(fileSenderDTO.getDataCode());
                reqDTO.setVersion(fileSenderDTO.getDataVersion());
                reqDTO.setTraceId(traceId);
                // 超过 50MB，走分片 / 断点续传
                CompleteMultipartUploadResult result =
                        RetryUtil.executeWithRetry(() -> ObsUploader.getInstance().uploadFile(reqDTO),"大文件分片上传");
                eTage = result.getEtag();
                bucketName = result.getBucketName();
                // 是否需要设置元数据？
            } else {
                // 普通上传
                PutObjectRequest putRequest = new PutObjectRequest(
                        ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(),
                        objectKey, fileSenderDTO.getFile());
                OBSMetadataUtil.applyMetadata(fileSenderDTO.getDataCode(), fileSenderDTO.getDataVersion(), traceId, putRequest);
                
                PutObjectResult result = RetryUtil.executeWithRetry(() ->ObsClientHandler.putObject(putRequest),
                        "小文件上传");
                eTage = result.getEtag();
                bucketName = result.getBucketName();
            }

            long endTime = System.currentTimeMillis();
            FileSenderComplete.sendFileSendCompleteMsg(fileDate, fileSenderDTO.getDataCode(),
                    fileSenderDTO.getDataVersion(),
                    traceId, fgs, eTage, objectKey, bucketName, producerConfig.getSkipLineOneFlag(),
                    producerConfig.getFileEncoding());
            DhcLog.getInstance().info(traceId,
                    LogType.FILE_PROCESSING,
                    fileDate,
                    fileSenderDTO.getDataCode(),
                    fileSenderDTO.getDataVersion(),
                    "文件发送成功", endTime - startTime, "文件发送成功，文件名：" + fileSenderDTO.getFile().getName());
            return new SendResult("200", "发送成功", true, buildFileResultInfo(eTage, objectKey, bucketName, fgs));
        } catch (Exception e) {
            log.error("文件发送异常", e);
            long endTime = System.currentTimeMillis();
            DhcLog.getInstance().error(traceId,
                    LogType.FILE_PROCESSING,
                    fileDate,
                    fileSenderDTO.getDataCode(),
                    fileSenderDTO.getDataVersion(),
                    "文件发送异常", endTime - startTime,
                    "文件发送异常，文件名：" + fileSenderDTO.getFile().getName() + ",异常信息：", StackTraceFormatUtil.getStackTrace(e));
            return new SendResult("500", "发送异常" + e.getMessage(), false);
        }
    }

}
