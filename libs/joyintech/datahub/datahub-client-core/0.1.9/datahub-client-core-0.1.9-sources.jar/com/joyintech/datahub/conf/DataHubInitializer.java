package com.joyintech.datahub.conf;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.transporter.HttpConfigTransporter;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.ObsConfContent;
import com.joyintech.datahub.model.URL;
import com.joyintech.datahub.transporter.ObsConfigTransporter;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.ObsClientHolder;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import org.slf4j.Logger;


/**
 * @author ChenHao
 * @date 11/6/25 19:32
 */
public class DataHubInitializer {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(DataHubInitializer.class);

    private final ObsConfContent obsConfContent;

    private final HttpConfigTransporter httpConfManager;
    
    private final ObsConfigTransporter obsConfigTransporter;

    /**
     * 1、初始化http拉取配置
     * 2、初始化obs拉取配置
     * <p>
     * 优先1；失败后使用2
     *
     * @param
     */
    public DataHubInitializer(String accessKey, String secretKey, String endpoint,
                              String bucketName, String objectPath, URL confUrl, String confKey,
                              String apiKey, String appCode, URL url) {
        String key = objectPath + appCode + "_" + apiKey + DataHubConstant.OBS_SERVICE_CONFIG_SUFFIX;
        this.obsConfContent = new ObsConfContent(
                bucketName,
                key,
                accessKey,
                secretKey,
                endpoint
        );
        ConfHolder.getInstance().setConfKey(confKey);
        ConfHolder.getInstance().setUrl(url);
        ConfHolder.getInstance().setObsConfContent(obsConfContent);
        ConfHolder.getInstance().setConfUrl(confUrl);
        ConfHolder.getInstance().setApiKey(apiKey);
        this.httpConfManager = new HttpConfigTransporter();
        this.obsConfigTransporter = new ObsConfigTransporter(obsConfContent);
        ConfHolder.getInstance().setAppCode(appCode);
        StackTraceFormatUtil.setDefaultLines(ConfHolder.getInstance().getStackTraceLimit());
    }

    /**
     * 初始化配置 obsClient 等
     *
     * @return
     */
    public ConfDto initialize() {
        ObsClientHolder.getInstance().initInternalObsClient(obsConfContent);

        ConfDto confDto = httpConfManager.fetchConf();
        if (confDto != null) {
            ObsClientHolder.getInstance().initObsClient();
            log.info("http pulls initial data successfully");
            return confDto;
        }
        
        log.info("http pull failed, try to pull from obs");
        confDto = obsConfigTransporter.fetchConf();

        return confDto;
    }

}