package com.joyintech.datahub.file;

import com.joyintech.datahub.model.FileGenStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Iterator;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileContentInputStream.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 16:23 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileContentInputStream<T> extends  InputStream {

    private static final Logger log = LoggerFactory.getLogger(FileContentInputStream.class);
    private final Iterator<T> dataIterator;
    private final EnhancedLineConverter<T> lineConverter;
    private final Charset charset;

    private byte[] currentLineBytes;
    private int currentPosition = 0;
    private boolean hasMoreData = true;

    // 新增：头部行相关
    private byte[] headerLineBytes = null;
    private boolean headerProcessed = false;

    // 大小计算相关
    private long totalBytesGenerated = 0;
    private long lineCount = 0;

    // 同步锁，确保线程安全
    private final Object lock = new Object();

    private final FileGenStats fileGenStats = new FileGenStats();

    public FileContentInputStream(Iterator<T> dataIterator,
                                  EnhancedLineConverter<T> lineConverter,
                                  Charset charset) {
        this.dataIterator = dataIterator;
        this.lineConverter = lineConverter;
        this.charset = charset;
    }

    /**
     * 设置头部行
     * @param headerLine 头部行内容
     */
    public void setHeaderLine(String headerLine) {
        if (headerLine != null && !headerLine.isEmpty()) {
            this.headerLineBytes = (headerLine + "\n").getBytes(charset);
        }
    }

    @Override
    public int read() throws IOException {
        synchronized ( lock) {
            return doRead();
        }
    }

    /**
     * 获取已生成的总字节数（文件大小）
     */
    public long getTotalBytesGenerated() {
        return totalBytesGenerated;
    }

    /**
     * 获取生成的行数
     */
    public long getLineCount() {
        return lineCount;
    }

    private int doRead() throws IOException {
        // 检查是否还有数据
        if (!hasMoreData) {
            return -1;
        }

        // 如果当前行为空或已读完，加载下一行
        if (currentLineBytes == null || currentPosition >= currentLineBytes.length) {
            if (!loadNextLineSafely()) {
                return -1;
            }
        }

        // 再次检查边界（防御性编程）
        if (currentLineBytes == null ||
                currentPosition < 0 ||
                currentPosition >= currentLineBytes.length) {

            // 如果状态异常，尝试恢复
            if (!recoverFromErrorState()) {
                return -1;
            }
        }

        // 安全读取字节
        byte result = currentLineBytes[currentPosition];
        currentPosition++;

        return result & 0xFF;
    }

    /**
     * 安全的加载下一行方法
     */
    private boolean loadNextLineSafely() {
        try {
            // 如果是第一次加载，先处理头部行
            if (!headerProcessed && headerLineBytes != null) {
                currentLineBytes = headerLineBytes;
                currentPosition = 0;
                totalBytesGenerated += currentLineBytes.length;
                headerProcessed = true;
                return true;
            }

            // 正常加载数据行
            if (dataIterator != null && dataIterator.hasNext()) {
                T data = dataIterator.next();
                String line = lineConverter.convertToLine(data);
                currentLineBytes = (line + "\n").getBytes(charset);
                currentPosition = 0;
                totalBytesGenerated += currentLineBytes.length;
                lineCount++;
                return true;

            } else {
                // 没有更多数据了
                hasMoreData = false;
                currentLineBytes = null;
                currentPosition = 0;
                return false;
            }

        } catch (Exception e) {
            // 记录错误并进入错误状态
            log.error("加载下一行时发生错误: " ,e);
            hasMoreData = false;
            currentLineBytes = null;
            currentPosition = 0;
            return false;
        }
    }

    /**
     * 从错误状态恢复
     */
    private boolean recoverFromErrorState() {
        log.warn("检测到错误状态，尝试恢复...");

        // 重置状态
        currentPosition = 0;

        // 尝试加载下一行
        if (loadNextLineSafely()) {
            log.warn("状态恢复成功");
            return true;
        } else {
            log.warn("状态恢复失败，没有更多数据");
            return false;
        }
    }

    /**
     * 批量读取方法 - 提高性能
     */
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        } else if (off < 0 || len < 0 || len > b.length - off) {
            throw new IndexOutOfBoundsException();
        } else if (len == 0) {
            return 0;
        }

        synchronized (lock) {
            return doRead(b, off, len);
        }
    }

    private int doRead(byte[] b, int off, int len) throws IOException {
        int totalRead = 0;

        while (len > 0 && hasMoreData) {
            if (currentLineBytes == null || currentPosition >= currentLineBytes.length) {
                if (!loadNextLineSafely()) {
                    break;
                }
            }

            // 计算当前行剩余字节数
            int remainingInLine = currentLineBytes.length - currentPosition;
            if (remainingInLine <= 0) {
                // 异常情况，跳过这一行
                loadNextLineSafely();
                continue;
            }

            // 复制数据
            int bytesToCopy = Math.min(remainingInLine, len);
            System.arraycopy(currentLineBytes, currentPosition, b, off, bytesToCopy);

            currentPosition += bytesToCopy;
            off += bytesToCopy;
            len -= bytesToCopy;
            totalRead += bytesToCopy;
        }

        return totalRead == 0 ? -1 : totalRead;
    }

    /**
     * 关闭流（清理资源）
     */
    @Override
    public void close() throws IOException {
        synchronized (lock) {
            hasMoreData = false;
            headerLineBytes = null;
            currentLineBytes = null;
            currentPosition = 0;
            headerProcessed = false;
            super.close();
            // 注意：这里不关闭dataIterator，因为它可能被其他地方使用
        }
    }

    /**
     * 获取文件生成统计信息
     */
    public FileGenStats getFileGenStats() {
        fileGenStats.setTotalSize(totalBytesGenerated);
        fileGenStats.setLineCount(lineCount);
        return fileGenStats;
    }
}