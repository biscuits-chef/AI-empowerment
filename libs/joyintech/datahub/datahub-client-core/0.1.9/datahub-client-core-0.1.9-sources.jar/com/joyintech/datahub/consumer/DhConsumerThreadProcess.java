package com.joyintech.datahub.consumer;

import com.joyintech.datahub.model.MsgHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author ChenHao
 * @date 11/25/25 18:09
 */
public class DhConsumerThreadProcess {

    private static final Logger log = LoggerFactory.getLogger(DhConsumerThreadProcess.class);

    private static volatile DhConsumerThreadProcess instance;


    private DhConsumerThreadProcess() {
    }

    public static DhConsumerThreadProcess getInstance(int poolSize, int maxPoolSize, long keepAliveTime, int queueCapacity) {
        if (instance == null) {
            synchronized (DhConsumerThreadProcess.class) {
                if (instance == null) {
                    instance = new DhConsumerThreadProcess();
                    initExecutor(poolSize, maxPoolSize, keepAliveTime, queueCapacity);
                }
            }
        }
        return instance;
    }

    public static DhConsumerThreadProcess getInstance() {
        if (instance == null) {
            throw new IllegalStateException("DhConsumerThreadProcess is not initialized. Please call getInstance with parameters first.");
        }
        return instance;
    }


    // ---------------- 线程池配置 ----------------

    private ExecutorService executor;


    private static void initExecutor(int poolSize, int maxPoolSize, long keepAliveTime, int queueCapacity) {
        instance.executor = new ThreadPoolExecutor(
                poolSize,
                maxPoolSize,
                keepAliveTime,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(queueCapacity),
                new ThreadFactory() {
                    private final AtomicInteger index = new AtomicInteger(1);
                    @Override
                    public Thread newThread(Runnable r) {
                        return new Thread(r, "dh-file-consumer-thread-" + index.getAndIncrement());
                    }
                },
                // 队列满时由调用线程执行
                new ThreadPoolExecutor.CallerRunsPolicy()
        );
    }

    /**
     * 文件通常数据多 独立5线程+10队列处理
     * <p>
     * 提交一个消息处理任务到线程池
     *
     * @param msg 通知
     */
    public void processFile(String msg) {
        log.info("[DhConsumerThreadProcess] Submitting file processing task, message={}", msg);
        executor.submit(() -> {
            try {
                log.info("[DhConsumerThreadProcess] Start processing file message, message={}", msg);
                DhConsumerProcess.getInstance().processFile(msg);
                log.info("[DhConsumerThreadProcess] Finished processing file message, message={}", msg);
            } catch (Throwable e) {
                log.error("[DhConsumerThreadProcess] An exception occurred while processing the message, message={}", msg, e);
            }
        });
        log.info("[DhConsumerThreadProcess] File processing task submitted, message={}", msg);
    }

    /**
     * 与文件处理共享线程池
     * 
     * @param header
     * @param msg
     */
    public void processAttachment(MsgHeader header, String msg) {
        executor.submit(() -> {
            try {
                DhConsumerProcess.getInstance().attachProcess(header, msg);
            } catch (Throwable e) {
                log.error("[DhConsumerThreadProcess] An exception occurred while processing the attachment message, traceId={}, dataCode={}",
                        header.getTraceId(), header.getDataCode(), e);
            }
        });
    }
    

    public static synchronized void shutdown() {
        try {
            instance.executor.shutdown();
            if (!instance.executor.awaitTermination(10, TimeUnit.SECONDS)) {
                instance.executor.shutdownNow();
                log.warn("[DhConsumerThreadProcess] Thread pool forced shutdown");
            }
        } catch (InterruptedException e) {
            instance.executor.shutdownNow();
            log.warn("[DhConsumerThreadProcess] Interrupted when thread pool is closed", e);
        } finally {
            instance.executor = null;
            instance = null;
        }
        log.info("[DhConsumerThreadProcess] Thread pool is closed");
    }

}