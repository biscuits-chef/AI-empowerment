package com.joyintech.datahub.kafka;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.consumer.DhConsumerProcess;
import com.joyintech.datahub.consumer.DhConsumerThreadProcess;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.model.AttachFile;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.MsgHeader;
import com.joyintech.datahub.purview.ConsumerPurview;
import com.joyintech.datahub.util.ConfHolder;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * 此处consumer仅处理 json消息
 * 文件通知topic的consumer在 DataHubFileConsumer 中处理特殊处理
 *
 * @author ChenHao
 * @date 11/4/25 17:08
 */
public class ConsumerWrapper {

    private static final Logger log = LoggerFactory.getLogger(ConsumerWrapper.class);

    private final KafkaConsumer<String, String> consumer;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * ✅ 外部传入共享线程池
     */
    private final ExecutorService executor;
    private volatile boolean running = true;
    /**
     * ✅ 保存线程任务的引用
     */
    private Future<?> taskFuture;

    public ConsumerWrapper(Properties props, String topic, ExecutorService executor) {
        log.info("st:1 ConsumerWrapper init, topic={}; executor={}", topic, executor);
        try {
            this.consumer = new KafkaConsumer<>(props);
            this.consumer.subscribe(Collections.singletonList(topic));
        } catch (Exception e) {
            log.error("ConsumerWrapper init error, topic={}", topic);
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "ConsumerWrapper init error", e);
        }
        this.executor = executor;
        log.info("st:2 init consumer thread start");
        start();
        log.info("st:3 init consumer thread end");
    }

    @SuppressWarnings("java:S3776")
    private void start() {
        log.info("st:2.1 consumer thread submitting task to executor... running flag={}", running);
        // 将任务提交到共享线程池中，但保存 Future
        taskFuture = executor.submit(() -> {
            try {
                while (running) {
                    ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(500));
                    for (ConsumerRecord<String, String> record : records) {
                        try {
                            MsgHeader header = new MsgHeader();
                            Header traceHeader = record.headers().lastHeader(DataHubConstant.TRACE_ID);
                            Header fromAppCodeHeader = record.headers().lastHeader(DataHubConstant.APP_CODE_FROM);
                            Header toAppCodeHeader = record.headers().lastHeader(DataHubConstant.APP_CODE_TO);
                            Header dataCodeHeader = record.headers().lastHeader(DataHubConstant.DATA_CODE);
                            Header versionHeader = record.headers().lastHeader(DataHubConstant.VERSION);
                            Header sendTypeFileHeader = record.headers().lastHeader(DataHubConstant.SEND_TYPE_FILE);
                            Header dataDateHeader = record.headers().lastHeader(DataHubConstant.DATA_DATE);
                            Header sendTypeHeader = record.headers().lastHeader(DataHubConstant.SEND_TYPE);
                            Header attachInfoHeader = record.headers().lastHeader(DataHubConstant.ATTACH_FILE_LIST);
                            if (traceHeader != null) {
                                header.setTraceId(headerValue(traceHeader));
                            }
                            String sendTypeFile = sendTypeFileHeader != null ? new String(sendTypeFileHeader.value(), StandardCharsets.UTF_8) : null;
                            header.setAttachFiles(attachInfoHeader(attachInfoHeader));

                            // 校验消息是否发给自己
                            if (toAppCodeHeader != null) {
                                String toAppCode = headerValue(toAppCodeHeader);
                                String localAppCode = ConfHolder.getInstance().getAppCode();
                                String serverName = ConfHolder.getInstance().getServerName();
                                // appCode 与 appCode_serverName 都无法匹配上toAppCode，则跳过该消息
                                if (!localAppCode.equalsIgnoreCase(toAppCode)
                                        && !(localAppCode + DataHubConstant.GROUP_SEPARATOR + serverName).equalsIgnoreCase(toAppCode)) {
                                    log.info("[ConsumerWrapper] Message not for this appCode, skipping. traceId={}, toAppCode={}",
                                            header.getTraceId(), toAppCode);
                                    consumer.commitSync();
                                    continue;
                                }
                            }

                            if (fromAppCodeHeader != null) {
                                header.setFromAppCode(headerValue(fromAppCodeHeader));
                            }

                            if (sendTypeHeader != null) {
                                header.setSendType(headerValue(sendTypeHeader));
                            }

                            if (versionHeader != null) {
                                header.setVersion(headerValue(versionHeader));
                            }
                            if (dataCodeHeader != null) {
                                header.setDataCode(headerValue(dataCodeHeader));
                            }
                            if (dataDateHeader != null) {
                                header.setDataDate(headerValue(dataDateHeader));
                            }
                            log.debug("[ConsumerWrapper] Consuming message: topic={}, partition={}, offset={}, header=[{}]",
                                    record.topic(), record.partition(), record.offset(), header);

                            String msg = record.value();

                            if (noPurview(header.getDataCode(), header.getVersion())) {
                                log.info("[ConsumerWrapper] No permission to consume message, skipping. header=[{}]", header);
                                consumer.commitSync();
                                continue;
                            }

                            String traceId = header.getTraceId();
                            String dataCode = header.getDataCode();

                            try { // NOSONAR
                                if (LogType.KAFKA_ATTACH.getCode().equalsIgnoreCase(header.getSendType())) {
                                    // Kafka附件消息，提交到处理线程池后再提交offset（保证至少已成功入队）
                                    DhConsumerThreadProcess.getInstance().processAttachment(header, msg);
                                    consumer.commitSync();
                                } else if (StringUtils.isNotEmpty(sendTypeFile) && DataHubConstant.Y_OR_N_Y.equalsIgnoreCase(sendTypeFile)) {
                                    // 文件通知类消息，提交到处理线程池后再提交offset（保证至少已成功入队）
                                    log.debug("[ConsumerWrapper] File notification messages are processed after submission and then committed. traceId={}, dataCode={}", traceId, dataCode);
                                    DhConsumerThreadProcess.getInstance().processFile(msg);
                                    consumer.commitSync();
                                } else {
                                    // 即时消息，先处理再提交offset
                                    DhConsumerProcess.getInstance().processMsg(header, msg);
                                    consumer.commitSync();
                                }
                            } catch (Throwable e) { // NOSONAR
                                // 统一异常日志
                                String msgType;
                                if (LogType.KAFKA_ATTACH.getCode().equalsIgnoreCase(header.getSendType())) {
                                    msgType = "file attachment";
                                } else if (StringUtils.isNotEmpty(sendTypeFile) && DataHubConstant.Y_OR_N_Y.equalsIgnoreCase(sendTypeFile)) {
                                    msgType = "file notification";
                                } else {
                                    msgType = "instant message";
                                }
                                log.error("[ConsumerWrapper] Error processing {} message, traceId={}, dataCode={}", msgType, traceId, dataCode, e);
                            }
                        } catch (WakeupException e) {
                            throw e;
                        } catch (Throwable e) { // NOSONAR
                            log.error("[ConsumerWrapper] Failed to handle record topic={}, partition={}, offset={}. Skipping.",
                                    record.topic(), record.partition(), record.offset(), e);
                            try {
                                consumer.commitSync();
                            } catch (Exception ignored) {
                            }
                        }

                    }
                }
            } catch (WakeupException e) {
                if (running) {
                    log.warn("[ConsumerWrapper] WakeupException while running", e);
                }
                // 正常关闭时会触发，忽略
            } catch (Throwable e) { // NOSONAR
                log.error("[ConsumerWrapper] Error while polling", e);
            } finally {
                try {
                    consumer.close(Duration.ofSeconds(10));
                    log.info("[ConsumerWrapper] Consumer closed cleanly.");
                } catch (Exception e) {
                    log.error("[ConsumerWrapper] Close failed", e);
                }
            }
        });
    }

    private List<AttachFile> attachInfoHeader(Header attachInfoHeader) {
        if (attachInfoHeader == null) {
            return Collections.emptyList();
        }
        byte[] attachFileBytes = attachInfoHeader.value();
        List<AttachFile> attachFileList = Collections.emptyList();
        try {
            if (attachFileBytes != null && attachFileBytes.length > 0) {
                String attachFileJson = new String(attachFileBytes, StandardCharsets.UTF_8);
                attachFileList = objectMapper.readValue(attachFileJson, new TypeReference<List<AttachFile>>() {
                });
            }
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "附件列表反序列化失败", e);
        }
        return attachFileList;
    }

    private String headerValue(Header h) {
        return h.value() == null ? null :
                new String(h.value(), StandardCharsets.UTF_8);
    }

    /**
     * 1、判断consumerPurview里面有值;
     * 2、接收系统的appCode+'_'serverName==appCodeTo
     *
     * @return
     */
    private boolean noPurview(String dataCode, String version) {
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(dataCode, version);
        return consumerConfig == null;
    }

    public void close() {
        if (!running) {
            return;
        }
        running = false;
        consumer.wakeup();
        if (taskFuture != null) {
            try {
                taskFuture.get(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                // 恢复线程中断状态
                Thread.currentThread().interrupt();
                taskFuture.cancel(true);
                log.warn("Consumer thread interrupted while waiting for shutdown");
            } catch (ExecutionException e) {
                log.warn("Consumer task execution error", e);
            } catch (TimeoutException e) {
                taskFuture.cancel(true);
                log.warn("Consumer thread did not exit in time");
            }
        }
    }
}
