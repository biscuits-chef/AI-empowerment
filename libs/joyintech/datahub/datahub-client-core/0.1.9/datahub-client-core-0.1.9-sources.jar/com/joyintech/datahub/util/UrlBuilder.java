package com.joyintech.datahub.util;

import com.joyintech.datahub.model.Address;
import com.joyintech.datahub.model.HandlerLocation;
import com.joyintech.datahub.model.URL;

/**
 * @author ChenHao
 * @date 11/26/25 13:46
 */
public class UrlBuilder {

    private UrlBuilder() {
    }

    public static URL builder(String urlStr) {
        // 去掉协议部分
        String noProtocol = urlStr.replaceFirst("https?://", "");
        // 拆分 host:port 和 path
        String[] hostAndPath = noProtocol.split("/", 2);
        String hostPort = hostAndPath[0];
        String path = hostAndPath.length > 1 ? hostAndPath[1] : "";

        // 拆 host 和 port
        String[] hostPortSplit = hostPort.split(":");
        String host = hostPortSplit[0];
        String port = hostPortSplit.length > 1 ? hostPortSplit[1] : "80";

        // 拆 RootPath 和 MethodPath
        String[] pathParts = path.split("/", 2);
        String rootPath = pathParts[0];
        String methodPath = pathParts.length > 1 ? pathParts[1] : "";

        return URL.builder().setAddress(
                Address.builder()
                        .setHost(host)
                        .setPort(Integer.parseInt(port))
                        .build()
        ).setLocation(HandlerLocation.builder()
                .setMethodPath(methodPath)
                .setRootPath(rootPath)
                .build()).build();
    }

}