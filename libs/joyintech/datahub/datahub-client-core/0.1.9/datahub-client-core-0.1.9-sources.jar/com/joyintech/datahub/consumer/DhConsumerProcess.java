package com.joyintech.datahub.consumer;

import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.delayed.GlobalFileDeleter;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.AttachConFile;
import com.joyintech.datahub.model.AttachFile;
import com.joyintech.datahub.model.MsgHeader;
import com.joyintech.datahub.sdk.InsMsgLogServerLoad;
import com.joyintech.datahub.sdk.InstMsgConsumerRecord;
import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;
import com.joyintech.datahub.subscribe.DhAttachListener;
import com.joyintech.datahub.subscribe.DhInstantMsgListener;
import com.joyintech.datahub.subscribe.DhListener;
import com.joyintech.datahub.subscribe.SubscribeRegister;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.IdUtil;
import com.joyintech.datahub.util.JsonUtil;
import com.joyintech.datahub.util.ObsHttpDownload;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import com.joyintech.datahub.util.TimeUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhConsumerProcess.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 10:40 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DhConsumerProcess {

    private static final Logger log = LoggerFactory.getLogger(DhConsumerProcess.class);

    private static final DhConsumerProcess instance;

    static {
        instance = new DhConsumerProcess();
    }

    private DhConsumerProcess() {

    }

    public static DhConsumerProcess getInstance() {
        return instance;
    }

    /**
     * 处理即时消息类消息
     */
    public void processMsg(MsgHeader msgHeader, String jsonStr) {
        // 消息发送者appCode
        String fromAppCode = msgHeader.getFromAppCode();
        log.debug("接收到DataCode={},version={}的kafka消息", msgHeader.getDataCode(), msgHeader.getVersion());
        try {
            DhListener dhListener = SubscribeRegister.get(msgHeader.getDataCode(), msgHeader.getVersion());
            if (dhListener == null) {
                log.warn("dataCode:{},version:{},未找到对应处理实例;serverName:{}",
                        msgHeader.getDataCode(), msgHeader.getVersion(),
                        ConfHolder.getInstance().getServerName());
                return;
            }
            if (dhListener instanceof DhInstantMsgListener) {
                long startTime = System.currentTimeMillis();
                DhInstantMsgListener<?> dhInstantMsgListener = (DhInstantMsgListener<?>) dhListener;
                msgStartLog(msgHeader, jsonStr);
                try {
                    processInstantMessage(dhInstantMsgListener, jsonStr);
                    long endTime = System.currentTimeMillis();
                    DhcLog.getInstance().info(msgHeader.getTraceId(), LogType.KAFKA_REALTIME, msgHeader.getDataDate(), fromAppCode, msgHeader.getDataCode(),
                            msgHeader.getVersion(), "即时消息接收处理成功", endTime - startTime);
                    msgEndLog(msgHeader.getTraceId(), "S", "处理成功");
                } catch (RuntimeException e) {
                    log.error("dataCode:{},version:{},traceId:{},业务处理发生异常", msgHeader.getDataCode(),
                            msgHeader.getVersion(), msgHeader.getTraceId(), e);
                    long endTime = System.currentTimeMillis();
                    DhcLog.getInstance().error(msgHeader.getTraceId(),
                            LogType.KAFKA_REALTIME,
                            msgHeader.getDataDate(),
                            fromAppCode,
                            msgHeader.getDataCode(),
                            msgHeader.getVersion(),
                            "业务处理发生异常", endTime - startTime, StackTraceFormatUtil.getStackTrace(e));
                    msgEndLog(msgHeader.getTraceId(), "E", "接收即时消息业务处理发生异常,异常简要信息：" + e.getMessage());
                }

            } else {
                log.warn("dataCode:{},version:{},数据接收开发不符合规范", msgHeader.getDataCode(), msgHeader.getVersion());
                DhcLog.getInstance().warn(msgHeader.getTraceId(),
                        LogType.KAFKA_REALTIME,
                        msgHeader.getDataDate(),
                        fromAppCode,
                        msgHeader.getDataCode(),
                        msgHeader.getVersion(),
                        "数据接收开发不符合规范！", 0L);
            }
        } catch (IllegalArgumentException e) {
            log.error("dataCode:{},version:{}无对应的即时消息实现", msgHeader.getDataCode(), msgHeader.getVersion(), e);
            DhcLog.getInstance().error(msgHeader.getTraceId(),
                    LogType.KAFKA_REALTIME,
                    msgHeader.getDataDate(),
                    fromAppCode,
                    msgHeader.getDataCode(),
                    msgHeader.getVersion(),
                    "无对应即时消息实现！", 0L, StackTraceFormatUtil.getStackTrace(e));
        }
    }

    private static <T> void processInstantMessage(DhInstantMsgListener<T> listener, String jsonStr) throws RuntimeException {
        Class<T> entityClass = listener.getDataClass();
        T entity = JsonUtil.fromJson(jsonStr, entityClass);
        listener.onInstantMsg(entity);
    }


    public void processFile(String jsonStr) {
        log.debug("文件监听器接收到消息");
        DhFileDownloadProcess.getInstance().fileProcess(jsonStr);
    }

    /**
     * 功能描述: 即时消息日志开始记录
     */
    private void msgStartLog(MsgHeader msgHeader, String jsonStr) {
        InstantMsgLogDTO logDTO = new InstantMsgLogDTO();
        logDTO.setMsg(jsonStr);
        logDTO.setDataCode(msgHeader.getDataCode());
        logDTO.setTraceId(msgHeader.getTraceId());
        logDTO.setDataVersion(msgHeader.getVersion());
        logDTO.setFromAppCode(msgHeader.getFromAppCode());
        logDTO.setReceiveTime(TimeUtils.now());
        logDTO.setDataDate(msgHeader.getDataDate());
        InstMsgConsumerRecord msgLog = InsMsgLogServerLoad.getInstance().getInstantMsgLog();
        try {
            msgLog.startLog(logDTO);
        } catch (Exception e) {
            //日志记录不能影响主业务逻辑
            log.error("消息traceId:{},开始日志处理出现异常", msgHeader.getTraceId(), e);
        }
    }

    /**
     * 功能描述: 即时消息日志结束记录
     */
    private void msgEndLog(String traceId, String result, String errorMsg) {
        InstMsgConsumerRecord msgLog = InsMsgLogServerLoad.getInstance().getInstantMsgLog();
        try {
            msgLog.endLog(traceId, result, errorMsg);
        } catch (Exception e) {
            //日志记录不能影响主业务逻辑
            log.error("消息traceId:{},处理结果回写日志处理出现异常", traceId, e);
        }
    }

    /**
     * 功能描述: 附件消息处理
     * TODO 结构优化
     *
     * @param msgHeader
     * @param jsonStr
     */
    public void attachProcess(MsgHeader msgHeader, String jsonStr) {
        long startTime = System.currentTimeMillis();
        String fromAppCode = msgHeader.getFromAppCode();
        List<AttachFile> attachFiles = msgHeader.getAttachFiles();
        if (CollectionUtils.isEmpty(attachFiles)) {
            log.warn("附件处理未获取到附件, msgHeader={}", msgHeader);
            // 没有附件就直接返回
            return;
        }
        // 用于失败回滚时清理文件（现在存 AttachConFile）
        List<AttachConFile> attachConFiles = new ArrayList<>();
        String attachTempDirectory = ConfHolder.getInstance().getAttachTempDirectory();
        try {
            if (attachTempDirectory == null || attachTempDirectory.trim().isEmpty()) {
                throw new IllegalStateException("attachTempDirectory is blank");
            }
            for (AttachFile attachFile : attachFiles) {
                String fileSourceName = attachFile.getFileSourceName();
                String fileTmpUrl = attachFile.getFileTmpUrl();
                // 下载文件到临时目录
                String safeFileName = sanitizeFileName(fileSourceName);
                String savePath = buildSavePath(attachTempDirectory, safeFileName);
                File downloadedFile = ObsHttpDownload.downloadFile(fileTmpUrl, savePath, 3);

                // 封装成 AttachConFile
                AttachConFile attachConFile = new AttachConFile();
                attachConFile.setFileSourceName(fileSourceName);
                attachConFile.setFile(downloadedFile);

                // 下载成功后记录 AttachConFile，用于失败回滚
                attachConFiles.add(attachConFile);
                log.info("附件下载成功: fileSourceName={}", fileSourceName);
            }
            DhAttachListener<?> dhListener = (DhAttachListener<?>) SubscribeRegister.get(msgHeader.getDataCode(), msgHeader.getVersion());
            if (dhListener == null) {
                log.warn("dataCode:{},version:{}未找到对应处理实例;serverName:{}", msgHeader.getDataCode(), msgHeader.getVersion(), 
                        ConfHolder.getInstance().getServerName());
                cleanupDownloadedFiles(attachConFiles);
                return;
            }
            processInstantMessage(dhListener, jsonStr, attachConFiles);
            long endTime = System.currentTimeMillis();
            DhcLog.getInstance().info(msgHeader.getTraceId(), LogType.KAFKA_ATTACH, msgHeader.getDataDate(), fromAppCode,
                    msgHeader.getDataCode(), msgHeader.getVersion(), "附件消息接收处理成功", endTime - startTime);
            msgEndLog(msgHeader.getTraceId(), "S", "处理成功");

            List<File> collect = attachConFiles.stream()
                    .map(AttachConFile::getFile)
                    .filter(Objects::nonNull).collect(Collectors.toList());
            GlobalFileDeleter.submit(collect);
	            
        } catch (Exception e) {
            // 下载过程中发生异常，清理已经下载的文件
            cleanupDownloadedFiles(attachConFiles);
            long endTime = System.currentTimeMillis();
            DhcLog.getInstance().error(msgHeader.getTraceId(),
                    LogType.KAFKA_ATTACH,
                    msgHeader.getDataDate(),
                    fromAppCode,
                    msgHeader.getDataCode(),
                    msgHeader.getVersion(),
                    "业务处理发生异常", endTime - startTime, StackTraceFormatUtil.getStackTrace(e));
            msgEndLog(msgHeader.getTraceId(), "E", "接收附件消息业务处理发生异常,异常简要信息：" + e.getMessage());
        }
    }

    private static String buildSavePath(String attachTempDirectory, String fileName) {
        Path dir = Paths.get(attachTempDirectory);
        String finalName = IdUtil.generateStrId() + "_" + fileName;
        return dir.resolve(finalName).toString();
    }

    private static String sanitizeFileName(String fileSourceName) {
        if (fileSourceName == null) {
            return "unknown";
        }
        String normalized = fileSourceName.replace('\\', '/').trim();
        if (normalized.isEmpty()) {
            return "unknown";
        }
        int idx = normalized.lastIndexOf('/');
        String baseName = idx >= 0 ? normalized.substring(idx + 1) : normalized;
        baseName = baseName.replace("\r", "").replace("\n", "");
        if (baseName.isEmpty() || ".".equals(baseName) || "..".equals(baseName)) {
            return "unknown";
        }
        return baseName;
    }

    private static void cleanupDownloadedFiles(List<AttachConFile> attachConFiles) {
        for (AttachConFile attachConFile : attachConFiles) {
            File file = attachConFile.getFile();
            if (file != null && file.exists()) {
                boolean deleted = file.delete();
                if (deleted) {
                    log.info("已删除下载失败的临时文件: {}", file.getAbsolutePath());
                } else {
                    log.warn("删除下载失败的临时文件失败: {}", file.getAbsolutePath());
                }
            }
        }
    }

    private static <T> void processInstantMessage(DhAttachListener<T> listener, String jsonStr, List<AttachConFile> attachConFiles) throws RuntimeException {
        Class<T> entityClass = listener.getDataClass();
        T entity = JsonUtil.fromJson(jsonStr, entityClass);
        listener.onProcess(entity, attachConFiles);
    }

}
