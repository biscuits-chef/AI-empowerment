package com.joyintech.datahub.util;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileMetadata;
import com.joyintech.datahub.purview.ConsumerPurview;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.UnsupportedCharsetException;

/**
 * 文件编码解析工具。
 */
public final class FileEncodingUtil {

    private FileEncodingUtil() {
    }

    public static Charset resolve(String fileEncoding) {
        String encoding = StringUtils.isBlank(fileEncoding)
                ? DataHubConstant.DEFAULT_FILE_ENCODING
                : fileEncoding;
        try {
            return Charset.forName(encoding);
        } catch (IllegalCharsetNameException | UnsupportedCharsetException e) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "不支持的文件编码: " + encoding, e);
        }
    }

    public static Charset resolveConsumerEncoding(String dataCode, String version) {
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(dataCode, version);
        if (consumerConfig == null) {
            return resolve(null);
        }
        return resolve(consumerConfig.getFileEncoding());
    }

    public static Charset resolveFileEncoding(FileMetadata fileMetadata) {
        if (fileMetadata == null) {
            return resolve(null);
        }
        // 文件内容只按消费方配置解析；发送方声明编码仅保留在元数据和日志中。
        return resolveConsumerEncoding(fileMetadata.getDataCode(), fileMetadata.getVersion());
    }
}
