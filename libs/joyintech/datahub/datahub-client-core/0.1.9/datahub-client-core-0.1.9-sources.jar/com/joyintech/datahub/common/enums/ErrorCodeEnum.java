package com.joyintech.datahub.common.enums;

/**
 * 错误码枚举接口
 * 后续业务中可能会新增错误码，所以需要继承该接口
 * date 2025-02-22
 *
 * @author ZY22350
 */
public interface ErrorCodeEnum {
    /**
     * 错误码
     *
     * @return 错误码
     */
    String getCode();

    /**
     * 错误描述
     *
     * @return 错误描述
     */
    String getDesc();
}
