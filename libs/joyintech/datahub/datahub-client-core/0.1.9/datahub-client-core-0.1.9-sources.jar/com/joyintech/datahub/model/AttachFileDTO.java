package com.joyintech.datahub.model;

import java.util.List;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AttachFileDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/3/24 19:07 <br/>
 * Description: 附件文件类型  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AttachFileDTO<T> extends SendBaseDTO {
    /**
     * 文件列表
     */
    private List<OnlyAttachFile> attachFileList;
    /**
     * 业务数据
     */
    private T value;
    /**
     * 附件类型
     */
    private String attachType;

    public List<OnlyAttachFile> getAttachFileList() {
        return attachFileList;
    }

    public void setAttachFileList(List<OnlyAttachFile> attachFileList) {
        this.attachFileList = attachFileList;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public String getAttachType() {
        return attachType;
    }

    public void setAttachType(String attachType) {
        this.attachType = attachType;
    }
}
