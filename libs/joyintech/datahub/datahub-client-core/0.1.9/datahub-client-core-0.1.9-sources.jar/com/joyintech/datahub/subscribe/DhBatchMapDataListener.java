package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.model.FileMetadata;

import java.util.List;
import java.util.Map;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhBatchMapDataListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/12/13 17:27 <br/>
 * Description: 批量MAP数据处理监听器  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhBatchMapDataListener extends DhListener{

    /**
     * 业务批量对象处理逻辑
     */
    void onBatchData(List<Map<Integer,Object>> dataList, FileMetadata metadata);
    /**
     * 批量数据大小，默认1000
     */
    default int getBatch(){
        return 1000;
    }
}
