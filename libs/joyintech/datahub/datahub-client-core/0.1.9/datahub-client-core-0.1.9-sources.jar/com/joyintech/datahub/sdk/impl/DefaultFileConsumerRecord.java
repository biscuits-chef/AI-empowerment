package com.joyintech.datahub.sdk.impl;

import com.joyintech.datahub.model.FileSendNotify;
import com.joyintech.datahub.sdk.FileConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DefaultFileConsumerRecord.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/12/2 14:38 <br/>
 * Description: 默认文件接收处理 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DefaultFileConsumerRecord implements FileConsumerRecord {

    private static final Logger log = LoggerFactory.getLogger(DefaultFileConsumerRecord.class);

    @Override
    public void preFileProcess(FileSendNotify fileSendNotify) {
        log.info("默认文件处理前记录日志：{}", fileSendNotify);
    }

    @Override
    public void endFileProcess(String traceId, String result, String errorMsg) {
        log.info("默认文件处理结果日志：traceId={},result={},errorMsg={}", traceId, result, errorMsg);
    }
}
