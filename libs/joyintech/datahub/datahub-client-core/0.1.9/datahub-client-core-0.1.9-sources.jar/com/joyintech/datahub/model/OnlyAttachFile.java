package com.joyintech.datahub.model;

import java.io.File;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: OnlyAttachFile.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/3/24 19:08 <br/>
 * Description: 纯文件  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class OnlyAttachFile {
    /**
     * 文件源名称
     */
    private String fileSourceName;
    /**
     * 文件
     */
    private File file;

    public String getFileSourceName() {
        return fileSourceName;
    }

    public void setFileSourceName(String fileSourceName) {
        this.fileSourceName = fileSourceName;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
