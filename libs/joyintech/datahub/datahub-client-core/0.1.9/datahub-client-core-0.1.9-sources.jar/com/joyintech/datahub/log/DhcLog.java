package com.joyintech.datahub.log;

import com.joyintech.datahub.log.impl.DhcServerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 日志入口类（支持 destroy）
 *
 * @author ChenHao
 * @date 11/20/25 18:11
 */
public final class DhcLog {

    private static final Logger log = LoggerFactory.getLogger(DhcLog.class);
    private static volatile DhcLogger INSTANCE;

    private DhcLog() {
    }

    /**
     * 获取 Logger
     */
    public static DhcLogger getInstance() {
        if (INSTANCE == null) {
            synchronized (DhcLog.class) {
                if (INSTANCE == null) {
                    INSTANCE = DhcServerLogger.getInstance();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 设置 Logger 实例（可用于框架注入或重新初始化）
     */
    public static synchronized void setInstance(DhcLogger logger) {
        destroyInternal();
        INSTANCE = logger;
    }

    /**
     * 销毁当前 Logger（释放资源，幂等）
     */
    public static synchronized void shutdown() {
        destroyInternal();
        INSTANCE = null;
    }

    /**
     * 内部销毁逻辑
     */
    private static void destroyInternal() {
        if (INSTANCE == null) {
            return;
        }

        try {
            // 如果 Logger 有关闭方法就调用
            if (INSTANCE instanceof DhcServerLogger) {
                ((DhcServerLogger) INSTANCE).destroy();
            }
        } catch (Exception e) {
            // 避免 destroy 时抛异常影响系统
            log.error("Failed to destroy DhcLogger", e);
        }
    }
}
