package com.joyintech.datahub.exception;

import com.joyintech.datahub.common.enums.ErrorCodeEnum;

/**
 * 〈应用业务通用异常〉<br>
 * 〈应用系统中定义的通用业务异常，方便异常拦截使用〉
 *
 * @author ZY22350
 * @date 2025-03-04
 */
public class DataHubException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -231584260894205850L;
    /**
     * 错误编码
     */
    private final String code;
    /**
     * 错误描述
     */
    private final String desc;

    /**
     * 构造方法
     *
     * @param statusEnum 错误枚举
     */
    public DataHubException(ErrorCodeEnum statusEnum) {

        super(statusEnum.getDesc());

        this.code = statusEnum.getCode();

        this.desc = statusEnum.getDesc();

    }

    /**
     * 构造方法
     *
     * @param statusEnum 错误枚举
     * @param errorMsg   错误描述
     */
    public DataHubException(ErrorCodeEnum statusEnum, String errorMsg) {

        super(errorMsg);

        this.code = statusEnum.getCode();
        this.desc = errorMsg;

    }

    /**
     * 构造方法
     *
     * @param statusEnum 错误枚举
     * @param errorMsg   错误描述
     * @param t          异常
     */
    public DataHubException(ErrorCodeEnum statusEnum, String errorMsg, Throwable t) {

        super(errorMsg, t);

        this.code = statusEnum.getCode();

        this.desc = errorMsg;
    }

    /**
     * 构造方法
     *
     * @param code 错误码
     * @param desc 错误描述
     */
    public DataHubException(String code, String desc) {

        super(desc);

        this.code = code;

        this.desc = desc;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @return the codeDesc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * (non-Javadoc)
     *
     * @see Throwable#fillInStackTrace()
     */
    @Override
    public synchronized Throwable fillInStackTrace() {

        return this;
    }

    /**
     * (non-Javadoc)
     *
     * @see Throwable#getMessage()
     */
    @Override
    public String getMessage() {

        return "错误码:" + this.code + ";错误信息:" + super.getMessage();
    }
}
