package com.joyintech.datahub.sdk;

import com.joyintech.datahub.model.FileSendNotify;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileConsumerRecord.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/12/2 13:49 <br/>
 * Description: 文件消费记录  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface FileConsumerRecord {
    /**
     * 文件处理前记录日志
     * @param fileSendNotify 文件发送通知
     */
    void preFileProcess(FileSendNotify fileSendNotify);
    /**
     * 文件处理结果日志
     * @param traceId 日志追踪ID
     * @param result 处理结果 S成功，E失败
     * @param errorMsg 处理错误信息
     */
    void endFileProcess(String traceId,String result,String errorMsg);
}
