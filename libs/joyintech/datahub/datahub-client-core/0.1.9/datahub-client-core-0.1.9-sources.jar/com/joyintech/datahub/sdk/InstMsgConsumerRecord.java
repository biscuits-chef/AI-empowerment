package com.joyintech.datahub.sdk;

import com.joyintech.datahub.sdk.dto.InstantMsgLogDTO;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: InstantMsgLog.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 13:56 <br/>
 * Description: 即时消息日志记录  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface InstMsgConsumerRecord {
    /**
     * 接收到即时消息数据记录日志
     * @param logDTO 日志数据实体
     */
    void startLog(InstantMsgLogDTO logDTO);
    /**
     * 即时消息处理结果日志
     */
    void endLog(String traceId,String result,String errorMsg);
}
