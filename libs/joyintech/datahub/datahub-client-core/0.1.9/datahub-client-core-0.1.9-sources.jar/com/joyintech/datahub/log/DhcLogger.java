package com.joyintech.datahub.log;

import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.model.DhcLogContext;

/**
 * 在线日志，直接上报到 Server，可在控制台直接查看
 * 
 * @author 
 * @since 2020/4/21
 */
public interface DhcLogger {
    
    void info(DhcLogContext context);

    void warn(DhcLogContext context);

    void error(DhcLogContext context);
    
    @Deprecated
    void info(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args);
    @Deprecated
    void info(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args);

    @Deprecated
    void error(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args);
    @Deprecated
    void error(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args);

    @Deprecated
    void warn(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args);
    @Deprecated
    void warn(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args);

}