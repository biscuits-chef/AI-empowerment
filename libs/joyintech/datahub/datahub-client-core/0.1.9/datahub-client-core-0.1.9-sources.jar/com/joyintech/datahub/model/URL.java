package com.joyintech.datahub.model;

import java.io.Serializable;

/**
 * URL
 *
 * @author 
 * @since 2022/12/31
 */
public class URL implements Serializable {
    
    /**
     * remote address
     */
    private Address address;

    /**
     * location
     */
    private HandlerLocation location;

    public URL(Address address, HandlerLocation location) {
        this.address = address;
        this.location = location;
    }

    public URL() {
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public HandlerLocation getLocation() {
        return location;
    }

    public void setLocation(HandlerLocation location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "URL{" +
                "address=" + address +
                ", location=" + location +
                '}';
    }
    
    public static class Builder {
        private Address address;
        private HandlerLocation location;

        public Builder setAddress(Address address) {
            this.address = address;
            return this;
        }

        public Builder setLocation(HandlerLocation location) {
            this.location = location;
            return this;
        }
        public URL build() {
            URL url = new URL();
            url.setAddress(address);
            url.setLocation(location);
            return url;
        }
    }
    public static URL.Builder builder() {
        return new URL.Builder();
    }
    
}
