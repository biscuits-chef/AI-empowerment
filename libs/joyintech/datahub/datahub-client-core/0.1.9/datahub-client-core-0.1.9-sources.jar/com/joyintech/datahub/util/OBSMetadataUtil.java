package com.joyintech.datahub.util;

import com.obs.services.model.ObjectMetadata;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.UploadFileRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: OBSMetadataUtil.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 14:02 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class OBSMetadataUtil {

    private static final Logger log = LoggerFactory.getLogger(OBSMetadataUtil.class);

    private OBSMetadataUtil(){}

    // 埋点元数据键名常量
    public static final String META_DATA_CODE = "x-dh-meta-datacode";
    public static final String META_LINE_COUNT = "x-dh-meta-line-count";
    public static final String META_FILE_VERSION = "x-dh-meta-file-version";
    public static final String META_FILE_SIZE = "x-dh-meta-file-size";
    public static final String META_TRACE_ID = "x-dh-meta-trace-id";

    /**
     * 构建基础埋点元数据
     */
    public static Map<String, String> buildBaseMetadata(String dataCode, long lineCount, long fileSize,String version,
                                                        String traceId) {
        Map<String, String> metadata = new HashMap<>();

        metadata.put(META_DATA_CODE, dataCode);
        metadata.put(META_FILE_VERSION, version);
        metadata.put(META_LINE_COUNT, String.valueOf(lineCount));
        metadata.put(META_FILE_SIZE, String.valueOf(fileSize));
        metadata.put(META_TRACE_ID, traceId);
        return metadata;
    }

    /**
     * 为上传请求添加埋点元数据
     */
    public static void applyMetadata(PutObjectRequest request, Map<String, String> metadata) {
        if (request.getMetadata() == null) {
            request.setMetadata(new ObjectMetadata());
        }

        if (metadata != null) {
            for (Map.Entry<String, String> entry : metadata.entrySet()) {
                request.getMetadata().addUserMetadata(entry.getKey(), entry.getValue());
            }
        }
    }

    public static void applyMetadata(String dataCode,String version,String uuid,PutObjectRequest putRequest){
        Map<String, String> metadata = buildBaseMetadata(dataCode, 0L, 0L,version, uuid);
        applyMetadata(putRequest, metadata);
    }
    /**
     *功能描述: 设置UploadFileRequest头部信息
     */
    public static void applyFileUploadMetadata(String dataCode, String version, String uuid, UploadFileRequest request){
        Map<String,String> metadata = buildBaseMetadata(dataCode,0L,0L,version,uuid);
        if(request.getObjectMetadata() == null){
            request.setObjectMetadata(new ObjectMetadata());
        }
        if (metadata != null) {
            for (Map.Entry<String, String> entry : metadata.entrySet()) {
                request.getObjectMetadata().addUserMetadata(entry.getKey(), entry.getValue());
            }
        }
    }

    public static String getMetaTraceId(ObjectMetadata metadata){
        if(metadataEmpty(metadata)){
            return null;
        }
        return metadata.getUserMetadata(META_TRACE_ID) != null ? (String)metadata.getUserMetadata(META_TRACE_ID) : null;
    }
    //无数据返回0
    public static long getMetaLineCount(ObjectMetadata metadata){
        if(metadataEmpty(metadata)){
            return 0;
        }
        return metadata.getUserMetadata(META_LINE_COUNT) != null ?
                Long.parseLong(metadata.getUserMetadata(META_LINE_COUNT).toString()):0L;
    }
    //取文件大小---此处可能存在不准问题
    public static long getMetaFileSize(ObjectMetadata metadata){
        if(metadataEmpty(metadata)){
            return 0;
        }
        return metadata.getUserMetadata(META_FILE_SIZE) != null ?
                Long.parseLong(metadata.getUserMetadata(META_FILE_SIZE).toString()):0L;
    }
    /**
     * 获取文件MD5值
     */
    public static String getMetaMD5(ObjectMetadata metadata){
        if(metadataEmpty(metadata)){
            return null;
        }
        return MD5Util.cleanObsEtag(metadata.getEtag());
    }

    private static boolean metadataEmpty(ObjectMetadata metadata){
        if(metadata == null){
            log.error("metadata为空，直接返回null");
            return true;
        }
        return false;
    }
}
