package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.util.LocalConfigKeyUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: SubscribeRegister.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 19:29 <br/>
 * Description: 订阅注册器  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class SubscribeRegister {

    private static final Logger log = LoggerFactory.getLogger(SubscribeRegister.class);

    private SubscribeRegister(){

    }
    /**
     * 监听器缓存
     */
    private static final Map<String,DhListener> listenerMap = new ConcurrentHashMap<>();

    /**
     * 注册监听器
     * @param listener 监听器
     */
    public static void register(DhListener listener){
        listenerMap.put(LocalConfigKeyUtil.generateKey(listener.getDataCode(), listener.getDataVersion()),
                listener);
        registerDTO(listener);
    }
    /**
     * 注销监听器
     * @param listener 监听器
     */
    public static void removeRegister(DhListener listener){
        listenerMap.remove(LocalConfigKeyUtil.generateKey(listener.getDataCode(), listener.getDataVersion()));
    }
    /**
     * 注销监听器
     * @param dataCode 数据编码
     * @param dataVersion 数据版本
     */
    public static void removeRegister(String dataCode,String dataVersion){
        listenerMap.remove(LocalConfigKeyUtil.generateKey(dataCode, dataVersion));
    }
    /**
     * 获取监听器
     * @param dataCode 数据码
     * @param dataVersion 数据版本
     * @return 监听器
     * @throws IllegalArgumentException 如果未找到匹配的监听器
     */
    public static DhListener get(String dataCode,String dataVersion) throws IllegalArgumentException{
        return listenerMap.get(LocalConfigKeyUtil.generateKey(dataCode, dataVersion));
    }
    /**
     * 通过listener进行处理
     */
    private static void registerDTO(DhListener listener){
        Class<?> consumerClazz = null;
        if(listener instanceof DhSubscribeDataListener){
            DhSubscribeDataListener<?> dhSubDateListener = (DhSubscribeDataListener<?>)listener;
            consumerClazz =dhSubDateListener.getDataClass();
        }else if(listener instanceof DhSubscribeBatchDataListener){
            DhSubscribeBatchDataListener<?> dhSubDateListener = (DhSubscribeBatchDataListener<?>)listener;
            consumerClazz =dhSubDateListener.getDataClass();
        }
        if(consumerClazz != null){
            DhBaseDTO.checkConstructor(consumerClazz);
        }
    }

    /**
     * 创建DTO实例
     */
    public static <T extends DhBaseDTO> T createDtoInstance(Class<T> dtoClass) {
        try {
            return dtoClass.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            log.error("创建DTO实例失败: " + dtoClass.getName(), e);
            return null;
        }
    }
}
