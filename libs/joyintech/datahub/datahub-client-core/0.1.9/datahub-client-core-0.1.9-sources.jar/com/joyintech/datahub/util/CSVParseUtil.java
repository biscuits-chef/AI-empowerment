package com.joyintech.datahub.util;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: CSVParseUtil.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/4/8 11:21 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class CSVParseUtil {

    private CSVParseUtil() {
        // nothing doing
    }

    /**
     * 智能转换：将自定义分隔符格式转为标准CSV
     * 1. 先按分隔符分割（考虑引号保护）
     * 2. 判断每个字段是否已经是标准CSV格式
     * 3. 对非标准字段进行引号处理
     */
    public static String toStandardCSV(String line, String delimiter)  {
        // 1. 分割字段（保护引号内的分隔符）
        List<String> rawFields = splitRespectingQuotes(line, delimiter);
        // 2. 智能处理每个字段
        List<String> processedFields = new ArrayList<>();
        for (String field : rawFields) {
            processedFields.add(processFieldIntelligently(field));
        }

        // 3. 重新组合为标准CSV
        return joinAsCSV(processedFields);
    }

    /**
     * 分割字符串，保护引号内的分隔符
     */
    private static List<String> splitRespectingQuotes(String line, String delimiter) {
        String[] fields = StringUtils.splitByWholeSeparatorPreserveAllTokens(line, delimiter);
        return Arrays.asList(fields);
    }

    /**
     * 智能处理字段：如果已经是标准CSV格式，不处理；否则添加引号
     */
    private static String processFieldIntelligently(String field) {
        // 空字段
        if (field == null || field.isEmpty()) {
            return "";
        }
        if (field.contains("\n") || field.contains("\r")) {
            field = field.replace("\n", "\\n").replace("\r", "\\r");
        }
        // 检查是否已经是标准CSV格式
        if (isValidCSVField(field)) {
            return field;  // 已经是标准格式，不处理
        }

        // 需要处理：添加引号并转义内部引号
        return quoteField(field);
    }

    /**
     * 判断字段是否已经是有效的CSV格式
     * 规则：
     * 1. 要么被引号正确包围，且内部引号正确转义
     * 2. 没有引号但是有,
     */
    private static boolean isValidCSVField(String field) {

        // 检查是否被引号正确包围
        if (isProperlyQuoted(field)) {
            return true;
        } else {
            return !(field.contains(",") || //特殊,处理
                    field.contains("\"") || // 包含引号本身
                    field.isEmpty());   // 空字段（可选）
        }
    }

    /**
     * 检查字段是否被引号正确包围
     */
    private static boolean isProperlyQuoted(String field) {
        field = field.trim();

        if (field.length() < 2 || field.charAt(0) != '"' || field.charAt(field.length() - 1) != '"') {
            return false;
        }

        String inner = field.substring(1, field.length() - 1);
        int i = 0;

        while (i < inner.length()) {
            if (inner.charAt(i) == '"') {
                // 必须后面还有一个引号
                if (i + 1 >= inner.length() || inner.charAt(i + 1) != '"') {
                    return false;
                }
                i += 2;  // 跳过两个引号
            } else {
                i++;
            }
        }

        return true;
    }

    /**
     * 为字段添加引号
     */
    private static String quoteField(String field) {
        // 转义内部的引号：每个"变成""
        String escaped = field.replace("\"", "\"\"");
        return "\"" + escaped + "\"";
    }

    /**
     * 将字段列表连接为标准CSV
     */
    private static String joinAsCSV(List<String> fields) {
        if (fields.isEmpty()) {
            return "";
        }

        StringBuilder csv = new StringBuilder();
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) {
                csv.append(",");
            }
            csv.append(fields.get(i));
        }
        return csv.toString();
    }

}