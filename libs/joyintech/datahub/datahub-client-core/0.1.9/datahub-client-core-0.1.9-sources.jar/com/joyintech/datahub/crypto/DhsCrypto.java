package com.joyintech.datahub.crypto;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

/**
 * DHS 敏感配置加解密工具。
 *
 * <p>密文格式为 {@code DHS(Base64CipherText)}。未使用 DHS 前缀的配置值保持原样，
 * 便于已有明文配置平滑迁移。</p>
 */
public final class DhsCrypto {

    public static final String PREFIX = "DHS(";
    public static final String PASSWORD_PROPERTY_NAME = "datahub.encryptor.password";
    private static final String SUFFIX = ")";
    private static final String JOYIN = "joyin";
    private static final Logger log = LoggerFactory.getLogger(DhsCrypto.class);

    private DhsCrypto() {
    }

    /**
     * 使用 JVM 参数指定的口令加密；未配置时使用内置默认口令。
     */
    public static String encrypt(String plainText) {
        return encrypt(plainText, configuredPassword());
    }

    /**
     * 加密明文，并增加 DHS 标识。
     *
     * @param plainText 明文
     * @param password 加解密口令
     * @return DHS 格式密文
     */
    public static String encrypt(String plainText, String password) {
        if (plainText == null) {
            throw new IllegalArgumentException("plainText cannot be null");
        }
        try {
            String base64Key = deriveBase64Key(resolvePassword(password));
            return PREFIX + AesCrypto.encrypt(plainText, base64Key) + SUFFIX;
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,
                    "Failed to encrypt DHS value", e);
        }
    }

    /**
     * 使用 JVM 参数指定的口令解密；未配置时使用内置默认口令。
     */
    public static String decrypt(String encryptedValue) {
        if (!isEncrypted(encryptedValue)) {
            throw new IllegalArgumentException("Value must use DHS(...) format");
        }
        String cipherText = encryptedValue.substring(PREFIX.length(),
                encryptedValue.length() - SUFFIX.length());
        try {
            String base64Key = deriveBase64Key(configuredPassword());
            return AesCrypto.decrypt(cipherText, base64Key);
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,
                    "Failed to decrypt DHS value", e);
        }
    }

    /**
     * 解密始终使用 JVM 参数指定的口令；保留该重载以兼容已有调用。
     */
    public static String decrypt(String encryptedValue, String ignoredPassword) {
        return decrypt(encryptedValue);
    }

    /**
     * 带 DHS 标识时解密，否则原样返回。解密口令始终来自 JVM 参数。
     */
    public static String decryptIfNecessary(String value, String ignoredPassword) {
        return decryptIfNecessary(value);
    }

    /**
     * 带 DHS 标识时使用 JVM 口令或默认口令解密，否则原样返回。
     */
    public static String decryptIfNecessary(String value) {
        if (value == null || !value.startsWith(PREFIX)) {
            return value;
        }
        return decrypt(value);
    }

    public static boolean isEncrypted(String value) {
        return value != null
                && value.startsWith(PREFIX)
                && value.endsWith(SUFFIX)
                && value.length() > PREFIX.length() + SUFFIX.length();
    }

    static String resolvePassword(String configuredPassword) {
        if (configuredPassword == null || configuredPassword.trim().isEmpty()) {
            return JOYIN;
        }
        return configuredPassword.trim();
    }

    static String deriveBase64Key(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            byte[] aesKey = Arrays.copyOf(hash, 16);
            return Base64.getEncoder().encodeToString(aesKey);
        } catch (NoSuchAlgorithmException e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,
                    "Failed to derive DHS encryption key", e);
        }
    }

    private static String configuredPassword() {
        String configuredPassword = System.getProperty(PASSWORD_PROPERTY_NAME);
        if (configuredPassword == null || configuredPassword.trim().isEmpty()) {
            log.warn("JVM property {} is not configured; using the built-in default DHS password.",
                    PASSWORD_PROPERTY_NAME);
        } else {
            log.info("Using DHS password from JVM property {}.", PASSWORD_PROPERTY_NAME);
        }
        return resolvePassword(configuredPassword);
    }

}
