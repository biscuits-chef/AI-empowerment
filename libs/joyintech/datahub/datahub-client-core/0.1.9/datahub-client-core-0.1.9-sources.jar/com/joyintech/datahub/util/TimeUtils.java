package com.joyintech.datahub.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author ChenHao
 * @date 11/13/25 15:14
 */
public class TimeUtils {

    private TimeUtils() {
    }

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * 获取当前时间字符串
     */
    public static String now() {
        return LocalDateTime.now().format(DATE_TIME_FORMATTER);
    }
    
    /**
     * 获取当前日期字符串
     */
    public static String today() {
        return LocalDateTime.now().format(DATE_FORMATTER);
    }
    
}