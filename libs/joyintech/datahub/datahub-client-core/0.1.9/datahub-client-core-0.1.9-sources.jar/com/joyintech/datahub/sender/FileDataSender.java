package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.enums.FileFormat;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.exception.NoAccessException;
import com.joyintech.datahub.file.EnhancedLineConverter;
import com.joyintech.datahub.file.FilenameConvertEnum;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.DataSenderDTO;
import com.joyintech.datahub.model.FileGenStats;
import com.joyintech.datahub.model.MultipartReqDTO;
import com.joyintech.datahub.obs.ObsClientHandler;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.*;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.PutObjectResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Iterator;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileDataSender.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 15:20 <br/>
 * Description: 文件数据发送器  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileDataSender extends FileAbstractSender {

    private static final Logger log = LoggerFactory.getLogger(FileDataSender.class);
    private static final FileDataSender instance;

    private static final String DEFAULT_HEADER = "default header line";

    private FileDataSender() {
    }

    static {
        try {
            instance = new FileDataSender();
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "初始化异常", e);
        }
    }

    public static FileDataSender getInstance() {
        return instance;
    }

    /**
     * 功能描述: <br>
     * 发送文件数据到OBS存储桶
     *
     * @param fileDate      业务日期格式为：yyyy-mm-dd
     * @param dataSenderDTO 请求 数据
     * @return com.joyintech.datahub.sender.SendResult
     */
    public <T> SendResult sendData(String fileDate, DataSenderDTO<T> dataSenderDTO) throws NoAccessException {
        if (StringUtils.isBlank(fileDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        return smartSendData(fileDate,dataSenderDTO);
    }

    /**
     * 功能描述: <br>
     * 智能发送文件数据到OBS存储桶，根据文件大小自适应调整缓冲区大小,默认缓冲区大小为2MB,最小缓冲区大小为1MB,最大缓冲区大小为20MB
     *
     * @param fileDate      业务日期格式为：yyyy-mm-dd
     * @param dataSenderDTO 请求 数据
     * @return com.joyintech.datahub.sender.SendResult isSuccess为是否成功标记
     */
    public <T> SendResult smartSendData(String fileDate, DataSenderDTO<T> dataSenderDTO) throws NoAccessException {
        if (StringUtils.isBlank(fileDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        validate(dataSenderDTO);
        long startTime = System.currentTimeMillis();
        ConfDto.ProducerConfig producerConfig = SendPurview.getInstance().sendCheck(dataSenderDTO.getDataCode(), dataSenderDTO.getDataVersion());
        if (StringUtils.equalsIgnoreCase(FileFormat.JSON.name(), producerConfig.getFileType())) {
            return new SendResult("500", "JSON 文件类型必须使用 FileSender 发送", false);
        }
        FilenameConvertEnum simple = FilenameConvertEnum.getDescByCode(producerConfig.getFilenameConventions());
        if (simple != null) {
            String fileUrl = FileUtil.simpleFilename(dataSenderDTO.getDataCode(), dataSenderDTO.getDataVersion(),
                    producerConfig.getDirectory(), FileFormat.valueOf(producerConfig.getFileType().toUpperCase()),
                    producerConfig.getStoreInRoot(), producerConfig.getDatePathMode());
            EnhancedLineConverter<T> converter = new EnhancedLineConverter<>(dataSenderDTO.getFieldExtractor(),
                    FileFormat.valueOf(producerConfig.getFileType().toUpperCase()), producerConfig.getFileSeparator());
            String traceId = IdUtil.generateStrId();
            File tempFile = null;
            try {
                //  创建临时文件
                tempFile = createTempFile(dataSenderDTO.getDataCode(), dataSenderDTO.getDataVersion());
                log.info("创建临时文件: {}", tempFile.getAbsolutePath());

                // SDK 生成的临时文件必须按发送方配置编码写入，确保声明编码与实际字节一致。
                long writeStartTime = System.currentTimeMillis();
                FileGenStats fileStats = writeDataToTempFile(
                        dataSenderDTO.getDataIterator(),
                        converter,
                        tempFile,
                        producerConfig
                );
                long writeEndTime = System.currentTimeMillis();
                log.info("数据写入完成，耗时: {}ms, 大小: {} bytes, 行数: {}",
                        writeEndTime - writeStartTime,
                        tempFile.length(),
                        fileStats.getLineCount()
                );

                long uploadStartTime = System.currentTimeMillis();

                // 抽象类中无此属性。。。
                String eTage;
                String objectKey;
                String bucketName;

                // 判断文件大小，选择上传方式
                if (FileUtil.isFileLargerThanXMB(tempFile)) {
                    // 超过 50MB，走分片 / 断点续传
                    File finalTempFile = tempFile;
                    MultipartReqDTO reqDTO = new MultipartReqDTO();
                    reqDTO.setBucketName(ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName());
                    reqDTO.setFile(finalTempFile);
                    reqDTO.setObjectKey(fileUrl);
                    reqDTO.setDataCode(dataSenderDTO.getDataCode());
                    reqDTO.setVersion(dataSenderDTO.getDataVersion());
                    reqDTO.setTraceId(traceId);
                    CompleteMultipartUploadResult result = RetryUtil.executeWithRetry(() ->ObsUploader.getInstance()
                            .uploadFile(reqDTO),"大文件分片上传");
                    eTage = result.getEtag();
                    objectKey = result.getObjectKey();
                    bucketName = result.getBucketName();
                    // 是否需要设置元数据？
                } else {
                    // 普通上传
                    PutObjectRequest putRequest = new PutObjectRequest(
                            ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(),
                            fileUrl, tempFile);
                    OBSMetadataUtil.applyMetadata(dataSenderDTO.getDataCode(), dataSenderDTO.getDataVersion(),
                            traceId, putRequest);
                    PutObjectResult result = RetryUtil.executeWithRetry(
                            () -> ObsClientHandler.putObject(putRequest),"小文件上传");
                    eTage = result.getEtag();
                    objectKey = result.getObjectKey();
                    bucketName = result.getBucketName();
                    OBSMetadataUtil.applyMetadata(dataSenderDTO.getDataCode(), dataSenderDTO.getDataVersion(), traceId, putRequest);
                }


                long endTime = System.currentTimeMillis();
                log.debug("文件上传完成，耗时: {}ms", endTime - uploadStartTime);
                //发送文件上传成功通知
                FileSenderComplete.sendFileSendCompleteMsg(fileDate, dataSenderDTO.getDataCode(),
                        dataSenderDTO.getDataVersion(), traceId, fileStats, eTage, objectKey, bucketName,
                        producerConfig.getSkipLineOneFlag(), producerConfig.getFileEncoding());
                DhcLog.getInstance().info(traceId,
                        LogType.FILE_PROCESSING,
                        fileDate,
                        dataSenderDTO.getDataCode(),
                        dataSenderDTO.getDataVersion(),
                        "文件发送成功，文件路径：" + fileUrl,
                        endTime - startTime,
                        "文件发送成功");
                SendResult.FileResultInfo fileResultInfo = buildFileResultInfo(eTage, objectKey, bucketName, fileStats);
                return new SendResult("200", "发送成功", true, fileResultInfo);
            } catch (Exception e) {
                log.error("发送数据异常", e);
                long endTime = System.currentTimeMillis();
                DhcLog.getInstance().error(traceId,
                        LogType.FILE_PROCESSING,
                        fileDate,
                        dataSenderDTO.getDataCode(),
                        dataSenderDTO.getDataVersion(),
                        "文件发送失败，文件路径：" + fileUrl,
                        endTime - startTime,
                        StackTraceFormatUtil.getStackTrace(e));
                return new SendResult("500", "发送失败" + e.getMessage(), false);
            } finally {
                cleanupTempFile(tempFile);
            }
        }
        return new SendResult("500", "类型转化异常", false);
    }

    private <T> void validate(DataSenderDTO<T> dataSenderDTO) {
        if (dataSenderDTO == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "dataSenderDTO 不能为空");
        }
        dataSenderDTO.validate();
    }


    /**
     * 创建临时文件
     */
    private File createTempFile(String dataCode, String dataVersion) throws IOException {
        // 1. 获取或创建临时目录
        File tempDir = getOrCreateTempDir();

        // 2. 清理过期的临时文件
        cleanupOldTempFiles(tempDir);

        // 3. 生成唯一的文件名
        String fileName = String.format(
                "datahub_%s_%s_%s_%s.tmp",
                dataCode,
                dataVersion,
                System.currentTimeMillis(),
                IdUtil.generateStrId()
        );

        // 4. 创建文件对象
        File tempFile = new File(tempDir, fileName);

        // 5. 确保文件不存在（避免冲突）
        if (tempFile.exists()) {
            boolean deleted = tempFile.delete();
            if (!deleted) {
                throw new IOException("无法删除已存在的临时文件: " + tempFile.getAbsolutePath());
            }
        }

        return tempFile;
    }

    /**
     * 获取或创建临时目录
     */
    private File getOrCreateTempDir() throws IOException {
        String baseTempDir = ConfHolder.getInstance().getTempDirectory();
        String appTempDir = baseTempDir + File.separator + "datahub_uploads";

        File dir = new File(appTempDir);

        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new IOException("无法创建临时目录: " + appTempDir);
            }
            log.info("创建临时目录: {}", appTempDir);
        }

        // 验证目录是否可访问
        if (!dir.isDirectory()) {
            throw new IOException("临时路径不是目录: " + appTempDir);
        }
        if (!dir.canWrite()) {
            throw new IOException("临时目录不可写: " + appTempDir);
        }

        return dir;
    }

    /**
     * 清理过期的临时文件
     */
    private void cleanupOldTempFiles(File tempDir) {
        try {
            long now = System.currentTimeMillis();
            long maxAge = 24 * 60 * 60 * 1000L; // 24小时
            int deletedCount = 0;

            File[] files = tempDir.listFiles((dir, name) -> name.endsWith(".tmp"));
            if (files == null) {
                return;
            }

            for (File file : files) {
                if (file.isFile() && (now - file.lastModified()) > maxAge) {
                    try {
                        if (file.delete()) {
                            deletedCount++;
                            log.debug("删除过期临时文件: {}", file.getName());
                        }
                    } catch (Exception e) {
                        log.warn("无法删除过期文件: {}", file.getAbsolutePath(), e);
                    }
                }
            }

            if (deletedCount > 0) {
                log.info("清理了 {} 个过期临时文件", deletedCount);
            }

        } catch (Exception e) {
            log.warn("清理临时文件时发生异常", e);
        }
    }

    /**
     * 将数据写入临时文件
     */
    private <T> FileGenStats writeDataToTempFile(Iterator<T> dataIterator,
                                                 EnhancedLineConverter<T> converter,
                                                 File outputFile,
                                                 ConfDto.ProducerConfig producerConfig) throws IOException {

        FileGenStats fileStats = new FileGenStats();
        long totalBytes = 0;
        long lineCount = 0;

        // 检查父目录是否存在
        File parentDir = outputFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                throw new IOException("无法创建文件目录: " + parentDir.getAbsolutePath());
            }
        }

        // 检查磁盘空间
        checkDiskSpace(parentDir);

        // 直接使用发送方配置编码生成文件，不依赖操作系统默认编码。
        Charset charset = FileEncodingUtil.resolve(producerConfig.getFileEncoding());
        byte[] lineSeparatorBytes = System.lineSeparator().getBytes(charset);

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(outputFile), charset),
                4 * 1024 * 1024)) {  // 4MB缓冲区

            // 写入头部行
            if (StringUtils.equals(DataHubConstant.Y_OR_N_N, producerConfig.getSkipLineOneFlag())) {
                writer.write(DEFAULT_HEADER);
                writer.newLine();
                totalBytes += DEFAULT_HEADER.getBytes(charset).length + lineSeparatorBytes.length;
            }

            // 写入数据行
            long lastLogTime = System.currentTimeMillis();
            long startTime = lastLogTime;

            while (dataIterator.hasNext()) {
                T data = dataIterator.next();
                String line = converter.convertToLine(data);

                if (line != null) {
                    writer.write(line);
                    writer.newLine();
                    totalBytes += line.getBytes(charset).length + lineSeparatorBytes.length;
                    lineCount++;
                }

                // 进度日志（每5秒或每10000行）
                long currentTime = System.currentTimeMillis();
                if (lineCount % 10000 == 0 || (currentTime - lastLogTime) > 5000) {
                    double elapsedSeconds = (currentTime - startTime) / 1000.0;
                    double speed = lineCount / elapsedSeconds;

                    log.debug("写入进度: 已处理 {} 行, 速度: {}/秒, 文件大小: {} MB",
                            lineCount,
                            speed,
                            totalBytes / 1024.0 / 1024.0);

                    lastLogTime = currentTime;
                }
            }

            writer.flush();

            long endTime = System.currentTimeMillis();
            log.debug("文件写入完成: 总行数={}, 总大小={} MB, 总耗时={} 毫秒",
                    lineCount,
                    String.format("%.2f", totalBytes / 1024.0 / 1024.0),
                    (endTime - startTime));

        } catch (IOException e) {
            // 写入失败，删除不完整文件
            if (outputFile.exists()) {
                try {
                    outputFile.delete();
                } catch (Exception ex) {
                    log.warn("无法删除不完整的临时文件", ex);
                }
            }
            throw e;
        }

        fileStats.setTotalSize(totalBytes);
        fileStats.setLineCount(lineCount);
        return fileStats;
    }

    /**
     * 检查磁盘空间
     */
    private void checkDiskSpace(File directory) throws IOException {
        if (directory == null) {
            return;
        }

        long freeSpace = directory.getFreeSpace();
        long minRequired = 100 * 1024 * 1024L;  // 至少100MB

        if (freeSpace < minRequired) {
            throw new IOException(String.format(
                    "磁盘空间不足。目录: %s, 可用空间: %.2f MB, 需要至少: %.2f MB",
                    directory.getAbsolutePath(),
                    freeSpace / 1024.0 / 1024.0,
                    minRequired / 1024.0 / 1024.0
            ));
        }
    }

    /**
     * 清理临时文件
     */
    private void cleanupTempFile(File tempFile) {
        if (tempFile == null) {
            return;
        }

        try {
            if (tempFile.exists()) {
                if (tempFile.delete()) {
                    log.debug("成功删除临时文件: {}", tempFile.getAbsolutePath());
                } else {
                    // 标记为退出时删除
                    tempFile.deleteOnExit();
                    log.warn("无法立即删除临时文件，已标记为退出时删除: {}", tempFile.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            log.error("清理临时文件时发生异常: {}", tempFile.getAbsolutePath(), e);
        }
    }

    /**
     * 文件统计信息类
     */
    public static class FileStats {
        private long totalSize;
        private long lineCount;

        public long getTotalSize() {
            return totalSize;
        }

        public void setTotalSize(long totalSize) {
            this.totalSize = totalSize;
        }

        public long getLineCount() {
            return lineCount;
        }

        public void setLineCount(long lineCount) {
            this.lineCount = lineCount;
        }
    }

}
