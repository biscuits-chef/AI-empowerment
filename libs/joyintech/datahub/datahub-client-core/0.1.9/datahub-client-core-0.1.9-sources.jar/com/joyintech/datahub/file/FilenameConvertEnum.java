package com.joyintech.datahub.file;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FilenameConvertEnum.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 15:56 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public enum FilenameConvertEnum {

    SIMPLE("01","简单模式"),
    ;
    private final String code;
    private final String desc;
    FilenameConvertEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public String getCode() {
        return code;
    }
    public String getDesc() {
        return desc;
    }
    public static FilenameConvertEnum getDescByCode(String code) {
        for (FilenameConvertEnum value : FilenameConvertEnum.values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
