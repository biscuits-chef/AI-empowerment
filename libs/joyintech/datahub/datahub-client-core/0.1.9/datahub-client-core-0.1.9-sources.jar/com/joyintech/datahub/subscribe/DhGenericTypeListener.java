package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.util.GenericTypeResolver;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhGenericTypeListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/22 15:56 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhGenericTypeListener<T> extends DhListener{

    Class<T> getDataClass();

    /**
     * 验证泛型类型一致性（默认实现）
     */
    default void isGenericTypeConsistent() {
        boolean result;
        Class<?> actualGenericType = null;
        Class<?> returnedType = null;
        try {
            actualGenericType = GenericTypeResolver.getGenericType(getClass());
            returnedType = getDataClass();
            result = actualGenericType != null && actualGenericType.equals(returnedType);

        } catch (Exception e) {

            result = false;
        }
        if(!result){
            throw new DataHubException(DataHubErrorEnum.EXCEPTION,
                    String.format("泛型类型不一致! 接口泛型: %s, 返回的Class: %s",
                            actualGenericType != null ? actualGenericType.getName() : "未知",
                            returnedType != null ? returnedType.getName() : "null"));
        }
    }
 }
