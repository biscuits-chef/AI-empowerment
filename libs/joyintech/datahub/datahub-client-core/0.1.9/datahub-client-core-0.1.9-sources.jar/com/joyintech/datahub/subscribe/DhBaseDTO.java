package com.joyintech.datahub.subscribe;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhListenerBasicDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 19:08 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public abstract class DhBaseDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 检查子类是否有公共无参构造方法
     */
    public static <T> void checkConstructor(Class<T> clazz) {
        try {
            // 检查是否有公共无参构造方法
            clazz.getConstructor();
        } catch (NoSuchMethodException e) {
            String errorMsg = String.format(
                    "DTO类 %s 必须提供公共无参构造方法。请添加: public %s() {}",
                    clazz.getName(),
                    clazz.getSimpleName()
            );
            throw new IllegalStateException(errorMsg, e);
        }
    }

    public abstract FieldMapping[] fieldMappings();

    /**
     * 从字段数组映射数据到当前对象
     */
    public final void mapFromFields(String[] fields) {
        FieldMapping[] mappings = fieldMappings();
        for (FieldMapping mapping : mappings) {
            if (mapping.index < fields.length) {
                String fieldValue = fields[mapping.index];
                if (StringUtils.isNotBlank(fieldValue)) {
                    mapping.fieldSetter.set(this, fieldValue);
                }
            }
        }
    }

    /**
     * 字段映射配置
     */
    protected static class FieldMapping {
        final int index;
        final FieldSetter fieldSetter;

        public FieldMapping(int index, FieldSetter fieldSetter) {
            this.index = index;
            this.fieldSetter = fieldSetter;
        }
    }

    /**
     * 字段设置器函数式接口
     */
    @FunctionalInterface
    public interface FieldSetter {
        void set(DhBaseDTO obj, String value);
    }

    /**
     * 简化的静态工厂方法
     */
    protected static class Mappings {
        public static MappingBuilder create() {
            return new MappingBuilder();
        }
    }

    protected static class MappingBuilder {
        private final List<FieldMapping> mappings = new ArrayList<>();

        public MappingBuilder map(int index, FieldSetter setter) {
            mappings.add(new FieldMapping(index, setter));
            return this;
        }

        public FieldMapping[] toArray() {
            return mappings.toArray(new FieldMapping[0]);
        }
    }
}
