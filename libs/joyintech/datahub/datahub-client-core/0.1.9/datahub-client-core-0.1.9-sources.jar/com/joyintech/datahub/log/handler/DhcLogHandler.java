package com.joyintech.datahub.log.handler;

import com.joyintech.datahub.log.SafeRunnable;
import com.joyintech.datahub.log.model.LogDTO;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JsonUtil;
import com.joyintech.datahub.util.KafkaProducerHolder;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 日志处理器
 *
 * @author
 * @since 2020/4/21
 */
public class DhcLogHandler {

    private static final Logger log = LoggerFactory.getLogger(DhcLogHandler.class);

    // =================== 单例实现 ===================
    private static volatile DhcLogHandler INSTANCE;

    public static DhcLogHandler getInstance() {
        if (INSTANCE == null) {
            synchronized (DhcLogHandler.class) {
                if (INSTANCE == null) {
                    INSTANCE = new DhcLogHandler();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 强制重新初始化（destroy + init）
     */
    public static synchronized void reinit() {
        if (INSTANCE != null) {
            INSTANCE.destroyInternal();
        }
        INSTANCE = new DhcLogHandler();
    }

    // =================== 成员变量 ===================
    private BlockingQueue<LogDTO> logQueue;
    private Thread submitterThread;
    private volatile boolean running;
    private AtomicReference<String> topicRef;
    private volatile KafkaProducer<String, String> producer;

    private DhcLogHandler() {
        logQueue = new LinkedBlockingQueue<>(10240);
        topicRef = new AtomicReference<>();
        running = true;

        // 初始化配置和 producer
        refreshConfig(ConfHolder.getInstance().getConfDto().getKafka().getInternalKafkaConfig().getLogTopic());

        // 启动后台线程
        submitterThread = new Thread(new LogSubmitter(), "dhc-log-handler-thread");
        submitterThread.setDaemon(true);
        submitterThread.start();
    }

    // =================== 配置加载 ===================
    public void refreshConfig(String logTopic) {
        try {
            // 更新本地缓存
            topicRef.set(logTopic);
            producer = KafkaProducerHolder.getInstance().getProducer();

            log.info("[DhcLogHandler] Kafka Log配置加载成功: topic={}", logTopic);
        } catch (Exception e) {
            log.error("[DhcLogHandler] Kafka配置加载失败", e);
            throw new RuntimeException("Kafka配置初始化失败", e);
        }
    }
    

    /**
     * 提交日志
     */
    public void submitLog(LogDTO logContent) {
        if (!running) {
            log.warn("[DhcLogHandler] Handler 已被销毁，丢弃日志: {}", logContent);
            return;
        }

        if (!logQueue.offer(logContent)) {
            log.warn("[DhcLogHandler] 日志队列已满，丢弃日志: {}", logContent);
        }
    }

    /**
     * =================== 后台线程 ===================
     */
    private class LogSubmitter extends SafeRunnable {
        @Override
        protected void run0() {
            while (running) {
                try {
                    LogDTO dto = logQueue.take();
                    sendToKafka(dto);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    log.info("[DhcLogHandler] Sender线程被中断，退出");
                    break;
                } catch (Exception e) {
                    log.error("[DhcLogHandler] 日志发送异常", e);
                }
            }
        }

        private void sendToKafka(LogDTO dto) {
            KafkaProducer<String, String> localProducer = producer;
            String topic = topicRef.get();

            if (localProducer == null || topic == null) {
                log.warn("[DhcLogHandler] Producer未初始化，丢弃日志: {}", dto);
                return;
            }

            String json = JsonUtil.toJson(dto);
            localProducer.send(new ProducerRecord<>(topic, json), (metadata, exception) -> {
                if (exception != null) {
                    log.warn("[Kafka] 日志发送失败 topic={} error={}", topic, exception.getMessage());
                } else {
                    log.debug("[Kafka] 日志发送成功 topic={} offset={}", metadata.topic(), metadata.offset());
                }
            });
        }
    }

    /**
     * =================== 销毁 ===================
     */
    public static synchronized void shutdown() {
        INSTANCE.destroyInternal();
        INSTANCE = null;
    }

    /**
     * 内部销毁逻辑（幂等）
     */
    private void destroyInternal() {
        if (!running) {
            return;
        }
        running = false;

        // 中断线程
        if (submitterThread != null) {
            try {
                submitterThread.interrupt();
                submitterThread.join(5000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            submitterThread = null;
        }

        // 清空队列
        if (logQueue != null) {
            logQueue.clear();
            logQueue = null;
        }

        // 关闭 producer
        if (producer != null) {
            try {
                producer.close();
            } catch (Exception ignored) {}
            producer = null;
        }

        topicRef = null;
        log.info("[DhcLogHandler] 已销毁");
    }
}