package com.joyintech.datahub.util;

import java.util.UUID;

/**
 * @author ChenHao
 * @date 11/6/25 14:37
 */
public class IdUtil {

    private IdUtil() {
    }
    

    /**
     * 生成 id
     * @return 
     */
    public static String generateStrId() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-", "");
    }

}