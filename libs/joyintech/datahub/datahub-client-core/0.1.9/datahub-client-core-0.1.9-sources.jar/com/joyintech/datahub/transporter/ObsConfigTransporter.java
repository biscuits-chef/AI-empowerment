package com.joyintech.datahub.transporter;

import com.joyintech.datahub.crypto.AesCrypto;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.ObsConfContent;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JsonUtil;
import com.joyintech.datahub.util.ObsClientHolder;
import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.ObsObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * 配置管理：拉取、读本地缓存、写本地缓存
 *
 * @author ChenHao
 * @date 11/4/25 17:07
 */
public class ObsConfigTransporter implements ConfigTransporter {

    private static final Logger log = LoggerFactory.getLogger(ObsConfigTransporter.class);

    private ConfDto confDto;
    
    private final ObsConfContent obsConfContent;

    public ObsConfigTransporter(ObsConfContent obsConfContent) {
        this.obsConfContent = obsConfContent;
    }

    @Override
    public ConfDto fetchConf() {
        // 如果http拉取失败，则使用obs拉取
        ObsClient obsClient = ObsClientHolder.getInstance().getObsConfInternal();
        ByteArrayOutputStream bos = null;
        InputStream input = null;
        try {
            
            // 流式下载
            ObsObject obsObject = obsClient.getObject(obsConfContent.getBucketName(), obsConfContent.getObjectKey());
            // 读取对象内容
            log.info("[DataHubInitializer] Successfully fetched object from OBS: bucket={}, key={}", obsConfContent.getBucketName(), obsConfContent.getObjectKey());
            input = obsObject.getObjectContent();
            byte[] b = new byte[1024];
            bos = new ByteArrayOutputStream();
            int len;
            while ((len = input.read(b)) != -1) {
                bos.write(b, 0, len);
            }
            String s = bos.toString();

            String encrypt = null;
            try {
                encrypt = AesCrypto.decrypt(s, ConfHolder.getInstance().getConfKey());
            } catch (Exception e) {
                log.error("Decrypt configuration failed", e);
                throw new RuntimeException(e);
            }

            confDto = JsonUtil.fromJson(encrypt, ConfDto.class);

        } catch (ObsException e) {
            log.error("[DataHubInitializer] OBS Exception occurred while reading object: bucket={}, key={}", obsConfContent.getBucketName(), obsConfContent.getObjectKey(), e);
            throw new RuntimeException(e);
        } catch (Exception e) {
            log.error("[DataHubInitializer] Error occurred while reading object from OBS: bucket={}, key={}", obsConfContent.getBucketName(), obsConfContent.getObjectKey(), e);
            throw new RuntimeException(e);
        } finally {
            closeQuietly(bos);
            closeQuietly(input);
            // closeQuietly(obsClient);
        }

        if (confDto == null) {
            throw new RuntimeException("[DataHubInitializer] Failed to initialize configuration from OBS.");
        }
        ConfHolder.getInstance().init(confDto);

        ObsClientHolder.getInstance().initObsClient();
        return confDto;
    }

    private static void closeQuietly(AutoCloseable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Exception e) {
                log.warn("[DataHubInitializer] Failed to close resource: ", e);
            }
        }
    }

}
