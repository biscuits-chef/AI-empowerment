package com.joyintech.datahub.enums;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileFormat.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 11:52 <br/>
 * Description: 文件类型 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public enum FileFormat {

    CSV,
    TXT,
    DAT,
    JSON
    ;
    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
