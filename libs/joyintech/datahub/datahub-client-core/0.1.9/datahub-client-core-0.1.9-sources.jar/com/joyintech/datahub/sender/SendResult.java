package com.joyintech.datahub.sender;

/**
 * @author ChenHao
 * @date 11/7/25 15:42
 */
public class SendResult {
    
    private String code;
    
    private String message;
    
    private boolean success;
    
    private FileResultInfo fileResultInfo;
    
    public SendResult(String code, String message, boolean success) {
        this.code = code;
        this.message = message;
        this.success = success;
    }

    public SendResult(String code, String message, boolean success, FileResultInfo fileResultInfo) {
        this.code = code;
        this.message = message;
        this.success = success;
        this.fileResultInfo = fileResultInfo;
    }

    public SendResult() {
    }
    
    public static SendResult success() {
        return new SendResult("200", "Success", true);
    }
    
    public static SendResult failure(String code, String message) {
        return new SendResult(code, message, false);
    }

    /**
     *功能描述: <br>
     * 文件发送结果
     * Author  ZY22350
     * Date 2025/11/10 19:05
     */
    public static class FileResultInfo {
        /**
         * 文件对象名称
         */
        private String objectKey;
        /**
         * 文件大小
         */
        private Long fileSize;
        /**
         * 文件MD5
         */
        private String fileMD5;
        /**
         * 存储桶名称
         */
        private String bucketName;
        /**
         * 文件名
         */
        private String fileName;
        /**
         * 文件行数
         */
        private long lineCount;

        public String getObjectKey() {
            return objectKey;
        }

        public void setObjectKey(String objectKey) {
            this.objectKey = objectKey;
        }

        public Long getFileSize() {
            return fileSize;
        }

        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }

        public String getFileMD5() {
            return fileMD5;
        }

        public void setFileMD5(String fileMD5) {
            this.fileMD5 = fileMD5;
        }

        public String getBucketName() {
            return bucketName;
        }

        public void setBucketName(String bucketName) {
            this.bucketName = bucketName;
        }

        public String getFileName() {
            return fileName;
        }

        public long getLineCount() {
            return lineCount;
        }
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setLineCount(long lineCount) {
            this.lineCount = lineCount;
        }

        @Override
        public String toString() {
            return "FileResultInfo{" +
                    "objectKey='" + objectKey + '\'' +
                    ", fileSize='" + fileSize + '\'' +
                    ", fileMD5='" + fileMD5 + '\'' +
                    ", bucketName='" + bucketName + '\'' +
                    ", fileName='" + fileName + '\'' +
                    ", lineCount=" + lineCount +
                    '}';
        }
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        if("200".equals(code)){
            return true;
        }else {
            return success;
        }
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public FileResultInfo getFileResultInfo() {
        return fileResultInfo;
    }

    public void setFileResultInfo(FileResultInfo fileResultInfo) {
        this.fileResultInfo = fileResultInfo;
    }

    @Override
    public String toString() {
        return "SendResult{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", success=" + success +
                ", fileResultInfo=" + fileResultInfo +
                '}';
    }
}