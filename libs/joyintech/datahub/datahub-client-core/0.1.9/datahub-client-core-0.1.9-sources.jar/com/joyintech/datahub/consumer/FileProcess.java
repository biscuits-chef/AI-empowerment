package com.joyintech.datahub.consumer;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileMetadata;
import com.joyintech.datahub.purview.ConsumerPurview;
import com.joyintech.datahub.subscribe.DhBaseDTO;
import com.joyintech.datahub.subscribe.DhBatchMapDataListener;
import com.joyintech.datahub.subscribe.DhSubscribeBatchDataListener;
import com.joyintech.datahub.subscribe.DhSubscribeDataListener;
import com.joyintech.datahub.util.JsonUtil;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileProcess.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/13 14:18 <br/>
 * Description: 文件类处理  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public abstract class FileProcess {

    private static final Logger log = LoggerFactory.getLogger(FileProcess.class);

    public abstract <T extends DhBaseDTO> void process(FileMetadata fileData,
                                                       DhSubscribeDataListener<T> dataListener,
                                                       File file, String skipHeader,
                                                       String delimiter, String fromAppCode,long startTime);
    public abstract <T extends DhBaseDTO> void process(FileMetadata fileData,
                                                       DhSubscribeBatchDataListener<T> dataListener,
                                                       File file,String skipHeader,
                                                       String delimiter, String fromAppCode,long startTime);
    public abstract void process(FileMetadata fileData,
                                 DhBatchMapDataListener dataListener,
                                 File file,String skipHeader,
                                 String delimiter, String fromAppCode,long startTime);
    protected  <T extends DhBaseDTO> void dataProcess(DhSubscribeDataListener<T> dataListener, T data,
                                                 FileMetadata metadata){
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(metadata.getDataCode()
                ,metadata.getVersion());
        try{
            dataListener.onData(data, metadata);
        }catch(RuntimeException e){
            log.error("{}业务处理，数据:{}异常",dataListener.getClass().getName(), JsonUtil.toJson(data),e);
            //快速失败
            if(StringUtils.equals(DataHubConstant.Y_OR_N_Y,consumerConfig.getFailFast())){
                throw e;
            }
        }
    }

    protected <T extends DhBaseDTO> void batchDataProcess(List<T> list, DhSubscribeBatchDataListener<T> dataListener, FileMetadata metadata){
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(metadata.getDataCode()
                                                                            ,metadata.getVersion());
        try{
            dataListener.onBatchData(list, metadata);
        }catch(RuntimeException e){
            log.error("{}业务批量处理，批量:{}异常",dataListener.getClass().getName(),metadata.getBatchNo(),e);
            //快速失败
            if(StringUtils.equals(DataHubConstant.Y_OR_N_Y,consumerConfig.getFailFast())){
                throw e;
            }
        }
    }
    /**
     *功能描述: Map批量处理
     */
    protected  void batchDataProcess(List<Map<Integer,Object>> list, DhBatchMapDataListener dataListener,
                                     FileMetadata metadata){
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(metadata.getDataCode()
                ,metadata.getVersion());
        try{
            dataListener.onBatchData(list, metadata);
        }catch(RuntimeException e){
            log.error("{}业务批量处理，批量:{}异常",dataListener.getClass().getName(),metadata.getBatchNo(),e);
            //快速失败
            if(StringUtils.equals(DataHubConstant.Y_OR_N_Y,consumerConfig.getFailFast())){
                throw e;
            }
        }
    }


    protected String[] convertRecordToFields(CSVRecord csvRecord) {
        String[] fields = new String[csvRecord.size()];
        for (int i = 0; i < csvRecord.size(); i++) {
            if(csvRecord.get(i) != null){
                fields[i] = csvRecord.get(i).replace("\\r","\r").replace("\\n","\n");
            }else{
                fields[i] = null;
            }
            }
        return fields;
    }

}
