package com.joyintech.datahub.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ScheduledExecutorService;

/**
 * 安全的 runnable，可防止因抛出异常导致周期性任务终止
 * 使用 {@link ScheduledExecutorService} 执行任务时，推荐继承此类捕获并打印异常，避免因为抛出异常导致周期性任务终止
 *
 * @author
 * @since 2023/9/20 15:52
 */
public abstract class SafeRunnable implements Runnable {

    public static final Logger log = LoggerFactory.getLogger(SafeRunnable.class);

    @Override
    public void run() {
        try {
            run0();
        } catch (Exception e) {
            log.error("[SafeRunnable] run failed", e);
        }
    }

    protected abstract void run0();
}
