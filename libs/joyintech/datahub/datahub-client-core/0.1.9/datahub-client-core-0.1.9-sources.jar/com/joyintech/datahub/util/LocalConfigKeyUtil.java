package com.joyintech.datahub.util;

import com.joyintech.datahub.common.constant.DataHubConstant;

/**
 * @author ChenHao
 * @date 11/19/25 17:09
 */
public class LocalConfigKeyUtil {

    private LocalConfigKeyUtil() {
    }
    
    public static String generateKey(String dataCode, String version) {
        return dataCode + DataHubConstant.DEFAULT_PURVIEW_DELIMITER + version;
    }
    
}