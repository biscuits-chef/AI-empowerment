package com.joyintech.datahub.subscribe;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 17:48 <br/>
 * Description: DataHub订阅接口  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhListener {
    /**
     *数据接口编码
     */
    String getDataCode();
    /**
     *数据接口版本
     */
    String getDataVersion();
}
