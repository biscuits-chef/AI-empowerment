package com.joyintech.datahub.model;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.exception.DataHubException;

import java.io.InputStream;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: StreamSenderDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 14:44 <br/>
 * Description: 流式上传文件请求  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class StreamSenderDTO extends SendBaseDTO {

    /**
     * 文件
     */
    private final InputStream stream;
    /**
     * 数据行数
     */
    private final long rowCount;
    /**
     * 文件名
     */
    private final String fileName;
    /**
     * 文件大小
     */
    private final long fileSize;
     /**
      * 构造函数
      */
    public StreamSenderDTO (Builder builder) {
        super.setDataCode(builder.dataCode);
        super.setDataVersion(builder().dataVersion);
        this.stream = builder.stream;
        this.rowCount = builder.rowCount;
        this.fileName = builder.fileName;
        this.fileSize = builder.fileSize;
    }

    public InputStream getStream() {
        return stream;
    }

    public long getRowCount() {
        return rowCount;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public static class Builder {
        private String dataCode;
        private  String dataVersion;
        /**
         * 文件
         */
        private  InputStream stream;
        /**
         * 数据行数
         */
        private  long rowCount;

        private  String fileName;

        private  long fileSize;

        public Builder dataCode(String dataCode) {
            this.dataCode = dataCode;
            return this;
        }
        public Builder dataVersion(String dataVersion) {
            this.dataVersion = dataVersion;
            return this;
        }
        public Builder stream(InputStream stream) {
            this.stream = stream;
            return this;
        }
        public Builder rowCount(long rowCount) {
            this.rowCount = rowCount;
            return this;
        }
        public Builder fileName(String fileName) {
            this.fileName = fileName;
            return this;
        }
        public Builder fileSize(long fileSize) {
            this.fileSize = fileSize;
            return this;
        }
        public StreamSenderDTO build() {
            return new StreamSenderDTO(this);
        }
    }

    public static Builder builder() {
        return new Builder();
    }

    @Override
    public void validate(){
        super.validate();
        if (stream == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"Stream is required");
        }
        if (rowCount <= 0) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"RowCount is required");
        }

        if (fileSize <= 0) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"FileSize is required");
        }
    }
}
