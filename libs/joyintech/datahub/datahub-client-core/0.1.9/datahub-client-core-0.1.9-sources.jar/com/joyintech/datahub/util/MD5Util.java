package com.joyintech.datahub.util;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: MD5Util.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 18:11 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class MD5Util {

    private MD5Util() {
    }

    /**
     * 清洗并校验 OBS ETag
     * <p>
     * - 普通上传：ETag = md5
     * - 分片上传：ETag = md5-partCount
     * <p>
     * 校验规则：
     * - 仅校验 md5 部分是否合法
     * - 返回值保留原始语义（分片不丢 -N）
     */
    public static String cleanObsEtag(String etag) {
        if (etag == null) {
            return null;
        }

        // trim + 去引号
        String cleaned = etag.trim();
        if (cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
            cleaned = cleaned.substring(1, cleaned.length() - 1);
        }

        // 用于校验的 md5（只取 '-' 前 32 位）
        int dashIndex = cleaned.indexOf('-');
        String md5Part = dashIndex > 0 ? cleaned.substring(0, dashIndex) : cleaned;

        // 只校验 md5 部分
        if (!md5Part.matches("^[0-9a-fA-F]{32}$")) {
            throw new IllegalArgumentException("无效的 OBS ETag（MD5 部分非法）: " + etag);
        }

        // 返回完整 ETag（普通 / 分片都保留）
        return cleaned.toLowerCase();
    }

}
