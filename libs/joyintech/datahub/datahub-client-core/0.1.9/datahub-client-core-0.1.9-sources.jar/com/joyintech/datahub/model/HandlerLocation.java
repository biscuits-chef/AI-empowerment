package com.joyintech.datahub.model;

import java.io.Serializable;

/**
 * handler location
 *
 * @author 
 * @since 2022/12/31
 */
public class HandlerLocation implements Serializable {
    /**
     * 根路径
     */
    private String rootPath;
    /**
     * 方法路径
     */
    private String methodPath;


    public String toPath() {
        if (methodPath == null || methodPath.isEmpty()) {
            return "/" + rootPath;
        }
        return "/" + rootPath + "/" + methodPath;
    }
    
    public String getRootPath() {
        return rootPath;
    }

    public void setRootPath(String rootPath) {
        this.rootPath = rootPath;
    }

    public String getMethodPath() {
        return methodPath;
    }

    public void setMethodPath(String methodPath) {
        this.methodPath = methodPath;
    }

    @Override
    public String toString() {
        return "HandlerLocation{" +
                "rootPath='" + rootPath + '\'' +
                ", methodPath='" + methodPath + '\'' +
                '}';
    }
    
    public static class Builder {
        private String rootPath;
        private String methodPath;

        public Builder setRootPath(String rootPath) {
            this.rootPath = rootPath;
            return this;
        }

        public Builder setMethodPath(String methodPath) {
            this.methodPath = methodPath;
            return this;
        }
        public HandlerLocation build() {
            HandlerLocation handlerLocation = new HandlerLocation();
            handlerLocation.setRootPath(rootPath);
            handlerLocation.setMethodPath(methodPath);
            return handlerLocation;
        }
    }
    
    public static HandlerLocation.Builder builder() {
        return new HandlerLocation.Builder();
    }
    
}
