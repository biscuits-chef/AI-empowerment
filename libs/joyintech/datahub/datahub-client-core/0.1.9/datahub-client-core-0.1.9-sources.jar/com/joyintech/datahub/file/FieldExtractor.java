package com.joyintech.datahub.file;

import java.util.List;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FieldExtractor.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 13:38 <br/>
 * Description: 字段提取器 - 业务方实现，从对象中提取字段值  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
@FunctionalInterface
public interface FieldExtractor<T> {

    List<String> extractFields(T data);
}
