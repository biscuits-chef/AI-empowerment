package com.joyintech.datahub.file;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.BiFunction;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: PaginationIterator.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/13 17:58 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class PaginationIterator<T> implements Iterator<T> {
    private final int pageSize;
    private final BiFunction<Integer, Integer, List<T>> pageDataLoader; // 改为 BiFunction
    private int currentPage = 1;
    private List<T> currentBatch;
    private int currentIndex = 0;
    private boolean hasMore = true;

    public PaginationIterator(int pageSize, BiFunction<Integer, Integer, List<T>> pageDataLoader) {
        this.pageSize = pageSize;
        this.pageDataLoader = pageDataLoader;
        loadNextPage();
    }

    private void loadNextPage() {
        // 使用 pageSize 参数
        currentBatch = pageDataLoader.apply(currentPage, pageSize);
        currentIndex = 0;
        currentPage++;

        if (currentBatch == null || currentBatch.isEmpty()) {
            hasMore = false;
            currentBatch = Collections.emptyList();
        }
    }

    @Override
    public boolean hasNext() {
        if (currentIndex < currentBatch.size()) {
            return true;
        }
        if (!hasMore) {
            return false;
        }
        loadNextPage();
        return currentIndex < currentBatch.size();
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return currentBatch.get(currentIndex++);
    }
}