package com.joyintech.datahub.util;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Jackson ObjectMapper
 *
 * @author ChenHao
 * @date 11/4/25 17:09
 */
public class JsonUtil {

    private JsonUtil() {
    }

    private static final Logger log = LoggerFactory.getLogger(JsonUtil.class);

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        // 注册 Java 8 时间模块，支持 LocalDateTime、LocalDate、LocalTime 等
        MAPPER.registerModule(new JavaTimeModule());
        // 序列化为 ISO 格式，而不是时间戳
        MAPPER.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        // 忽略强校验 ConfDto多的字段 
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    }

    /**
     * 对象转 JSON 字符串
     */
    public static String toJson(Object obj) {
        try {
            return MAPPER.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("JsonUtil toJson error", e);
            return null;
        }
    }

    /**
     * JSON 字符串转对象
     *
     * @param json  JSON 字符串
     * @param clazz 目标类型
     * @param <T>   泛型
     * @return T 对象，如果解析失败返回 null
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        if (StringUtils.isBlank(json)) {
            return null;
        }
        json = json.trim();
        try {
            // 尝试直接解析
            return MAPPER.readValue(json, clazz);
        } catch (Exception e) {
            log.warn("Direct JSON parse failed, trying to unwrap a quoted JSON value");

            // 异常后尝试拆一层 String，再解析
            try {
                String unwrapped = unwrapJson(json);
                return MAPPER.readValue(unwrapped, clazz);
            } catch (Exception ex) {
                log.error("JsonUtil fromJson failed even after unwrap", ex);
                return null;
            }
        }
    }

    /**
     * 拆一层 JSON 字符串，如果外层是双引号包裹
     *
     * @param json 原始 JSON
     * @return 拆完的 JSON
     */
    private static String unwrapJson(String json) throws JsonProcessingException {
        String unwrapped = json;
        // 最多拆两层，防止死循环
        for (int i = 0; i < 2; i++) {
            unwrapped = MAPPER.readValue(unwrapped, String.class).trim();
            if (!(unwrapped.startsWith("\"") && unwrapped.endsWith("\""))) {
                break;
            }
        }
        return unwrapped;
    }
    
}
