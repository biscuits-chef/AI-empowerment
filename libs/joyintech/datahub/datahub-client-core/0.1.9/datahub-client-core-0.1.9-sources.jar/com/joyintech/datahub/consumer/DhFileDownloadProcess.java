package com.joyintech.datahub.consumer;

import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.enums.FileFormat;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileMetadata;
import com.joyintech.datahub.model.FileSendNotify;
import com.joyintech.datahub.obs.ObsClientHandler;
import com.joyintech.datahub.purview.ConsumerPurview;
import com.joyintech.datahub.subscribe.*;
import com.joyintech.datahub.util.*;
import com.obs.services.exception.ObsException;
import com.obs.services.model.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhFileDownloadProcess.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 15:24 <br/>
 * Description: 文件下载类订阅处理  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class DhFileDownloadProcess {

    private static final Logger log = LoggerFactory.getLogger(DhFileDownloadProcess.class);

    private DhFileDownloadProcess(){}

    private static final DhFileDownloadProcess instance;

    static {
        instance = new DhFileDownloadProcess();
    }

    public static DhFileDownloadProcess getInstance(){
        return instance;
    }
    //csv文件处理
    private final CsvFileProcess csvFileProcess = new CsvFileProcess();
    //其他文件处理
    private final OtherFileProcess otherFileProcess = new OtherFileProcess();
    /**
     * 文件处理入口
     * */
    public void fileProcess(String jsonStr){
        FileSendNotify fileSendNotify = FileSenderComplete.parseJson(jsonStr);
        if(validator(fileSendNotify)){
            //获取处理实例
            DhListener listener = SubscribeRegister.get(fileSendNotify.getDataCode(), fileSendNotify.getDataVersion());
            if (listener == null) {
                log.warn("dataCode:{},version:{},未找到对应处理实例;serverName:{}",
                        fileSendNotify.getDataCode(),fileSendNotify.getDataVersion(),
                        ConfHolder.getInstance().getServerName());
                return;
            }
            DhFileListener fileLister = null;
            DhSubscribeBatchDataListener<?> batchDataListener = null;
            DhSubscribeDataListener<?> dataListener = null;
            DhBatchMapDataListener mapDataListener = null;
            boolean existListener = true;
            if(listener instanceof DhFileListener){
                fileLister = (DhFileListener) listener;
            }else if(listener instanceof DhSubscribeBatchDataListener){
                batchDataListener = (DhSubscribeBatchDataListener<?>) listener;
            }else if(listener instanceof DhSubscribeDataListener){
                dataListener = (DhSubscribeDataListener<?>) listener;
            }else if(listener instanceof DhBatchMapDataListener){
                mapDataListener = (DhBatchMapDataListener) listener;
            }else{
                existListener = false;
            }
            
            FileFormat fileFormat = FileUtil.detectFileFormat(fileSendNotify.getSourceFileName());
            ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(
                    fileSendNotify.getDataCode(), fileSendNotify.getDataVersion());
            boolean jsonFile = FileFormat.JSON == fileFormat
                    || (consumerConfig != null && StringUtils.equalsIgnoreCase(FileFormat.JSON.name(),
                    consumerConfig.getFileType()));
            if(fileFormat == null && !jsonFile){
                DhcLog.getInstance().warn(fileSendNotify.getTraceId(),
                        LogType.FILE_PROCESSING,
                        fileSendNotify.getDataDate(),
                        fileSendNotify.getFormAppCode(),
                        fileSendNotify.getDataCode(),
                        fileSendNotify.getDataVersion(),
                        "文件格式不支持", 0L);
                log.warn("dataCode:{},version:{},文件格式不支持",fileSendNotify.getDataCode(),fileSendNotify.getDataVersion());
                FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(),
                        "E","文件格式不支持");
                return;
            }
            if (jsonFile && fileLister == null) {
                String errorMsg = "JSON 文件类型必须使用 DhFileListener 消费";
                DhcLog.getInstance().error(fileSendNotify.getTraceId(),
                        LogType.FILE_PROCESSING,
                        fileSendNotify.getDataDate(),
                        fileSendNotify.getFormAppCode(),
                        fileSendNotify.getDataCode(),
                        fileSendNotify.getDataVersion(),
                        errorMsg, 0L);
                log.error("dataCode:{},version:{},{}", fileSendNotify.getDataCode(),
                        fileSendNotify.getDataVersion(), errorMsg);
                FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(), "E", errorMsg);
                return;
            }
            if(existListener) {
                File f = null;
                Path localPath = downloadFileToStorage(fileSendNotify);
                if (localPath == null) {
                    FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(), "E", "临时文件处理失败");
                    return;
                }
                long startTime = System.currentTimeMillis();
                f = downloadFile(localPath, fileSendNotify);
                if (f == null) {
                    return;
                }

                if (fileLister != null) {
                    fileProcess(fileLister, fileSendNotify,localPath,startTime);
                } else {
                    switch (fileFormat) {
                        case CSV:
                            csvDataProcess(dataListener, batchDataListener, mapDataListener, fileSendNotify,localPath
                                    ,startTime);
                            break;
                        case TXT:
                        case DAT:
                            otherDataProcess(dataListener, batchDataListener, mapDataListener, fileSendNotify,localPath
                                    ,startTime);
                            break;
                        case JSON:
                            log.error("dataCode:{},version:{},JSON 文件类型必须使用 DhFileListener 消费",
                                    fileSendNotify.getDataCode(), fileSendNotify.getDataVersion());
                            FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(), "E",
                                    "JSON 文件类型必须使用 DhFileListener 消费");
                            break;
                        default:
                            log.warn("dataCode:{},version:{},文件格式不支持", fileSendNotify.getDataCode(), fileSendNotify.getDataVersion());

                            break;
                    }
                }
            }

        }
    }

    /**
     * csv文件处理
     * @param dataListener 订阅数据监听
     * @param batchListener 订阅批量数据监听
     * @param notify 文件发送通知
     */
    private void csvDataProcess(DhSubscribeDataListener<?> dataListener,
                                DhSubscribeBatchDataListener<?> batchListener,
                                DhBatchMapDataListener mapDataListener,
                                FileSendNotify notify,Path path,long startTime){

        FileMetadata fileMetadata = builder(notify, null);
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(notify.getDataCode(),
                notify.getDataVersion());
        String delimiter = consumerConfig.getFileSeparator();
        String skipHeader = consumerConfig.getSkipLineOneFlag();
        if(StringUtils.isBlank(delimiter)){
            delimiter = ",";
        }else{
            if(delimiter.length() > 1){
                log.warn("csv文件分隔符只能有一个字符，当前长度大于1，采用默认,进行处理");
                delimiter = ",";
            }
        }
        try {
            if (batchListener != null) {
                csvFileProcess.process(fileMetadata, batchListener, path.toFile(), skipHeader,delimiter,
                        notify.getFormAppCode(),startTime);
            } else if(mapDataListener != null){
                csvFileProcess.process(fileMetadata,mapDataListener,path.toFile(),skipHeader,delimiter,
                        notify.getFormAppCode(),startTime);
            }else {
                csvFileProcess.process(fileMetadata, dataListener, path.toFile(), skipHeader, delimiter,
                        notify.getFormAppCode(),startTime);
            }
        }catch (Exception e){
            log.error("csv处理",e);
        }finally {
            cleanupFile(path.toFile(),notify.getTraceId(),"处理完成文件删除");
        }
    }

    /**
     * 其他文件处理
     * @param dataListener 订阅数据监听
     * @param batchListener 订阅批量数据监听
     * @param notify 文件发送通知
     */
    private void otherDataProcess(DhSubscribeDataListener<?> dataListener,
                                  DhSubscribeBatchDataListener<?> batchListener,
                                  DhBatchMapDataListener mapDataListener,
                                  FileSendNotify notify,Path path,long startTime){
        FileMetadata fileMetadata = builder(notify, null);
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(notify.getDataCode(),
                notify.getDataVersion());
        String delimiter = consumerConfig.getFileSeparator();
        String skipHeader = consumerConfig.getSkipLineOneFlag();

        try {
            if (batchListener != null) {
                otherFileProcess.process(fileMetadata, batchListener, path.toFile(),skipHeader, delimiter,
                        notify.getFormAppCode(),startTime);
            } else if(mapDataListener != null){
                otherFileProcess.process(fileMetadata,mapDataListener,path.toFile(),skipHeader,delimiter,
                        notify.getFormAppCode(),startTime);
            }else {
                otherFileProcess.process(fileMetadata, dataListener, path.toFile(),skipHeader, delimiter,
                        notify.getFormAppCode(),startTime);
            }
        }catch (Exception e){
            log.error("其他文件处理发生异常",e);

        }finally {
            cleanupFile(path.toFile(), notify.getTraceId(), "删除临时下载文件");
        }

    }

    /**
     * 文件处理入口
     * @param dhFileListener
     * @param fileSendNotify
     */
    private void fileProcess(DhFileListener dhFileListener,FileSendNotify fileSendNotify,Path path,long startTime){

        try {
            dhFileListener.onFile(path.toFile(), builder(fileSendNotify, Files.size(path)));
            DhcLog.getInstance().info(fileSendNotify.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileSendNotify.getDataDate(),
                    fileSendNotify.getFormAppCode(),
                    fileSendNotify.getDataCode(),
                    fileSendNotify.getDataVersion(),
                    "文件处理完成",
                    System.currentTimeMillis() - startTime,
                    "文件处理完成");
            FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(),
                    "S","文件处理完成");
        }catch(Exception e){
            log.error("文件:{},traceId:{}业务处理异常",fileSendNotify.getSourceFileName(),fileSendNotify.getTraceId(),e);
            DhcLog.getInstance().error(fileSendNotify.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileSendNotify.getDataDate(),
                    fileSendNotify.getFormAppCode(),
                    fileSendNotify.getDataCode(),
                    fileSendNotify.getDataVersion(),
                    "文件处理异常",
                    System.currentTimeMillis() - startTime,
                    StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(),
                    "E","文件处理异常"+ e.getMessage());
        }finally {
            cleanupFile(path.toFile(), fileSendNotify.getTraceId(), "业务处理结束删除文件");
        }
    }

    /**
     * 下载文件到临时目录
     * @param fileSendNotify 文件发送通知
     * @return 文件路径
     */
    private Path downloadFileToStorage(FileSendNotify fileSendNotify){
        try {
            if(!validateFile(fileSendNotify)){
                return null;
            }
            String tmpPath = ConfHolder.getInstance().getTempDirectory();
            String filePath = generateFilePath(tmpPath, fileSendNotify);
            Path localPath = Paths.get(filePath);
            Files.createDirectories(localPath.getParent());
            return localPath;
        }catch (IOException e){
            log.error("traceId:{}创建下载临时文件异常",fileSendNotify.getTraceId(),e);
            DhcLog.getInstance().error(fileSendNotify.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileSendNotify.getDataDate(),
                    fileSendNotify.getFormAppCode(),
                    fileSendNotify.getDataCode(),
                    fileSendNotify.getDataVersion(),
                    "创建下载临时文件异常", 0L, StackTraceFormatUtil.getStackTrace(e));
        }
        return null;
    }

    private File downloadFile(Path path,FileSendNotify fileSendNotify){
        File tempFile = path.toFile();
        Charset consumerEncoding;
        try {
            // 下载前校验消费方编码，配置无效时不得继续下载或回调业务监听器。
            consumerEncoding = FileEncodingUtil.resolveConsumerEncoding(
                    fileSendNotify.getDataCode(), fileSendNotify.getDataVersion());
        } catch (RuntimeException e) {
            log.error("OBS文件消费编码配置无效，objectKey:{}，消费方配置编码:{}",
                    fileSendNotify.getObjectKey(), getConsumerEncoding(fileSendNotify), e);
            cleanupFile(tempFile, fileSendNotify.getTraceId(), "消费编码配置无效删除文件");
            FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(),
                    "E","文件消费编码配置无效");
            return null;
        }

        try {
            DownloadFileRequest request = new DownloadFileRequest(fileSendNotify.getBucket(),
                    fileSendNotify.getObjectKey());
            // 设置本地文件路径
            request.setDownloadFile(tempFile.getAbsolutePath());
            // 设置分段大小为10MB
            request.setPartSize(10 * 1024 * 1024);
            // 设置最大并发数
            request.setTaskNum(5);
            // 开启断点续传模式
            request.setEnableCheckpoint(true);
            // 执行下载
            DownloadFileResult result = ObsClientHolder.getInstance().getReader().downloadFile(request);
            logFileEncoding(fileSendNotify, consumerEncoding);
            log.info("OBS文件下载完成，objectKey:{}，ETag: {}",
                    fileSendNotify.getObjectKey(), result.getObjectMetadata().getEtag());
        } catch (ObsException e) {
            log.error("OBS文件下载失败",e);
            cleanupFile(tempFile, fileSendNotify.getTraceId(), "业务处理结束删除文件");
            FileConsumerHandler.postFileRecord(fileSendNotify.getTraceId(),
                    "E","文件下载出现异常");
            return null;
        }
        return tempFile;
    }

    private void logFileEncoding(FileSendNotify notify, Charset consumerEncoding) {
        log.info("OBS文件编码信息，objectKey:{}，发送方声明编码:{}，消费方配置编码:{}，SDK实际读取编码:{}",
                notify.getObjectKey(), notify.getFileEncoding(), getConsumerEncoding(notify),
                consumerEncoding.name());
    }

    private String getConsumerEncoding(FileSendNotify notify) {
        ConfDto.ConsumerConfig consumerConfig = ConsumerPurview.getInstance().getConsumerConfig(
                notify.getDataCode(), notify.getDataVersion());
        return consumerConfig == null ? null : consumerConfig.getFileEncoding();
    }

    /**
     * 验证文件
     * @param metadata 文件元数据
     * @param notify 文件发送通知
     * @return 是否验证通过
     */
     private boolean validateFile(ObjectMetadata metadata, FileSendNotify notify){
        String md5Value = OBSMetadataUtil.getMetaMD5(metadata);
        String traceId = OBSMetadataUtil.getMetaTraceId(metadata);
        if(StringUtils.equals(md5Value,notify.getFileMD5Value())){
            return true;
        }
        log.warn("文件：{},traceId:{}获取MD5值不一致",notify.getObjectKey(),traceId);
        return false;
    }

    private boolean validateFile(FileSendNotify fileSendNotify){
        try {
            ObsObject object = ObsClientHandler.getObject(builderGob(fileSendNotify.getBucket(), fileSendNotify.getObjectKey()));
            if (!validateFile(object.getMetadata(), fileSendNotify)) {
                DhcLog.getInstance().warn(fileSendNotify.getTraceId(),
                        LogType.FILE_PROCESSING,
                        fileSendNotify.getDataDate(),
                        fileSendNotify.getFormAppCode(),
                        fileSendNotify.getDataCode(),
                        fileSendNotify.getDataVersion(),
                        "文件验证失败，MD5值不一致", 0L);
                log.warn("文件：{},traceId:{}验证失败，MD5值不一致",fileSendNotify.getObjectKey(),fileSendNotify.getTraceId());
                return false;
            }
            return true;
        }catch(Exception e){
            log.error("下载文件:{}出现异常",fileSendNotify.getObjectKey(),e);
            DhcLog.getInstance().error(fileSendNotify.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileSendNotify.getDataDate(),
                    fileSendNotify.getFormAppCode(),
                    fileSendNotify.getDataCode(),
                    fileSendNotify.getDataVersion(),
                    "下载文件出现异常", 0L, StackTraceFormatUtil.getStackTrace(e));
        }
        return false;
    }

    /**
     * 清理文件
     */
    private void cleanupFile(File file, String traceId, String reasonMsg) {
        if (file == null || !file.exists()) {
            return;
        }

        try {
            boolean deleted = Files.deleteIfExists(file.toPath());
            if (deleted) {
                log.info("[{}] 文件已清理: {} (原因: {})", traceId, file.getAbsolutePath(), reasonMsg);
            } else {
                log.warn("[{}] 文件清理失败，文件不存在: {}", traceId, file.getAbsolutePath());
            }
        } catch (IOException e) {
            log.error("[{}] 文件清理异常: {}", traceId, file.getAbsolutePath(), e);
        }
    }

    /**
     * 构建文件元数据
     */
    FileMetadata builder(FileSendNotify notify,Long fileSize){
        FileMetadata fmd = new FileMetadata();
        fmd.setFileName(notify.getSourceFileName());
        fmd.setFileSize(fileSize != null ? fileSize : notify.getFileSize());
        fmd.setDataCode(notify.getDataCode());
        fmd.setVersion(notify.getDataVersion());
        fmd.setFromAppCode(notify.getFormAppCode());
        fmd.setTraceId(notify.getTraceId());
        fmd.setLineCount(notify.getLineCount());
        fmd.setDataDate(notify.getDataDate());
        // 文件级回调按照消费方配置读取原始文件，元数据必须传递相同的有效编码。
        fmd.setFileEncoding(FileEncodingUtil.resolveConsumerEncoding(
                notify.getDataCode(), notify.getDataVersion()).name());
        return fmd;
    }
    /**
     * 生成文件名
     * 采用：基础目录/consumer/yyyy-mm-dd/traceId/fileName模式
     */
    private String generateFilePath(String tempPath,FileSendNotify sendNotify){
        String dateStr = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        return  String.format("%s/%s/%s/%s/%s",tempPath,"consumer",dateStr,sendNotify.getTraceId(),
                sendNotify.getSourceFileName());
    }


    /**
     * 构建obs对象获取请求
     * @param bucketName 桶名
     * @param objectKey 对象键
     * @return GetObjectRequest
     */
    private GetObjectRequest builderGob(String bucketName,String objectKey){
        GetObjectRequest gob = new GetObjectRequest();
        gob.setBucketName(bucketName);
        gob.setObjectKey(objectKey);
        return gob;
    }

    /**
     * 验证文件发送通知消息
     * @param fileSendNotify 文件发送通知
     * @return 是否验证通过
     */
    private boolean validator(FileSendNotify fileSendNotify){
        boolean validate = true;
        if(fileSendNotify == null){
            log.warn("文件通知消息解析失败");
           return false;
        }
        if(StringUtils.isBlank(fileSendNotify.getDataCode())){
            log.warn("文件通知消息数据编码为空");
            validate = false;
        }
        if(StringUtils.isBlank(fileSendNotify.getDataVersion())){
            log.warn("文件通知消息数据版本为空");
            validate = false;
        }
        if(StringUtils.isBlank(fileSendNotify.getObjectKey())){
            log.warn("文件通知消息objectKey为空");
            validate = false;
        }
        return validate;
    }
}
