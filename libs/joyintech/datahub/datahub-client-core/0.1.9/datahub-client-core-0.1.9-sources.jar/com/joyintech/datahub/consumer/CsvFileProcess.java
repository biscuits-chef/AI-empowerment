package com.joyintech.datahub.consumer;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.FileMetadata;
import com.joyintech.datahub.subscribe.*;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.FileEncodingUtil;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: CsvFileProcess.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/13 9:33 <br/>
 * Description: CSV格式文件解析  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class CsvFileProcess extends FileProcess{

    private static final Logger log = LoggerFactory.getLogger(CsvFileProcess.class);

    @Override
    public <T extends DhBaseDTO> void process(FileMetadata fileData,DhSubscribeDataListener<T> dataListener,
                                              File csvFile,String skipHeader,
                                              String delimiter, String fromAppCode,long startTime){
        log.info("单条数据处理开始:{}",fileData.getFileName());
        char delimiterChar = delimiter.charAt(0);
        try(Reader reader = new InputStreamReader(new FileInputStream(csvFile),
                FileEncodingUtil.resolveFileEncoding(fileData));
            CSVParser parser = CSVParser.parse(reader,
                    CSVFormat.DEFAULT.withIgnoreEmptyLines(true)
                            .withDelimiter(delimiterChar)
                            .withTrim(false))) {
            Iterator<CSVRecord> iterator = parser.iterator();
            int rowNumber = 1;
            boolean skip= StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirst=true;
            // 是否有数据标识
            boolean hasData = false;
            while(iterator.hasNext()){
                CSVRecord csvRecord = iterator.next();
                if(isFirst && skip){
                    isFirst=false;
                    continue;
                }
                // 将CSV记录转换为字段数组
                String[] fields = convertRecordToFields(csvRecord);
                T data = SubscribeRegister.createDtoInstance(dataListener.getDataClass());
                if (data != null) {
                    hasData = true;
                    data.mapFromFields(fields);
                    fileData.setRowNumber(rowNumber);
                    dataProcess(dataListener, data, FileMetadata.copyOf(fileData));
                }
                rowNumber++;
            }
            if (!hasData && ConfHolder.getInstance().notifyIfEmpty()) {
                fileData.setRowNumber(0);
                // 文件为空 或 只有表头
                dataProcess(dataListener, null, FileMetadata.copyOf(fileData));
            }
        } catch (Throwable e) {//NOSONAR
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "csv文件下载处理异常", System.currentTimeMillis() - startTime, StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E","csv文件单条数据处理异常，" + e.getMessage());
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "csv文件单条处理异常",e);
        }
        long endTime = System.currentTimeMillis();
        log.info("单条数据处理结束:{},耗时:{}ms",fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "csv文件处理正常完成", endTime - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S","csv文件单条数据处理完成");
    }
    /**
     * 处理批量数据
     * @param fileData 文件元数据
     * @param dataListener 批量数据监听器
     * @param csvFile 文件
     * @param skipHeader 是否跳过头数据
     * @param delimiter 分隔符
     * @param fromAppCode 来源
     */
    public <T extends DhBaseDTO> void process(FileMetadata fileData, DhSubscribeBatchDataListener<T> dataListener,
                                              File csvFile, String skipHeader,
                                              String delimiter, String fromAppCode,long startTime){
        int batchSize = dataListener.getBatch();
        List<T> dataList = new ArrayList<>(batchSize);
        int batchNo = 0;
        char delimiterChar = delimiter.charAt(0);
        log.info("批量数据处理开始:{}",fileData.getFileName());
        try(Reader reader = new InputStreamReader(new FileInputStream(csvFile),
                FileEncodingUtil.resolveFileEncoding(fileData));
            CSVParser parser = CSVParser.parse(reader,
                    CSVFormat.DEFAULT.withIgnoreEmptyLines(true)
                            .withDelimiter(delimiterChar)
                            .withTrim(false))) {
            Iterator<CSVRecord> iterator = parser.iterator();
            boolean skip= StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirst=true;
            // 是否有数据标识
            boolean hasData = false;
            while(iterator.hasNext()){
                CSVRecord csvRecord = iterator.next();
                if(isFirst && skip){
                    isFirst=false;
                    continue;
                }
                // 将CSV记录转换为字段数组
                String[] fields = convertRecordToFields(csvRecord);
                T data = SubscribeRegister.createDtoInstance(dataListener.getDataClass());
                if (data != null) {
                    hasData = true;
                    data.mapFromFields(fields);
                    dataList.add(data);
                }
                if (dataList.size() >= batchSize) {
                    batchNo++;
                    fileData.setBatchNo(batchNo);
                    batchDataProcess(dataList, dataListener, FileMetadata.copyOf(fileData));
                    dataList.clear();
                }
            }
            // 当dataList为空，但文件是空依然触发调用
            if(CollectionUtils.isNotEmpty(dataList) || (!hasData && ConfHolder.getInstance().notifyIfEmpty())){
                batchNo++;
                fileData.setBatchNo(batchNo);
                dataListener.onBatchData(dataList, FileMetadata.copyOf(fileData));
            }
        } catch (Throwable e){//NOSONAR
            log.error("内部异常",e);
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "csv文件批量处理发生异常", System.currentTimeMillis() - startTime, StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E","csv文件批量处理异常");
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "csv文件批量处理异常",e);
        }
        long endTime = System.currentTimeMillis();
        log.info("批量数据处理结束:{},耗时:{}ms",fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "csv文件处理完成", System.currentTimeMillis() - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S","csv文件处理完成");
    }

    @Override
    public void process(FileMetadata fileData, DhBatchMapDataListener dataListener, File csvFile,
                        String skipHeader, String delimiter, String fromAppCode,long startTime) {
        int batchSize = dataListener.getBatch();
        List<Map<Integer,Object>> dataList = new ArrayList<>(batchSize);
        int batchNo = 0;
        char delimiterChar = delimiter.charAt(0);
        log.info("批量数据处理开始:{}",fileData.getFileName());

        try(Reader reader = new InputStreamReader(new FileInputStream(csvFile),
                FileEncodingUtil.resolveFileEncoding(fileData));
            CSVParser parser = CSVParser.parse(reader,
                    CSVFormat.DEFAULT.withIgnoreEmptyLines(true)
                            .withDelimiter(delimiterChar)
                            .withTrim(false))) {
            boolean skip= StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirst=true;
            boolean hasData = false;
            Iterator<CSVRecord> iterator = parser.iterator();
            while(iterator.hasNext()){
                CSVRecord csvRecord = iterator.next();
                if(isFirst && skip){
                    isFirst=false;
                    continue;
                }
                // 迭代器 hasNext == true 即认为有数据
                hasData = true;
                // 将CSV记录转换为字段数组
                String[] fields = convertRecordToFields(csvRecord);
                Map<Integer, Object> data = new HashMap<>(fields.length);
                for(int i = 0; i < fields.length; i++){
                    data.put(i, fields[i]);
                }

                dataList.add(data);
                if (dataList.size() >= batchSize) {
                    batchNo++;
                    fileData.setBatchNo(batchNo);
                    batchDataProcess(dataList, dataListener, FileMetadata.copyOf(fileData));
                    dataList.clear();
                }
            }
            // 当dataList为空，但文件是空依然触发调用
            if(CollectionUtils.isNotEmpty(dataList) || (!hasData && ConfHolder.getInstance().notifyIfEmpty())){
                batchNo++;
                fileData.setBatchNo(batchNo);
                dataListener.onBatchData(dataList, FileMetadata.copyOf(fileData));
            }        
        } catch (Throwable e){//NOSONAR
            log.error("内部异常",e);
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "csv文件批量处理发生异常", System.currentTimeMillis() - startTime, StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E","csv文件批量处理异常");
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "csv文件批量处理异常",e);
        }
        long endTime = System.currentTimeMillis();
        log.info("批量数据处理结束:{},耗时:{}ms",fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "csv文件处理完成", System.currentTimeMillis() - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S","csv文件处理完成");
    }

}
