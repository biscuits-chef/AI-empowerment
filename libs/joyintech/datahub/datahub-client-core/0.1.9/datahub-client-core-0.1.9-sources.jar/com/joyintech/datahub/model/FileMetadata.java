package com.joyintech.datahub.model;

/**
 * @author ChenHao
 * @date 11/7/25 14:10
 */
public class FileMetadata {
    /**
     * 数据编码
     */
    private String dataCode;
    /**
     * 数据版本
     */
    private String version;
    /**
     * 文件大小
     */
    private Long fileSize;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 来源APP
     */
    private String fromAppCode;
    /**
     * 参考总行数
     */
    private Long lineCount;
    /**
     * 行编码
     */
    private int rowNumber;
    /**
     * 批次号
     */
    private int batchNo;
    /**
     * 链路ID
     */
    private String traceId;
    /**
     * 数据日期
     */
    private String dataDate;
    /**
     * 文件编码
     */
    private String fileEncoding;

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFromAppCode() {
        return fromAppCode;
    }

    public void setFromAppCode(String fromAppCode) {
        this.fromAppCode = fromAppCode;
    }

    public Long getLineCount() {
        return lineCount;
    }

    public void setLineCount(Long lineCount) {
        this.lineCount = lineCount;
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public int getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(int batchNo) {
        this.batchNo = batchNo;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getFileEncoding() {
        return fileEncoding;
    }

    public void setFileEncoding(String fileEncoding) {
        this.fileEncoding = fileEncoding;
    }

    @Override
    public String toString() {
        return "FileMetadata{" +
                "dataCode='" + dataCode + '\'' +
                ", version='" + version + '\'' +
                ", fileSize='" + fileSize + '\'' +
                ", fileName='" + fileName + '\'' +
                ", fromAppCode='"+ fromAppCode + '\'' +
                ", countLine="+ lineCount +
                ", rowNumber="+ rowNumber +
                ", batchNo="+ batchNo +
                ", traceId='"+ traceId + '\''+
                ", dataDate='"+ dataDate + '\''+
                ", fileEncoding='"+ fileEncoding + '\''+
                '}';
    }

    public static FileMetadata copyOf(FileMetadata original) {
        FileMetadata copy= new FileMetadata();
            copy.setDataCode(original.getDataCode());
            copy.setVersion(original.getVersion());
            copy.setFileSize(original.getFileSize());
            copy.setFileName(original.getFileName());
            copy.setFromAppCode(original.getFromAppCode());
            copy.setLineCount(original.getLineCount());
            copy.setRowNumber(original.getRowNumber());
            copy.setBatchNo(original.getBatchNo());
            copy.setTraceId(original.getTraceId());
            copy.setDataDate(original.getDataDate());
            copy.setFileEncoding(original.getFileEncoding());
        return copy;
    }
}
