package com.joyintech.datahub.model;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: InstMsgDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/20 20:58 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class InstMsgDTO<T> extends SendBaseDTO {
    
    private T value;
    
    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    @Override
    public void validate() {
        super.validate();
        if (value == null) {
            throw new IllegalArgumentException("发送对象value不能为空");
        }
    }
}
