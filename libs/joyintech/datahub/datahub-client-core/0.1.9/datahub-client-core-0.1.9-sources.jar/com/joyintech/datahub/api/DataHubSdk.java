package com.joyintech.datahub.api;


import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.conf.ConfigManager;
import com.joyintech.datahub.conf.ConsumerManager;
import com.joyintech.datahub.conf.DataHubInitializer;
import com.joyintech.datahub.consumer.DhConsumerThreadProcess;
import com.joyintech.datahub.delayed.GlobalFileDeleter;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.log.handler.DhcLogHandler;
import com.joyintech.datahub.model.URL;
import com.joyintech.datahub.purview.ConsumerPurview;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.refresh.ConfRefreshListener;
import com.joyintech.datahub.refresh.heart.VertxTransporter;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.JarVersionUtil;
import com.joyintech.datahub.util.KafkaProducerHolder;
import com.joyintech.datahub.util.ObsClientHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SDK 主入口\ datahub-spring....调用
 *
 * @author ChenHao
 * @date 11/4/25 17:11
 */
public class DataHubSdk {

    private static final Logger log = LoggerFactory.getLogger(DataHubSdk.class);

    private ConfigManager configManager;
    private final DataHubInitializer dataHubInitializer;

    /**
     *
     * @param dataHubInitializer obs 拉取配置地址
     */
    public DataHubSdk(DataHubInitializer dataHubInitializer) {
        this.dataHubInitializer = dataHubInitializer;
        JarVersionUtil.collectVersion(DataHubSdk.class);
    }

    public void start() {
        log.info("Starting DataHub SDK...");

        //仅用户打印配置信息 方便核对
        readConfigurationItems();

        try {
            // 拉取配置信息
            dataHubInitializer.initialize();
            GlobalFileDeleter.init();
            // 初始化
            this.configManager = ConfigManager.getInstance(ConfHolder.getInstance().getConfDto());

            // 先初始化消费处理线程池，避免 consumer 先启动导致附件/文件处理线程池未就绪
            DhConsumerThreadProcess.getInstance(5, 5, 60L, 10);

            // 初始化 Kafka 
            configManager.start();
        } catch (Exception e) {
            log.error("DataHub SDK initialization failed deliver.");
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "SKD initialization failed. Please check the delivered configuration content.", e);
        }

        // 监听器初始化
        String objectKey = ConfHolder.getInstance().getObsConfContent().getObjectKey();
        ConfRefreshListener.getInstance(objectKey);
    }

    /**
     * 仅用户打印配置信息
     */
    private void readConfigurationItems() {
        URL confUrl = ConfHolder.getInstance().getConfUrl();
        int connectTimeout = ConfHolder.getInstance().getConnectTimeout();
        int readIdleTimeout = ConfHolder.getInstance().getReadIdleTimeout();
        String appCode = ConfHolder.getInstance().getAppCode();
        String serverName = ConfHolder.getInstance().getServerName();
        String tempDirectory = ConfHolder.getInstance().getTempDirectory();
        String healthUrl = ConfHolder.getInstance().getHealthUrl();
        long initialDelay = ConfHolder.getInstance().getInitialDelay();
        long period = ConfHolder.getInstance().getPeriod();
        Integer stackTraceLimit = ConfHolder.getInstance().getStackTraceLimit();
        ConfHolder.ObsUploadConf obsUploadConf = ConfHolder.getInstance().getObsUploadConf();
        log.info("Configuration items: confUrl={}, connectTimeout={}, readIdleTimeout={}, appCode={}, serverName={}, " +
                        "tempDirectory={}, healthUrl={}, initialDelay={}, period={}, stackTraceLimit={}, obsUploadConf={}",
                confUrl, connectTimeout, readIdleTimeout, appCode, serverName,
                tempDirectory, healthUrl, initialDelay, period, stackTraceLimit, obsUploadConf);
    }

    public void shutdown() {
        log.info("Shutting down DataHub SDK...");
        ConfRefreshListener.shutdown();
        log.info("Shut down ConfRefreshListener.");
        ConsumerManager.getInstance().closeAllConsumerThreads();
        log.info("Closed all consumer threads.");
        DhConsumerThreadProcess.shutdown();
        log.info("Shut down DhConsumerThreadProcess.");
        DhcLogHandler.shutdown();
        log.info("Shut down DhcLogHandler.");
        KafkaProducerHolder.shutdown();
        log.info("Shut down KafkaProducerHolder.");
        GlobalFileDeleter.shutdown();
        log.info("Shut down GlobalFileDeleter.");
        ConsumerPurview.shutdown();
        log.info("Shut down ConsumerPurview.");
        VertxTransporter.shutdown();
        log.info("Shut down VertxTransporter.");
        ConfHolder.shutdown();
        log.info("Shut down ConfHolder.");
        SendPurview.shutdown();
        log.info("Shut down SendPurview.");
        DhcLog.shutdown();
        log.info("Shut down DhcLog.");
        ObsClientHolder.shutdown();
        log.info("Shut down ObsClientHolder.");
        configManager.shutdown();
        log.info("Shut down ConfigManager.");
        log.info("DataHub SDK shut down successfully.");
    }
}
