package com.joyintech.datahub.exception;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: NoAccessException.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/10 19:38 <br/>
 * Description: 无权限异常  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class NoAccessException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = -1L;
    public NoAccessException(String message) {
        super(message);
    }
}
