package com.joyintech.datahub.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

/**
 * @author ChenHao
 * @date 1/13/26 17:19
 */
public class ObsHttpDownload {

    private ObsHttpDownload() {
    }

    private static final Logger log = LoggerFactory.getLogger(ObsHttpDownload.class);

    /**
     * 下载文件到本地
     *
     * @param fileUrl  文件下载 URL
     * @param savePath 文件保存完整路径
     * @return 下载后的 File 对象
     * @throws Exception 下载失败会抛出异常
     */
    public static File downloadFile(String fileUrl, String savePath) throws Exception {
        return downloadFile(fileUrl, savePath, false);
    }

    /**
     * 下载文件到本地（带重试）
     *
     * @param fileUrl      文件下载 URL
     * @param savePath     文件保存完整路径
     * @param maxAttempts  最大重试次数（包含首次尝试），建议 1~3
     * @return 下载后的 File 对象
     * @throws Exception 下载失败会抛出异常
     */
    public static File downloadFile(String fileUrl, String savePath, int maxAttempts) throws Exception {
        return downloadFile(fileUrl, savePath, false, maxAttempts);
    }

    /**
     * 下载文件到本地（断点续传）
     *
     * @param fileUrl  文件下载 URL
     * @param savePath 文件保存完整路径
     * @param resume   是否断点续传；true 时会基于已有文件长度发送 Range 头
     * @return 下载后的 File 对象
     * @throws Exception 下载失败会抛出异常
     */
    public static File downloadFile(String fileUrl, String savePath, boolean resume) throws Exception {
        return downloadFileOnce(fileUrl, savePath, resume);
    }

    /**
     * 下载文件到本地（断点续传 + 重试）
     *
     * @param fileUrl     文件下载 URL
     * @param savePath    文件保存完整路径
     * @param resume      是否断点续传
     * @param maxAttempts 最大重试次数（包含首次尝试），建议 1~3
     * @return 下载后的 File 对象
     * @throws Exception 下载失败会抛出异常
     */
    public static File downloadFile(String fileUrl, String savePath, boolean resume, int maxAttempts) throws Exception {
        if (maxAttempts <= 0) {
            throw new IllegalArgumentException("maxAttempts must be >= 1");
        }

        Exception lastException = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return downloadFileOnce(fileUrl, savePath, resume);
            } catch (Exception e) {
                lastException = e;
                if (!isRetryable(e) || attempt == maxAttempts) {
                    break;
                }
                long backoffMs = Math.min(1000L, 200L * attempt);
                log.warn("下载失败，准备重试: attempt={}/{}, backoffMs={}, savePath={}, err={}",
                        attempt, maxAttempts, backoffMs, savePath, e.toString());
                try {
                    Thread.sleep(backoffMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        throw lastException;
    }

    private static File downloadFileOnce(String fileUrl, String savePath, boolean resume) throws Exception {
        URL url = new URL(fileUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // === 只对当前连接跳过 HTTPS 证书校验 ===
        if (conn instanceof HttpsURLConnection) {
            HttpsURLConnection httpsConn = (HttpsURLConnection) conn;

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            }, new SecureRandom());

            httpsConn.setSSLSocketFactory(sslContext.getSocketFactory());
            httpsConn.setHostnameVerifier((hostname, session) -> true);
        }

        // 5 秒
        conn.setConnectTimeout(5_000);
        // 3 分钟
        conn.setReadTimeout(180_000);
        conn.setRequestMethod("GET");

        File file = new File(savePath);
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists() && !parentDir.mkdirs()) {
            throw new IOException("无法创建目录: " + parentDir.getAbsolutePath());
        }

        long existingLen = 0L;
        if (resume && file.exists()) {
            existingLen = file.length();
            if (existingLen > 0) {
                conn.setRequestProperty("Range", "bytes=" + existingLen + "-");
            }
        }

        int responseCode = conn.getResponseCode();
        if (resume && responseCode == 416) {
            log.info("文件已完整，无需续传: {}", file.getAbsolutePath());
            return file;
        }
        if (responseCode != HttpURLConnection.HTTP_OK && responseCode != HttpURLConnection.HTTP_PARTIAL) {
            throw new IOException("下载失败，HTTP 响应码: " + responseCode + ", URL: " + fileUrl);
        }

        boolean append = resume && existingLen > 0 && responseCode == HttpURLConnection.HTTP_PARTIAL;
        if (!append && file.exists() && !file.delete()) {
            log.warn("覆盖下载前删除旧文件失败: {}", file.getAbsolutePath());
        }

        try (InputStream inputStream = conn.getInputStream();
             FileOutputStream outputStream = new FileOutputStream(file, append)) {

            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (Exception e) {
            // 非断点续传场景，下载失败删除不完整文件；断点续传场景保留文件用于后续续传
            if (!resume && file.exists() && !file.delete()) {
                log.warn("删除下载失败的不完整文件失败: {}", file.getAbsolutePath());
            }
            throw new IOException("下载失败，fileUrl=" + fileUrl + ", savePath=" + savePath, e);
        } finally {
            conn.disconnect();
        }

        log.info("下载完成: {}", file.getAbsolutePath());
        return file;
    }

    private static boolean isRetryable(Exception e) {
        Integer httpCode = tryParseHttpCode(e);
        if (httpCode == null) {
            return true;
        }
        if (httpCode >= 500) {
            return true;
        }
        return httpCode == 408 || httpCode == 429;
    }

    private static Integer tryParseHttpCode(Exception e) {
        String msg = e.getMessage();
        if (msg == null) {
            return null;
        }
        int idx = msg.indexOf("HTTP 响应码:");
        if (idx < 0) {
            return null;
        }
        int start = idx + "HTTP 响应码:".length();
        int end = msg.indexOf(',', start);
        String codeStr = (end >= 0 ? msg.substring(start, end) : msg.substring(start)).trim();
        try {
            return Integer.parseInt(codeStr);
        } catch (NumberFormatException ignore) {
            return null;
        }
    }
    
}
