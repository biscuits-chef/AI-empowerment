package com.joyintech.datahub.model;

/**
 * obs-r 配置地址
 * 用户拉取初始化内容：obs、kafka 等配置信息
 * 
 * @author ChenHao
 * @date 11/6/25 19:33
 */
public class ObsConfContent {
    
    private String bucketName;
    
    private String objectKey;
    
    private String accessKey;
    
    private String secretKey;
    
    private String endpoint;
    
    public ObsConfContent(String bucketName) {
        this.bucketName = bucketName;
    }

    public ObsConfContent(String bucketName, String objectKey, String accessKey, String secretKey, String endpoint) {
        this.bucketName = bucketName;
        this.objectKey = objectKey;
        this.accessKey = accessKey;
        this.secretKey = secretKey;
        this.endpoint = endpoint;
    }

    public String getBucketName() {
        return bucketName;
    }

    @Override
    public String toString() {
        return "ObsConfContent{" +
                "bucketName='" + bucketName + '\'' +
                ", objectKey='" + objectKey + '\'' +
                ", accessKey='******'" +
                ", secretKey='******'" +
                ", endpoint='" + endpoint + '\'' +
                '}';
    }
    
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }
}
