package com.joyintech.datahub.conf;

import com.joyintech.datahub.kafka.ConsumerWrapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @author ChenHao
 * @date 11/21/25 09:46
 */
public class ConsumerManager {

    private ConsumerManager() {
        consumersThreadMap = new ConcurrentHashMap<>();
        consumerThreadLock = new ReentrantReadWriteLock();
    }
    
    private static volatile ConsumerManager consumerManager;
    
    public static ConsumerManager getInstance() {
        if (consumerManager == null) {
            synchronized (ConsumerManager.class) {
                if (consumerManager == null) {
                    consumerManager = new ConsumerManager();
                }
            }
        }
        return consumerManager;
    }


    /**
     * 消费线程
     * <p>
     * key: topic
     * value: ConsumerWrapper
     */
    private final Map<String, ConsumerWrapper> consumersThreadMap;
    
    private final ReadWriteLock consumerThreadLock;

    // ==================== consumersThreadMap 操作 ====================

    public Set<String> getConsumerThreadKeys() {
        consumerThreadLock.readLock().lock();
        try {
            return new HashSet<>(consumersThreadMap.keySet());
        } finally {
            consumerThreadLock.readLock().unlock();
        }
    }

    public ConsumerWrapper removeConsumerThread(String key) {
        consumerThreadLock.writeLock().lock();
        try {
            return consumersThreadMap.remove(key);
        } finally {
            consumerThreadLock.writeLock().unlock();
        }
    }

    public void putConsumerThread(String key, ConsumerWrapper consumerWrapper) {
        consumerThreadLock.writeLock().lock();
        try {
            consumersThreadMap.put(key, consumerWrapper);
        } finally {
            consumerThreadLock.writeLock().unlock();
        }
    }

    public boolean containsConsumerThread(String key) {
        consumerThreadLock.readLock().lock();
        try {
            return consumersThreadMap.containsKey(key);
        } finally {
            consumerThreadLock.readLock().unlock();
        }
    }

    public void closeAllConsumerThreads() {
        List<ConsumerWrapper> toClose;
        consumerThreadLock.writeLock().lock();
        try {
            toClose = new ArrayList<>(consumersThreadMap.values());
            consumersThreadMap.clear();
        } finally {
            consumerThreadLock.writeLock().unlock();
        }
        toClose.forEach(wrapper -> {
            try {
                wrapper.close();
            } catch (Exception e) {
                // best-effort close
            }
        });
    }

    public ConsumerWrapper getConsumerThread(String key) {
        consumerThreadLock.readLock().lock();
        try {
            return consumersThreadMap.get(key);
        } finally {
            consumerThreadLock.readLock().unlock();
        }
    }

    public boolean stopConsumerThread(String key) {
        ConsumerWrapper consumerWrapper;
        consumerThreadLock.writeLock().lock();
        try {
            consumerWrapper = consumersThreadMap.remove(key);
        } finally {
            consumerThreadLock.writeLock().unlock();
        }
        if (consumerWrapper != null) {
            consumerWrapper.close();
            return true;
        }
        return false;
    }



}
