package com.joyintech.datahub.subscribe;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhInstantMsgListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 17:51 <br/>
 * Description: 即时消息订阅接口  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhInstantMsgListener<T> extends DhGenericTypeListener<T> {
    /**
     * 业务具体处理消息
     */
    void onInstantMsg(T msg) throws RuntimeException;
}
