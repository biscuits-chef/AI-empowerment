package com.joyintech.datahub.consumer;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.log.DhcLog;
import com.joyintech.datahub.model.FileMetadata;
import com.joyintech.datahub.subscribe.*;
import com.joyintech.datahub.util.CSVParseUtil;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.FileEncodingUtil;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: OtherFileProcess.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/13 9:33 <br/>
 * Description: 非csv文件处理  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class OtherFileProcess extends FileProcess {

    private static final Logger log = LoggerFactory.getLogger(OtherFileProcess.class);
    private static final int STREAM_BUFFER_SIZE = 8 * 1024;

    private String[] convertToFields(String lineStr, String delimiter) throws IOException {

        String line = CSVParseUtil.toStandardCSV(lineStr,delimiter);

        CSVParser parser = CSVParser.parse(line,
                CSVFormat.DEFAULT.withIgnoreEmptyLines(true)
                        .withDelimiter(',')
                        .withTrim(false));
        Iterator<CSVRecord> iterator = parser.iterator();
        String[] fields = null;
        //此处只有单一数据
        while(iterator.hasNext()) {
            CSVRecord csvRecord = iterator.next();
            // 将CSV记录转换为字段数组
            fields = convertRecordToFields(csvRecord);
        }
        return fields;
    }

    @Override
    public <T extends DhBaseDTO> void process(FileMetadata fileData, DhSubscribeDataListener<T> dataListener,
                                              File file, String skipHeader,
                                              String delimiter, String fromAppCode,long startTime) {
        log.info("单条数据处理开始:{}", fileData.getFileName());
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(Files.newInputStream(file.toPath()),
                FileEncodingUtil.resolveFileEncoding(fileData)),STREAM_BUFFER_SIZE)) {
            String line;
            int rowNumber = 1;
            boolean skip = StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirstLine = true;
            // 是否有数据标识
            boolean hasData = false;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine && skip) {
                    isFirstLine = false;
                    continue;
                }
                T data = SubscribeRegister.createDtoInstance(dataListener.getDataClass());
                if (data != null) {
                    hasData = true;
                    String[] fields = convertToFields(line, delimiter);
                    if (fields != null) {
                        data.mapFromFields(fields);
                        fileData.setRowNumber(rowNumber);
                        dataProcess(dataListener, data, FileMetadata.copyOf(fileData));
                    } else {
                        log.warn("数据格式不准确！");
                    }
                }
                rowNumber++;
            }
            if (!hasData && ConfHolder.getInstance().notifyIfEmpty()) {
                fileData.setRowNumber(0);
                // 文件为空 或 只有表头
                dataProcess(dataListener, null, FileMetadata.copyOf(fileData));
            }
        } catch (Throwable e) {//NOSONAR
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "普通文件单条处理异常，文件名：" + fileData.getFileName(),
                    System.currentTimeMillis() - startTime,
                    StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E", "普通文件单条处理异常" + e.getMessage());
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "普通文件单条处理异常", e);
        }
        long endTime = System.currentTimeMillis();
        log.info("单条数据处理结束:{},耗时:{}ms", fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "普通文件处理完成，文件名：" + fileData.getFileName(),
                endTime - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S", "普通文件单条处理正常完成");
    }


    @Override
    public <T extends DhBaseDTO> void process(FileMetadata fileData, DhSubscribeBatchDataListener<T> dataListener,
                                              File file,String skipHeader,
                                              String delimiter, String fromAppCode,long startTime) {
        int batchSize = dataListener.getBatch();
        List<T> dataList = new ArrayList<>(batchSize);
        int batchNo = 0;
        log.info("批量数据处理开始:{}", fileData.getFileName());
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(Files.newInputStream(file.toPath()),
                FileEncodingUtil.resolveFileEncoding(fileData)),
                STREAM_BUFFER_SIZE)) {
            String line;
            boolean skip = StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirstLine = true;
            // 是否有数据标识
            boolean hasData = false;
            while ((line = reader.readLine()) != null) {
                if (skip && isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                T data = SubscribeRegister.createDtoInstance(dataListener.getDataClass());
                if (data != null) {
                    hasData = true;
                    String[] fields = convertToFields(line, delimiter);
                    if (fields != null) {
                        data.mapFromFields(fields);
                        dataList.add(data);
                    } else {
                        log.warn("数据格式不准确！");
                    }
                }
                if (dataList.size() >= batchSize) {
                    batchNo++;
                    fileData.setBatchNo(batchNo);
                    batchDataProcess(dataList, dataListener, FileMetadata.copyOf(fileData));
                    dataList.clear();
                }
            }
            // 当dataList为空，但文件是空依然触发调用
            if (CollectionUtils.isNotEmpty(dataList) || (!hasData && ConfHolder.getInstance().notifyIfEmpty())) {
                batchNo++;
                fileData.setBatchNo(batchNo);
                batchDataProcess(dataList, dataListener, FileMetadata.copyOf(fileData));
            }
        } catch (Throwable e) {//NOSONAR
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "普通文件批量处理异常，文件名：" + fileData.getFileName(),
                    System.currentTimeMillis() - startTime,
                    StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E", "文件批量处理异常" + e.getMessage());
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "文件批量处理异常", e);
        }
        long endTime = System.currentTimeMillis();
        log.info("批量数据处理结束:{},耗时:{}ms", fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "普通文件批量处理完成，文件名：" + fileData.getFileName(),
                endTime - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S", "普通文件批量接收处理正常");
    }

    @Override
    public void process(FileMetadata fileData, DhBatchMapDataListener mapDataListener, File file,
                        String skipHeader, String delimiter, String fromAppCode,long startTime) {
        int batchSize = mapDataListener.getBatch();
        List<Map<Integer,Object>> dataList = new ArrayList<>(batchSize);
        int batchNo = 0;
        log.info("批量数据处理开始:{}",fileData.getFileName());
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(Files.newInputStream(file.toPath()),
                FileEncodingUtil.resolveFileEncoding(fileData)),
                STREAM_BUFFER_SIZE)) {
            String line;
            boolean skip = StringUtils.equals(DataHubConstant.Y_OR_N_N,skipHeader);
            boolean isFirstLine = true;
            // 是否有数据标识
            boolean hasData = false;
            while ((line = reader.readLine()) != null) {
                if (skip && isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                hasData = true;
                String[] fields = convertToFields(line, delimiter);
                if(fields == null){
                    throw new DataHubException(DataHubErrorEnum.PARAM_ERROR,"转化数据为空");
                }
                Map<Integer, Object> data = new HashMap<>(fields.length);
                for(int i = 0; i < fields.length; i++){
                    data.put(i, fields[i]);
                }
                dataList.add(data);
                if (dataList.size() >= batchSize) {
                    batchNo++;
                    fileData.setBatchNo(batchNo);
                    batchDataProcess(dataList, mapDataListener, FileMetadata.copyOf(fileData));
                    dataList.clear();
                }
            }
            // 当dataList为空，但文件是空依然触发调用
            if(CollectionUtils.isNotEmpty(dataList) || (!hasData && ConfHolder.getInstance().notifyIfEmpty())){
                batchNo++;
                fileData.setBatchNo(batchNo);
                batchDataProcess(dataList, mapDataListener, FileMetadata.copyOf(fileData));
            }
        } catch (Throwable e) {//NOSONAR
            DhcLog.getInstance().error(fileData.getTraceId(),
                    LogType.FILE_PROCESSING,
                    fileData.getDataDate(),
                    fromAppCode,
                    fileData.getDataCode(),
                    fileData.getVersion(),
                    "普通文件批量处理异常，文件名：" + fileData.getFileName(),
                    System.currentTimeMillis() - startTime,
                    StackTraceFormatUtil.getStackTrace(e));
            FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                    "E","普通文件批量处理异常" + e.getMessage());
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "普通文件批量处理异常",e);
        }
        long endTime = System.currentTimeMillis();
        log.info("批量数据处理结束:{},耗时:{}ms",fileData.getFileName(), endTime - startTime);
        DhcLog.getInstance().info(fileData.getTraceId(),
                LogType.FILE_PROCESSING,
                fileData.getDataDate(),
                fromAppCode,
                fileData.getDataCode(),
                fileData.getVersion(),
                "普通文件批量处理完成，文件名：" + fileData.getFileName(),
                endTime - startTime);
        FileConsumerHandler.postFileRecord(fileData.getTraceId(),
                "S","普通文件批量接收处理正常");
    }
}
