package com.joyintech.datahub.model;

import java.io.Serializable;

/**
 * @author ChenHao
 * @date 11/12/25 11:34
 */
public class DhClientHeartbeat implements Serializable {
    /**
     * 本机地址 -> IP
     */
    private String serverAddress;
    /**
     * 当前 
     */
    private String appCode;
    /**
     * 当前时间
     */
    private String heartbeatTime;
    /**
     * 版本信息
     */
    private String sdkVersion;
    /**
     * 与app-code共同组成kafka groupId
     */
    private String serverName;

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getHeartbeatTime() {
        return heartbeatTime;
    }

    public void setHeartbeatTime(String heartbeatTime) {
        this.heartbeatTime = heartbeatTime;
    }

    public String getSdkVersion() {
        return sdkVersion;
    }

    public void setSdkVersion(String sdkVersion) {
        this.sdkVersion = sdkVersion;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public DhClientHeartbeat(String serverAddress, String appCode, String heartbeatTime, String sdkVersion) {
        this.serverAddress = serverAddress;
        this.appCode = appCode;
        this.heartbeatTime = heartbeatTime;
        this.sdkVersion = sdkVersion;
    }

    public DhClientHeartbeat() {
    }

    @Override
    public String toString() {
        return "DhClientHeartbeat{" +
                "serverAddress='" + serverAddress + '\'' +
                ", appCode='" + appCode + '\'' +
                ", heartbeatTime='" + heartbeatTime + '\'' +
                ", sdkVersion='" + sdkVersion + '\'' +
                ", serverName='" + serverName + '\'' +
                '}';
    }

    public static class Builder {
        private String serverAddress;
        private String appCode;
        private String heartbeatTime;
        private String sdkVersion;
        private String serverName;

        public Builder setServerAddress(String serverAddress) {
            this.serverAddress = serverAddress;
            return this;
        }

        public Builder setAppCode(String appCode) {
            this.appCode = appCode;
            return this;
        }

        public Builder setHeartbeatTime(String heartbeatTime) {
            this.heartbeatTime = heartbeatTime;
            return this;
        }

        public Builder setSdkVersion(String sdkVersion) {
            this.sdkVersion = sdkVersion;
            return this;
        }
        
        public Builder setServerName(String serverName) {
            this.serverName = serverName;
            return this;
        }

        public DhClientHeartbeat build() {
            DhClientHeartbeat heartbeat = new DhClientHeartbeat();
            heartbeat.setServerAddress(serverAddress);
            heartbeat.setAppCode(appCode);
            heartbeat.setHeartbeatTime(heartbeatTime);
            heartbeat.setSdkVersion(sdkVersion);
            heartbeat.setServerName(serverName);
            return heartbeat;
        }
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
}
