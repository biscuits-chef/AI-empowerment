package com.joyintech.datahub.util;

import com.joyintech.datahub.model.FileGenStats;
import com.joyintech.datahub.model.FileSendNotify;
import com.joyintech.datahub.model.MsgHeader;
import com.joyintech.datahub.sender.FileSendNotifyHelper;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.PutObjectResult;
import com.joyintech.datahub.common.constant.DataHubConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileSenderComplete.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 14:34 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class FileSenderComplete {

    private static final Logger log = LoggerFactory.getLogger(FileSenderComplete.class);

    /**
     * 功能描述: 构建文件发送结果信息
     */
    public static void sendFileSendCompleteMsg(String dataDate, String dataCode, String version, String uuid,
                                               PutObjectResult result,
                                               FileGenStats fgs, String skipLineOneFlag) {
        sendFileSendCompleteMsg(dataDate, dataCode, version, uuid, fgs, result.getEtag(), result.getObjectKey(),
                result.getBucketName(), skipLineOneFlag);
    }

    /**
     * 功能描述: 构建文件发送结果信息
     */
    public static void sendFileSendCompleteMsg(String dataDate, String dataCode, String version, String uuid,
                                               CompleteMultipartUploadResult result,
                                               FileGenStats fgs, String skipLineOneFlag) {
        sendFileSendCompleteMsg(dataDate, dataCode, version, uuid, fgs, result.getEtag(), result.getObjectKey(),
                result.getBucketName(), skipLineOneFlag);
    }

    /**
     * 功能描述: 构建文件发送结果信息
     */
    public static void sendFileSendCompleteMsg(String dataDate, String dataCode, String version, String uuid, FileGenStats fgs,
                                               String eTage, String objectKey, String bucketName, String skipLineOneFlag
    ) {
        sendFileSendCompleteMsg(dataDate, dataCode, version, uuid, fgs, eTage, objectKey, bucketName,
                skipLineOneFlag, DataHubConstant.DEFAULT_FILE_ENCODING);
    }

    /**
     * 功能描述: 构建文件发送结果信息
     */
    public static void sendFileSendCompleteMsg(String dataDate, String dataCode, String version, String uuid, FileGenStats fgs,
                                               String eTage, String objectKey, String bucketName, String skipLineOneFlag,
                                               String fileEncoding
    ) {
        FileSendNotify fileSendNotify = new FileSendNotify();
        fileSendNotify.setDataDate(dataDate);
        fileSendNotify.setDataCode(dataCode);
        fileSendNotify.setDataVersion(version);
        fileSendNotify.setFormAppCode(ConfHolder.getInstance().getAppCode());
        fileSendNotify.setFileMD5Value(MD5Util.cleanObsEtag(eTage));
        fileSendNotify.setObjectKey(objectKey);
        fileSendNotify.setFileSize(fgs.getTotalSize());
        fileSendNotify.setLineCount(fgs.getLineCount());
        fileSendNotify.setTraceId(uuid);
        fileSendNotify.setBucket(bucketName);
        fileSendNotify.setSourceFileName(FileUtil.extractFilenameOnly(objectKey));
        fileSendNotify.setFileEncoding(FileEncodingUtil.resolve(fileEncoding).name());
        MsgHeader msgHeader = new MsgHeader();
        msgHeader.setSkipLineOneFlag(skipLineOneFlag);
        FileSendNotifyHelper.getInstance().notify(fileSendNotify, msgHeader);
        log.info("文件：{}上传成功，声明文件编码：{}，发送文件通知完成",
                fileSendNotify.getObjectKey(), fileSendNotify.getFileEncoding());
    }

    /**
     * 解析json数据为FileSendNotify
     */
    public static FileSendNotify parseJson(String jsonStr) {
        return JsonUtil.fromJson(jsonStr, FileSendNotify.class);
    }
}
