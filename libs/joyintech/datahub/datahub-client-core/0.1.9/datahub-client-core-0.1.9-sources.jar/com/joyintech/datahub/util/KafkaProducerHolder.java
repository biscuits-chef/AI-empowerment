package com.joyintech.datahub.util;

import com.joyintech.datahub.model.ConfDto;
import org.apache.kafka.clients.producer.KafkaProducer;

/**
 * KafkaProducer 单例持有器
 * 用于统一管理全局 KafkaProducer 与 topic 映射配置
 *
 * @author ChenHao
 * @date 11/7/25 16:17
 */
public class KafkaProducerHolder {

    /**
     * 单例实例
     */
    private static volatile KafkaProducerHolder instance;

    /**
     * Kafka producer
     */
    private KafkaProducer<String, String> producer;

    /**
     * Kafka bootstrapServers
     */
    private ConfDto.KafkaConfig.KafkaProps kafkaProps;

    /**
     * 私有构造函数，防止外部实例化
     */
    private KafkaProducerHolder() {
    }

    /**
     * 获取单例实例（DCL）
     */
    public static KafkaProducerHolder getInstance() {
        if (instance == null) {
            synchronized (KafkaProducerHolder.class) {
                if (instance == null) {
                    instance = new KafkaProducerHolder();
                }
            }
        }
        return instance;
    }

    /**
     * 初始化 producer，只允许执行一次
     */
    public synchronized void init(KafkaProducer<String, String> producer, ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        if (this.producer == null && producer != null) {
            this.producer = producer;
        }
        if (this.kafkaProps == null && kafkaProps != null) {
            this.kafkaProps = kafkaProps;
        }
    }

    public synchronized void reload(KafkaProducer<String, String> producer, ConfDto.KafkaConfig.KafkaProps kafkaProps) {
        shutdown();
        this.producer = producer;
        this.kafkaProps = kafkaProps;
    }

    /**
     * 获取 Producer
     */
    public KafkaProducer<String, String> getProducer() {
        if (producer == null) {
            throw new IllegalStateException("KafkaProducer not initialized.");
        }
        return producer;
    }

    /**
     * 获取 bootstrapServers
     */
    public String getBootstrapServers() {
        return kafkaProps.getBootstrapServers();
    }

    public ConfDto.KafkaConfig.KafkaProps getKafkaProps() {
        return kafkaProps;
    }

    /**
     * 关闭 producer
     */
    public static synchronized void shutdown() {
        if (instance == null) {
            return;
        }
        if (instance.producer != null) {
            try {
                instance.producer.close();
            } catch (Exception e) {
                throw new RuntimeException("Failed to close KafkaProducer", e);
            } finally {
                instance.producer = null;
                instance.kafkaProps = null;
                instance = null;
            }
        }
    }
}