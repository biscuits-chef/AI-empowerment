package com.joyintech.datahub.subscribe;

import com.joyintech.datahub.model.FileMetadata;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: DhSubscribeDataListener.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/11 17:47 <br/>
 * Description: 单条数据订阅接口 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public interface DhSubscribeDataListener<T extends DhBaseDTO> extends DhGenericTypeListener<T> {
    /**
     * 业务数据对象处理
     */
    void onData(T data, FileMetadata  metadata);

    /**
     * 返回监听器处理的数据类
     * 实现类必须返回具体的泛型类
     */
    Class<T> getDataClass();
}
