package com.joyintech.datahub.log.impl;


import com.joyintech.datahub.common.enums.LogLevel;
import com.joyintech.datahub.common.enums.LogPhase;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.log.DhcLogger;
import com.joyintech.datahub.log.handler.DhcLogHandler;
import com.joyintech.datahub.log.model.LogDTO;
import com.joyintech.datahub.model.DhcLogContext;
import com.joyintech.datahub.util.ConfHolder;
import com.joyintech.datahub.util.NetUtils;
import com.joyintech.datahub.util.StackTraceFormatUtil;
import com.joyintech.datahub.util.TimeUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * WARN：Please do not use this logger to print large amounts of logs! <br/>
 * WARN：Please do not use this logger to print large amounts of logs! <br/>
 * WARN：Please do not use this logger to print large amounts of logs! <br/>
 *
 * @author
 * @since 2022/9/16
 */
public class DhcServerLogger extends AbstractDhcLogger {

    private final String appCode;
    private final DhcLogHandler dhcLogHandler;

    private static volatile DhcLogger INSTANCE;

    /**
     * 主机地址 默认重启获取一次
     */
    private static String host;

    public static DhcLogger getInstance() {
        if (INSTANCE == null) {
            synchronized (DhcLogger.class) {
                if (INSTANCE == null) {
                    host = NetUtils.getLocalHost();
                    INSTANCE = new DhcServerLogger();
                }
            }
        }
        return INSTANCE;
    }


    /**
     * 销毁资源
     */
    public void destroy() {
        if (INSTANCE == null) {
            return;
        }
        INSTANCE = null;
    }

    public DhcServerLogger() {
        this.appCode = ConfHolder.getInstance().getAppCode();
        this.dhcLogHandler = DhcLogHandler.getInstance();
    }

    public DhcServerLogger(String appCode, DhcLogHandler dhcLogHandler) {
        this.appCode = appCode;
        this.dhcLogHandler = dhcLogHandler;
    }

    @Override
    public void info(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args) {
        LogDTO build = buildLogDTO(traceId, logType, dataDate, fromAppCode, dataCode, version, format(msg, null, args), durationMs, LogLevel.INFO.name());
        dhcLogHandler.submitLog(build);
    }

    @Override
    public void warn(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args) {
        LogDTO build = buildLogDTO(traceId, logType, dataDate, fromAppCode, dataCode, version, format(msg, null, args), durationMs, LogLevel.WARN.name());
        dhcLogHandler.submitLog(build);
    }

    @Override
    public void error(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String... args) {
        LogDTO build = buildLogDTO(traceId, logType, dataDate, fromAppCode, dataCode, version, format(msg, null, args), durationMs, LogLevel.ERROR.name());
        dhcLogHandler.submitLog(build);
    }

    private LogDTO buildLogDTO(String traceId, LogType logType, String dataDate, String fromAppCode, String dataCode, String version, String msg, Long durationMs, String level) {
        LogDTO build = LogDTO.builder()
                .traceId(traceId)
                .logType(logType == null ? LogType.FILE_PROCESSING.getCode() : logType.getCode())
                .appCode(this.appCode)
                .logPhase(LogPhase.HANDLER.getCode())
                .dataDate(dataDate)
                .dataCode(dataCode)
                .version(version)
                .time(TimeUtils.now())
                .level(level)
                .message(msg)
                .host(host)
                .durationMs(durationMs)
                .build();

        if (StringUtils.isEmpty(fromAppCode) || StringUtils.equals(this.appCode, fromAppCode)) {
            build.setLogPhase(LogPhase.SENDER.getCode());
        }
        return build;
    }

    private LogDTO toLogDto(DhcLogContext context) {
        String logType = context.getLogType();
        LogDTO build = LogDTO.builder()
                .traceId(context.getTraceId())
                .logType(logType == null ? LogType.FILE_PROCESSING.getCode() : logType)
                .appCode(this.appCode)
                .logPhase(LogPhase.HANDLER.getCode())
                .dataDate(context.getDataDate())
                .dataCode(context.getDataCode())
                .version(context.getVersion())
                .time(TimeUtils.now())
                .headers(context.getHeaders())
                .level(context.getLevel())
                .message(format(context.getMessage(), context.getThrowable(), context.getArgs()))
                .host(host)
                .durationMs(context.getDurationMs())
                .build();

        if (StringUtils.isEmpty(context.getFromAppCode()) ||
                StringUtils.equals(this.appCode, context.getFromAppCode())) {
            build.setLogPhase(LogPhase.SENDER.getCode());
        }
        
        if (LogType.KAFKA_ATTACH.getCode().equalsIgnoreCase(logType) ||
                LogType.KAFKA_REALTIME.getCode().equalsIgnoreCase(logType)) {
            build.setRecordContents(context.getRecordContents());
        }
        return build;
    }

    @Override
    public void info(DhcLogContext context) {
        context.setLevel(LogLevel.INFO.name());
        LogDTO log = toLogDto(context);
        dhcLogHandler.submitLog(log);
    }


    @Override
    public void warn(DhcLogContext context) {
        context.setLevel(LogLevel.WARN.name());
        LogDTO log = toLogDto(context);
        dhcLogHandler.submitLog(log);
    }

    @Override
    public void error(DhcLogContext context) {
        context.setLevel(LogLevel.WARN.name());
        LogDTO log = toLogDto(context);
        dhcLogHandler.submitLog(log);
    }


    /**
     * 拼接消息内容，防止空指针，msg 与 args 自动加 []
     *
     * @param msg  主消息内容，可为 null
     * @param args 附加参数，可选
     * @return 拼接后的字符串，例如 [msg][a=1, b=2]
     */
    private String format(String msg, Throwable exception, String... args) {
        StringBuilder sb = new StringBuilder(128);

        // 主消息部分
        sb.append('[').append(msg == null ? "null" : msg).append(']');

        // 附加参数部分
        if (args != null && args.length > 0) {
            sb.append('[');
            for (int i = 0; i < args.length; i++) {
                if (i > 0) sb.append(", ");
                sb.append(args[i] == null ? "null" : args[i]);
            }
            sb.append(']');
        }

        // 异常栈信息部分
        if (exception != null) {
            sb.append("[Exception: ").append(StackTraceFormatUtil.getStackTrace(exception)).append(']');
        }

        return sb.toString();
    }

}