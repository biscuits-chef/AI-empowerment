package com.joyintech.datahub.model;

import com.joyintech.datahub.util.TimeUtils;

/**
 * @author ChenHao
 * @date 11/11/25 09:08
 */
public class FileSendNotify {
    
    private Long fileSize;
    
    private String sourceFileName;
    
    private String objectKey;
    
    private String fileMD5Value;
    
    private String traceId;
    
    private String bucket;
    
    private String dataCode;
    
    private String formAppCode;

    private String dataVersion;

    private String toAppCode;

    private Long lineCount;

    private String fileEncoding;
    
    private String sendTime = TimeUtils.now();
    //数据日期
    private String dataDate;

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getSourceFileName() {
        return sourceFileName;
    }

    public void setSourceFileName(String sourceFileName) {
        this.sourceFileName = sourceFileName;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public String getFileMD5Value() {
        return fileMD5Value;
    }

    public void setFileMD5Value(String fileMD5Value) {
        this.fileMD5Value = fileMD5Value;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getFormAppCode() {
        return formAppCode;
    }

    public void setFormAppCode(String formAppCode) {
        this.formAppCode = formAppCode;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public String getToAppCode() {
        return toAppCode;
    }

    public void setToAppCode(String toAppCode) {
        this.toAppCode = toAppCode;
    }

    public Long getLineCount() {
        return lineCount;
    }

    public void setLineCount(Long lineCount) {
        this.lineCount = lineCount;
    }

    public String getFileEncoding() {
        return fileEncoding;
    }

    public void setFileEncoding(String fileEncoding) {
        this.fileEncoding = fileEncoding;
    }

    @Override
    public String toString() {
        return "FileSendNotify{" +
                "dataDate='" + dataDate + '\'' +
                "fileSize=" + fileSize +
                ", lineCount=" + lineCount +
                ", sourceFileName='" + sourceFileName + '\'' +
                ", objectKey='" + objectKey + '\'' +
                ", fileMD5Value='" + fileMD5Value + '\'' +
                ", traceId='" + traceId + '\'' +
                ", bucket='" + bucket + '\'' +
                ", dataCode='" + dataCode + '\'' +
                ", formAppCode='" + formAppCode + '\'' +
                ", sendTime=" + sendTime +
                ", dataVersion='" + dataVersion + '\'' +
                ", toAppCode='" + toAppCode + '\'' +
                ", fileEncoding='" + fileEncoding + '\'' +
                '}';
    }
    
}
