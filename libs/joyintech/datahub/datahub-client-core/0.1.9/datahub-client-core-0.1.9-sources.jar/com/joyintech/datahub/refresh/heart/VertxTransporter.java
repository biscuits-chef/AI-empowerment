package com.joyintech.datahub.refresh.heart;

import com.joyintech.datahub.model.URL;
import com.joyintech.datahub.util.ConfHolder;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.RequestOptions;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.concurrent.CompletionStage;

/**
 * VertxTransporter
 * <p>
 * 用于通过 Vert.x HttpClient 异步发送 JSON POST 请求。
 * 内部返回 CompletionStage<T> 以支持 CompletableFuture 链式使用。
 *
 * @author
 * @since 2023/1/1
 */
public class VertxTransporter {

    private static final Logger log = LoggerFactory.getLogger(VertxTransporter.class);


    private final HttpClient httpClient;

    /**
     * 内部保存 Vertx，用于 shutdown
     */
    private Vertx vertx;

    public VertxTransporter(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    private static volatile VertxTransporter INSTANCE;

    /**
     * todo 需充分测试序列化；验证是否需要对JSON反序列化特殊处理
     *             io.vertx.core.json.jackson.DatabindCodec.mapper()
     *                     .configure(com.fasterxml.jackson.databind.MapperFeature.PROPAGATE_TRANSIENT_MARKER, true)
     *                     .configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true)
     *                     .configure(JsonParser.Feature.IGNORE_UNDEFINED, true)
     *                     .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
     *                     .setSerializationInclusion(JsonInclude.Include.NON_NULL);
     * 
     * @return
     */
    public static VertxTransporter getInstance() {
        if (INSTANCE == null) {
            synchronized (VertxTransporter.class) {
                if (INSTANCE == null) {
                    // 只在单例内部创建 Vertx
                    Vertx vertx = Vertx.vertx();
                    HttpClient client = vertx.createHttpClient(
                            new HttpClientOptions()
                                    .setReadIdleTimeout(ConfHolder.getInstance().getReadIdleTimeout())
                                    .setConnectTimeout(ConfHolder.getInstance().getConnectTimeout())
                                    .setKeepAlive(true)
                            // 默认不压缩；心跳为主要，关闭压缩以减少 CPU 开销
                    );
                    // 调用现有构造器
                    INSTANCE = new VertxTransporter(client);
                    // 保存 Vertx 引用用于销毁
                    INSTANCE.vertx = vertx;
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 单例销毁，不动任何业务逻辑
     */
    public static synchronized void shutdown() {
        if (INSTANCE != null) {
            try {
                INSTANCE.httpClient.close();
                if (INSTANCE.vertx != null) {
                    INSTANCE.vertx.close(ar -> {
                        if (ar.succeeded()) {
                            log.info("[VertxTransporter] Vertx shutdown successfully");
                        } else {
                            log.warn("[VertxTransporter] Vertx shutdown failed", ar.cause());
                        }
                    });
                }
            } catch (Exception e) {
                log.error("[VertxTransporter] Shutdown failed", e);
            } finally {
                INSTANCE = null;
            }
        }
    }


    /**
     * 向指定 URL 发送 POST 请求并反序列化响应。
     *
     * @param url  目标地址封装（包含 host、port、path）
     * @param body 请求体对象（会被序列化为 JSON）
     * @param clz  响应结果类型（null 表示忽略响应）
     * @return 异步 CompletionStage，用于链式处理结果
     */
    @SuppressWarnings("unchecked")
    public <T> CompletionStage<T> post(URL url, Serializable body, Class<T> clz) {
        final String host = url.getAddress().getHost();
        final int port = url.getAddress().getPort();
        final String path = url.getLocation().toPath();

        RequestOptions options = new RequestOptions()
                .setMethod(HttpMethod.POST)
                .setHost(host)
                .setPort(port)
                .setURI(path);

        // 1️⃣ 创建请求
        return httpClient
                .request(options)
                .compose(req -> {
                    // 设置 Header + 发送数据
                    req.putHeader(HttpHeaderNames.CONTENT_TYPE, HttpHeaderValues.APPLICATION_JSON);
                    return req.send(JsonObject.mapFrom(body).toBuffer());
                })
                .compose(resp -> {
                    // 2️⃣ 检查响应状态
                    int code = resp.statusCode();
                    if (code != HttpResponseStatus.OK.code()) {
                        String msg = String.format(
                                "HTTP request failed: [%s:%d%s] status=%d, reason=%s",
                                host, port, path, code, resp.statusMessage()
                        );
                        log.warn("[VertxTransporter] {}", msg);
                        return Future.failedFuture(new RuntimeException(msg));
                    }

                    // 3️⃣ 解析响应体
                    return resp.body().compose(buf -> {
                        if (clz == null) {
                            return Future.succeededFuture(null);
                        }
                        if (clz.equals(String.class)) {
                            return Future.succeededFuture((T) buf.toString());
                        }
                        try {
                            return Future.succeededFuture(buf.toJsonObject().mapTo(clz));
                        } catch (Exception e) {
                            log.error("[VertxTransporter] Failed to map response to {}: {}", clz.getSimpleName(), e.getMessage());
                            return Future.failedFuture(e);
                        }
                    });
                })
                .onFailure(err -> log.error("[VertxTransporter] POST {} failed: {}", url, ExceptionUtils.getMessage(err)))
                .toCompletionStage();
    }
}