package com.joyintech.datahub.util;

import com.joyintech.datahub.crypto.DhsCrypto;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.ObsConfContent;
import com.obs.services.ObsClient;
import com.obs.services.ObsConfiguration;

/**
 * OBS 客户端单例持有器
 * 用于统一管理 Reader / Writer 客户端实例
 *
 * @author ChenHao
 * @date 11/7/25 09:06
 */
public class ObsClientHolder {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ObsClientHolder.class);

    /**
     * 单例实例
     */
    private static volatile ObsClientHolder instance;

    /**
     * 读写客户端
     */
    private ObsClient obsClientReader;
    private ObsClient obsClientWriter;

    /**
     * 内置
     */
    private ObsClient obsConfInternal;

    /**
     * 私有构造函数，防止外部实例化
     */
    private ObsClientHolder() {
    }

    public ObsClient getObsConfInternal() {
        return obsConfInternal;
    }

    /**
     * 获取单例实例（双重检查锁）
     */
    public static ObsClientHolder getInstance() {
        if (instance == null) {
            synchronized (ObsClientHolder.class) {
                if (instance == null) {
                    instance = new ObsClientHolder();
                }
            }
        }
        return instance;
    }

    /**
     * 初始化客户端
     */
    public synchronized void init(ObsClient reader, ObsClient writer) {
        if (this.obsClientReader == null && reader != null) {
            this.obsClientReader = reader;
        }
        if (this.obsClientWriter == null && writer != null) {
            this.obsClientWriter = writer;
        }
    }

    public void initReader(ObsClient reader) {
        if (reader == null) {
            // 不允许直接赋值null 需通过 close 方法关闭
            throw new IllegalArgumentException("ObsClientReader cannot be assignment with null. Use close() to close the client.");
        }
        this.obsClientReader = reader;
    }

    public void initWriter(ObsClient writer) {
        if (writer == null) {
            // 不允许直接赋值null 需通过 close 方法关闭
            throw new IllegalArgumentException("ObsClientReader cannot be assignment with null. Use close() to close the client.");
        }
        this.obsClientWriter = writer;
    }

    /**
     * 获取读客户端
     */
    public ObsClient getReader() {
        if (obsClientReader == null) {
            log.warn("OBS Reader client is not initialized.");
            // throw new IllegalStateException("OBS Reader client not initialized.");
        }
        return obsClientReader;
    }

    /**
     * 获取写客户端
     */
    public ObsClient getWriter() {
        if (obsClientWriter == null) {
            log.warn("OBS Writer client is not initialized.");
            // throw new IllegalStateException("OBS Writer client not initialized.");
        }
        return obsClientWriter;
    }
    
    public ObsClient initInternalObsClient(ObsConfContent confContent) {
        log.info("Initializing internal OBS client...");
        ObsConfiguration obsConfiguration = getObsConfiguration();
        obsConfiguration.setEndPoint(confContent.getEndpoint());
        String secretKey = decryptLocalObsSecretKey(confContent.getSecretKey());
        ObsClient obsClient = new ObsClient(confContent.getAccessKey(), secretKey, obsConfiguration);
        instance.obsConfInternal = obsClient;
        return obsClient;
    }

    public void initObsClient() {
        ConfDto confDto = ConfHolder.getInstance().getConfDto();
        ObsConfiguration obsConfiguration = getObsConfiguration();
        obsConfiguration.setEndPoint(confDto.getObs().getEndPoint());
        ConfDto.ObsDetail obsR = confDto.getObs().getObsR();
        ObsClient obsClientR = new ObsClient(obsR.getAk(), obsR.getSk(), obsConfiguration);
        ConfDto.ObsDetail obsW = confDto.getObs().getObsW();
        if (obsW != null) {
            ObsClient obsClientW = new ObsClient(obsW.getAk(), obsW.getSk(), obsConfiguration);
            ObsClientHolder.getInstance().initWriter(obsClientW);
            log.info("OBS Writer client initialized successfully.");
        }
        // 初始化（在系统启动时执行一次）
        ObsClientHolder.getInstance().initReader(obsClientR);
    }


    public void startObsWriterClient(ConfDto.ObsConfig obs) {
        ObsConfiguration obsConfiguration = getObsConfiguration();
        obsConfiguration.setEndPoint(obs.getEndPoint());
        ConfDto.ObsDetail obsW = obs.getObsW();
        ObsClient obsClientW = new ObsClient(obsW.getAk(), obsW.getSk(), obsConfiguration);
        ObsClientHolder.getInstance().initWriter(obsClientW);
    }

    static String decryptLocalObsSecretKey(String secretKey) {
        if (secretKey == null || !secretKey.startsWith(DhsCrypto.PREFIX)) {
            log.debug("[ObsClientHolder] Local OBS secret key does not use DHS encryption.");
            return secretKey;
        }

        log.info("[ObsClientHolder] DHS-encrypted local OBS secret key detected; decrypting.");
        try {
            String decrypted = DhsCrypto.decryptIfNecessary(secretKey);
            if (decrypted == null || decrypted.isEmpty()) {
                throw new IllegalArgumentException("Decrypted OBS secret key cannot be empty");
            }
            log.info("[ObsClientHolder] Local OBS secret key decrypted successfully.");
            return decrypted;
        } catch (RuntimeException e) {
            log.error("[ObsClientHolder] Failed to decrypt local OBS secret key.", e);
            throw e;
        }
    }


    private static ObsConfiguration getObsConfiguration() {
        ObsConfiguration obsConfiguration = new ObsConfiguration();
        // 10分钟超时
        obsConfiguration.setSocketTimeout(600_000);
        // 60秒连接超时
        obsConfiguration.setConnectionTimeout(60_000);
        // 最大重试次数5
        obsConfiguration.setMaxErrorRetry(5);
        // 64KB
        obsConfiguration.setReadBufferSize(65536);
        // 64KB
        obsConfiguration.setWriteBufferSize(65536);
        // 较高并发
        obsConfiguration.setMaxConnections(200);
        // 1分钟空闲
        obsConfiguration.setIdleConnectionTime(60_000);
        return obsConfiguration;
    }


    /**
     * 关闭资源
     */
    public static synchronized void shutdown() {
        if (instance == null) {
            log.info("ObsClientHolder instance is null, nothing to close.");
            return;
        }

        instance.closeObsWriter();
        instance.closeObsReader();
        instance = null;
        log.info("OBS clients closed successfully.");
    }

    public void closeObsWriter() {
        if (instance.obsClientWriter != null) {
            closeQuietly(instance.obsClientWriter);
            instance.obsClientWriter = null;
        }

        log.info("OBS writer client closed successfully.");
    }

    public void closeObsReader() {

        if (instance.obsClientReader != null) {
            closeQuietly(instance.obsClientReader);
            instance.obsClientReader = null;
        }
        
        if (instance.obsConfInternal != null) {
            closeQuietly(instance.obsConfInternal);
            instance.obsConfInternal = null;
        }

        log.info("OBS reader client closed successfully.");
    }


    private void closeQuietly(AutoCloseable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Exception e) {
                log.warn("[ObsClientHolder]Failed to close resource: ", e);
            }
        }
    }

}
