package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.InstMsgDTO;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author ChenHao
 * @date 11/7/25 15:41
 */
public class InstantMsgSender extends AbstractInstantMsgSender {

    private InstantMsgSender() {
    }

    private static final Logger log = LoggerFactory.getLogger(InstantMsgSender.class);

    /**
     * 即时消息发送
     *
     * @param dataDate   业务日期
     * @param instMsgDTO 即时数据请求
     * @param sysCode    目标系统编码
     * @param <T>
     * @return
     */
    public static <T> SendResult sendData(String dataDate, InstMsgDTO<T> instMsgDTO, String sysCode) {
        if (StringUtils.isBlank(dataDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        if (instMsgDTO == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "instMsgDTO can not be null");
        }
        instMsgDTO.validate();
        log.info("即时数据待发送数据：{}", JsonUtil.toJson(instMsgDTO));
        // 发送校验
        ConfDto.ProducerConfig producerConfig = SendPurview.getInstance().sendCheck(instMsgDTO.getDataCode(), instMsgDTO.getDataVersion());
        // 获取 KafkaProducer
        KafkaProducer<String, String> producer = KafkaProducerHolder.getInstance().getProducer();
        String jsonStr = JsonUtil.toJson(instMsgDTO.getValue());
        ProducerRecord<String, String> record;
        if (StringUtils.isNotBlank(instMsgDTO.getPartitionKey())) {
            record = new ProducerRecord<>(producerConfig.getTopic(), instMsgDTO.getPartitionKey(), jsonStr);
        } else {
            record = new ProducerRecord<>(producerConfig.getTopic(), jsonStr);
        }
        return getSendResult(dataDate, instMsgDTO.getDataCode(), instMsgDTO.getDataVersion(), jsonStr, producer, record, LogType.KAFKA_REALTIME, sysCode);
    }

    /**
     * 即时消息发送
     *
     * @param dataDate   数据日期
     * @param instMsgDTO 即时数据请求
     * @return 发送结果
     */
    public static <T> SendResult sendData(String dataDate, InstMsgDTO<T> instMsgDTO) {
        return sendData(dataDate, instMsgDTO, null);
    }

}