package com.joyintech.datahub.obs;

import com.joyintech.datahub.util.ObsClientHolder;
import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.*;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: ObsClientHandler.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/22 14:58 <br/>
 * Description: Obs操作辅助类  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class ObsClientHandler {

    private ObsClientHandler(){

    }

    public static boolean objectKeyExists(ObsClient obsClient, String bucketName, String objectKey){
        try {
            ObjectMetadata metadata = obsClient.getObjectMetadata(bucketName, objectKey);
            return metadata != null;
        } catch (ObsException e) {
            if (e.getResponseCode() == 404) {
                // 对象不存在
                return false;
            }
            // 其他异常，重新抛出或处理
            throw new RuntimeException("检查OBS对象存在性失败", e);
        }
    }
    public static boolean objectKeyExists(String bucketName, String objectKey){
        return objectKeyExists(ObsClientHolder.getInstance().getWriter(), bucketName, objectKey);
    }

    public static PutObjectResult putObject( PutObjectRequest  request) {
        try {
            return ObsClientHolder.getInstance().getWriter().putObject(request);
        } catch (ObsException e) {
            // 处理异常
            throw new ObsException("上传OBS对象失败", e);
        }
    }

    public static ObsObject getObject(GetObjectRequest request){
        try {
            return ObsClientHolder.getInstance().getReader().getObject(request);
        } catch (ObsException e) {
            // 处理异常
            throw new ObsException("获取OBS对象失败", e);
        }
    }
}
