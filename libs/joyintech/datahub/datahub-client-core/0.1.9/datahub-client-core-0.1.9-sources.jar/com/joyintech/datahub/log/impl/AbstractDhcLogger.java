package com.joyintech.datahub.log.impl;

import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.log.DhcLogger;

/**
 * AbstractDhcLogger
 *
 * @author 
 * @since 2022/9/16
 */
public abstract class AbstractDhcLogger implements DhcLogger {

    @Override
    public void info(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args) {
        info(traceId, logType, dataDate, null, dataCode, version, msg, durationMs, args);
    }

    @Override
    public void error(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args) {
        error(traceId, logType, dataDate,null, dataCode, version, msg, durationMs, args);
    }

    @Override
    public void warn(String traceId, LogType logType, String dataDate, String dataCode, String version, String msg, Long durationMs, String... args) {
        warn(traceId, logType, dataDate,null, dataCode, version, msg, durationMs, args);
    }
}
