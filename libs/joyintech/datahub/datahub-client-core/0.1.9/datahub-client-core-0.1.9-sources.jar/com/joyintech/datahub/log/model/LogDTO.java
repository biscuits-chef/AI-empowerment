package com.joyintech.datahub.log.model;

/**
 * @author ChenHao
 * @date 11/12/25 15:45
 */
public class LogDTO {
    
    private String traceId;
    /**
     * @see com.joyintech.datahub.common.enums.LogType
     */
    private String logType;
    /**
     * @see com.joyintech.datahub.common.enums.LogPhase
     */
    private String logPhase;
    private String appCode;
    private String dataCode;
    private String version;
    private String time;
    private String level;
    private String message;
    private String host;
    private String headers;
    private Long durationMs;
    /**
     * 平台日
     */
    private String dataDate;
    /**
     * 即时信息报文
     */
    private String recordContents;

    public LogDTO() {
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getLogPhase() {
        return logPhase;
    }

    public void setLogPhase(String logPhase) {
        this.logPhase = logPhase;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }
    
    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Long durationMs) {
        this.durationMs = durationMs;
    }

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getRecordContents() {
        return recordContents;
    }

    public void setRecordContents(String recordContents) {
        this.recordContents = recordContents;
    }

    @Override
    public String toString() {
        return "LogDTO{" +
                "traceId='" + traceId + '\'' +
                ", logType='" + logType + '\'' +
                ", logPhase='" + logPhase + '\'' +
                ", appCode='" + appCode + '\'' +
                ", dataCode='" + dataCode + '\'' +
                ", version='" + version + '\'' +
                ", time='" + time + '\'' +
                ", level='" + level + '\'' +
                ", message='" + message + '\'' +
                ", host='" + host + '\'' +
                ", durationMs=" + durationMs +
                ", dataDate='" + dataDate + '\'' +
                ", recordContents='" + recordContents + '\'' +
                '}';
    }

    public static class Builder {
        private final LogDTO logDTO;

        public Builder() {
            logDTO = new LogDTO();
        }
        
        public Builder dataDate(String dataDate) {
            logDTO.setDataDate(dataDate);
            return this;
        }
        
        public Builder logPhase(String logPhase) {
            logDTO.setLogPhase(logPhase);
            return this;
        }

        public Builder traceId(String traceId) {
            logDTO.setTraceId(traceId);
            return this;
        }

        public Builder appCode(String appCode) {
            logDTO.setAppCode(appCode);
            return this;
        }

        public Builder dataCode(String dataCode) {
            logDTO.setDataCode(dataCode);
            return this;
        }

        public Builder version(String version) {
            logDTO.setVersion(version);
            return this;
        }

        public Builder time(String time) {
            logDTO.setTime(time);
            return this;
        }

        public Builder level(String level) {
            logDTO.setLevel(level);
            return this;
        }

        public Builder message(String message) {
            logDTO.setMessage(message);
            return this;
        }

        public Builder host(String host) {
            logDTO.setHost(host);
            return this;
        }

        public Builder durationMs(Long durationMs) {
            logDTO.setDurationMs(durationMs);
            return this;
        }
        
        public Builder logType(String logType) {
            logDTO.setLogType(logType);
            return this;
        }
        
        public Builder headers(String headers) {
            logDTO.setHeaders(headers);
            return this;
        }
        
        public Builder recordContents(String recordContents) {
            logDTO.setRecordContents(recordContents);
            return this;
        }

        public LogDTO build() {
            return logDTO;
        }
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
}