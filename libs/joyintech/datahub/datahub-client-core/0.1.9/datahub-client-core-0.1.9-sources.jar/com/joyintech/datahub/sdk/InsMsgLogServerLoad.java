package com.joyintech.datahub.sdk;

import com.joyintech.datahub.sdk.impl.DefaultFileConsumerRecord;
import com.joyintech.datahub.sdk.impl.DefaultInstMsgConsumerRecord;
import com.joyintech.datahub.sdk.impl.DefaultInstMsgSendRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: InsMsgLogServerLoad.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 14:13 <br/>
 * Description: 即时消息日志服务加载 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class InsMsgLogServerLoad {

    private static final Logger log = LoggerFactory.getLogger(InsMsgLogServerLoad.class);

    private static final InsMsgLogServerLoad instance;

    static {
        instance = new InsMsgLogServerLoad();
    }

    public static InsMsgLogServerLoad getInstance(){
        return instance;
    }
    /**
     * 获取InstantMsgLog实例
     */
    private InstMsgConsumerRecord instantMsgLog;
    /**
     * 获取InstMsgSendRecord实例
     * 采用懒加载模式，外部未设置使用默认配置
     */
    private InstMsgSendRecord instMsgSendRecord;
    /**
     * 文件消费记录
     */
    private FileConsumerRecord fileConsumerRecord;
    /**
     * 获取InstantMsgLog实例
     * 采用懒加载模式，外部未设置使用默认配置
     */
    public InstMsgConsumerRecord getInstantMsgLog(){

        if (instantMsgLog == null) {
            synchronized (InsMsgLogServerLoad.class) {
                if(instantMsgLog == null) {
                    instantMsgLog = new DefaultInstMsgConsumerRecord();
                    log.info("InstantMsgLog 使用默认日志打印记录模式");
                }
            }
        }
        return instantMsgLog;
    }

    public InstMsgSendRecord getInstMsgSendRecord() {
        if (instMsgSendRecord == null) {
            synchronized (InsMsgLogServerLoad.class) {
                if(instMsgSendRecord == null) {
                    instMsgSendRecord = new DefaultInstMsgSendRecord();
                    log.info("instMsgSendRecord 使用默认日志打印记录模式");
                }
            }
        }
        return instMsgSendRecord;
	}

    public FileConsumerRecord getFileConsumerRecord() {
		if (fileConsumerRecord == null) {
            synchronized (InsMsgLogServerLoad.class) {
                if(fileConsumerRecord == null) {
                    fileConsumerRecord = new DefaultFileConsumerRecord();
                    log.info("fileConsumerRecord 使用默认日志打印记录模式");
                }
            }
        }
		return fileConsumerRecord;
	}

    public void setInsMsgLog(InstMsgConsumerRecord insMsgLog){
        this.instantMsgLog = insMsgLog;
    }

    public void setInstMsgSendRecord(InstMsgSendRecord instMsgSendRecord) {
		this.instMsgSendRecord = instMsgSendRecord;
	}

    public void setFileConsumerRecord(FileConsumerRecord fileConsumerRecord) {
		this.fileConsumerRecord = fileConsumerRecord;
	}
}
