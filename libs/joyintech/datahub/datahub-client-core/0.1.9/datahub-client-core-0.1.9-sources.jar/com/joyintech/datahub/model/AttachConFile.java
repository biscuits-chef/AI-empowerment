package com.joyintech.datahub.model;

import java.io.File;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AttachConFile.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 17:07 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AttachConFile {
    /**
     *文件原名
    */
    private String fileSourceName;
    /**
     *文件信息
     */
    private File file;

    public String getFileSourceName() {
        return fileSourceName;
    }

    public void setFileSourceName(String fileSourceName) {
        this.fileSourceName = fileSourceName;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
