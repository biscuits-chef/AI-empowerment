package com.joyintech.datahub.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: JarVersionUtil.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/19 13:49 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class JarVersionUtil {

    private static final Logger log = LoggerFactory.getLogger(JarVersionUtil.class);

    private JarVersionUtil() {
        // private  constructor
    }
    private static final Map<String, String> VERSION_CACHE = new ConcurrentHashMap<>();


    /**
     * 获取单个class的版本信息
     */
    public static void collectVersion(Class<?> clazz) {
        if (clazz == null) {
            return ;
        }

        try {
            Package pkg = clazz.getPackage();
            if (pkg == null) {
                return ;
            }

            String title = pkg.getImplementationTitle();
            String version = pkg.getImplementationVersion();
            String specVersion = pkg.getSpecificationVersion();

            // 如果ImplementationVersion为空，尝试SpecificationVersion
            if (version == null) {
                version = specVersion;
            }

            // 如果title为空，使用类名
            if (title == null) {
                title = getSimpleJarName(clazz);
            }
            if (!VERSION_CACHE.containsKey(title)) {
                if (version == null) {
                    version = "unknown";
                }
                VERSION_CACHE.put(title, version);
            }

        } catch (Exception e) {
           log.error("获取jar版本信息异常", e);
        }
    }

    /**
     * 获取所有已查询过的版本信息
     */
    public static Map<String, String> getAllCollectedVersions() {
        return new HashMap<>(VERSION_CACHE);
    }

    /**
     * 清空版本缓存
     */
    public static void clearCache() {
        VERSION_CACHE.clear();
    }

    /**
     * 从类名提取简化的jar包名称
     */
    private static String getSimpleJarName(Class<?> clazz) {
        return clazz.getSimpleName();
    }
}
