package com.joyintech.datahub.sender;

import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.enums.FileFormat;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.FileGenStats;
import com.joyintech.datahub.util.FileUtil;
import com.joyintech.datahub.util.MD5Util;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.PutObjectResult;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: FileAbstractSender.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/20 13:51 <br/>
 * Description: 文件发送抽象类  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public abstract class FileAbstractSender {


    /**
     *功能描述: 构建文件发送结果信息
     */
    public SendResult.FileResultInfo buildFileResultInfo(PutObjectResult result, FileGenStats fgs){
        return buildFileResultInfo(result.getEtag(), result.getObjectKey(), result.getBucketName(), fgs);
    }

    public SendResult.FileResultInfo buildFileResultInfo(CompleteMultipartUploadResult result, FileGenStats fgs){
        return buildFileResultInfo(result.getEtag(), result.getObjectKey(), result.getBucketName(), fgs);
    }

    public SendResult.FileResultInfo buildFileResultInfo(String eTage, String objectKey, String bucketName, FileGenStats fgs){
        SendResult.FileResultInfo fileResultInfo = new SendResult.FileResultInfo();
        fileResultInfo.setObjectKey(objectKey);
        fileResultInfo.setFileSize(fgs.getTotalSize());
        fileResultInfo.setLineCount(fgs.getLineCount());
        fileResultInfo.setFileMD5(MD5Util.cleanObsEtag(eTage));
        fileResultInfo.setBucketName(bucketName);
        fileResultInfo.setFileName(FileUtil.extractFilenameOnly(objectKey));
        return fileResultInfo;
    }
    
    /**
     * 功能描述: 构建文件生成统计信息
     * @param fileSize 文件大小
     * @param lineCount 行数
     * @return FileGenStats 文件生成统计信息
     */
    public FileGenStats buildFileGenStats(long fileSize, long lineCount){
        FileGenStats fgs = new FileGenStats();
        fgs.setTotalSize(fileSize);
        fgs.setLineCount(lineCount);
        return fgs;
    }
    /**
     * 校验文件类型
     */
    public void checkFileType(String fileName, ConfDto.ProducerConfig producerConfig){
        FileFormat fileFormat = FileUtil.detectFileFormat(fileName);
        FileFormat targetFileFormat = FileFormat.valueOf(producerConfig.getFileType().toUpperCase());
        if (targetFileFormat != fileFormat) {
            throw new DataHubException(DataHubErrorEnum.FILE_FORMAT_ERROR, "文件格式错误");
        }
    }
}
