package com.joyintech.datahub.common.enums;

/**
 * @author ChenHao
 * @date 11/22/25 13:52
 */
public enum LogType {

    /**
     * 文件处理阶段产生的日志
     */
    FILE_PROCESSING("FILE", "文件处理日志"),

    /**
     * Kafka 即时消息产生的日志
     */
    KAFKA_REALTIME("KAFKA", "即时消息"),

    /**
     * Kafka 附件日志
     */
    KAFKA_ATTACH("ATTACH", "附件消息"),

    /**
     * SDK 内部使用的日志
     */
    INTERNAL_SDK("INTERNAL", "SDK 内置日志"),

    
    ;

    private final String code;
    private final String desc;

    LogType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 根据 code 获取枚举
     */
    public static LogType fromCode(String code) {
        for (LogType type : LogType.values()) {
            if (type.code.equalsIgnoreCase(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown LogType code: " + code);
    }
}