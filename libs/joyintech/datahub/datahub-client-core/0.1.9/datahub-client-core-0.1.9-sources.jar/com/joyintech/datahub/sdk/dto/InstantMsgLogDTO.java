package com.joyintech.datahub.sdk.dto;

import java.io.Serializable;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: InstantMsgLogDTO.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/11/12 13:58 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class InstantMsgLogDTO implements Serializable {
    //消息ID
    private String traceId;
    //来源appCode
    private String fromAppCode;
    //数据编码
    private String dataCode;
    //数据版本
    private String dataVersion;
    //接收时间 YYYY-MM-DD HH:MM:SS
    private String receiveTime;
    //发送时间 YYYY-MM-DD HH:MM:SS
    private String sendTime;
    //消息体-json字符串
    private String msg;
    //数据日期
    private String dataDate;

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getFromAppCode() {
        return fromAppCode;
    }

    public void setFromAppCode(String fromAppCode) {
        this.fromAppCode = fromAppCode;
    }

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public String getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(String receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String getMsg() {
        return msg;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    @Override
    public String toString(){
        return "InstantMsgLogDTO={fromAppCode=" +fromAppCode+
                ",dataCode="+dataCode+
                ",traceId="+traceId+
                ",dataVersion="+dataVersion+
                ",receiveTime="+receiveTime+
                ",sendTime="+sendTime+
                ",msg="+msg+
                "}";
    }
}
