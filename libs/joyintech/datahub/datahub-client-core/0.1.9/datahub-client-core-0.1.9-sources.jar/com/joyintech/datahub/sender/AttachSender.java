package com.joyintech.datahub.sender;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.common.enums.DataHubErrorEnum;
import com.joyintech.datahub.common.enums.LogType;
import com.joyintech.datahub.exception.DataHubException;
import com.joyintech.datahub.handler.TempUrlHandler;
import com.joyintech.datahub.model.*;
import com.joyintech.datahub.obs.ObsClientHandler;
import com.joyintech.datahub.purview.SendPurview;
import com.joyintech.datahub.util.*;
import com.obs.services.model.CompleteMultipartUploadResult;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.PutObjectResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C),2002-2026, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: AttachSender.java <br/>
 * Author: zy22350 <br/>
 * Date:  2026/1/13 16:07 <br/>
 * Description: //模块目的、功能描述  <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class AttachSender extends AbstractInstantMsgSender {

    private static final Logger log = LoggerFactory.getLogger(AttachSender.class);

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private AttachSender() {
        // nothing done
    }

    /**
     * 附件消息发送
     *
     * @param dataDate     业务日期
     * @param attachMsgDTO 附件数据请求
     * @param sysCode      目标系统编码
     * @param <T>
     * @return
     */
    public static <T> SendResult sender(String dataDate, AttachMsgDTO<T> attachMsgDTO, String sysCode) {
        if (StringUtils.isBlank(dataDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        if (attachMsgDTO == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "instMsgDTO can not be null");
        }
        attachMsgDTO.validate();
        if(log.isInfoEnabled()) {
            log.info("附件数据待发送数据：{}", JsonUtil.toJson(attachMsgDTO));
        }
        // 发送校验
        ConfDto.ProducerConfig producerConfig = SendPurview.getInstance().sendCheck(attachMsgDTO.getDataCode(),
                attachMsgDTO.getDataVersion());
        // 获取 KafkaProducer
        KafkaProducer<String, String> producer = KafkaProducerHolder.getInstance().getProducer();

        // 业务数据
        String jsonStr = JsonUtil.toJson(attachMsgDTO.getValue());

        // 附件列表
        List<AttachFile> attachFileList = attachMsgDTO.getAttachFileList();

        // 将 attachFileList 转成 JSON 字符串，再转成字节数组
        byte[] attachFileBytes = new byte[0];
        try {
            if (attachFileList != null && !attachFileList.isEmpty()) {
                String attachFileJson = objectMapper.writeValueAsString(attachFileList);
                attachFileBytes = attachFileJson.getBytes(StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            throw new DataHubException(DataHubErrorEnum.EXCEPTION, "附件列表序列化失败", e);
        }

        ProducerRecord<String, String> prdRecord;
        if (StringUtils.isNotBlank(attachMsgDTO.getPartitionKey())) {
            prdRecord = new ProducerRecord<>(producerConfig.getTopic(), attachMsgDTO.getPartitionKey(), jsonStr);
        } else {
            prdRecord = new ProducerRecord<>(producerConfig.getTopic(), jsonStr);
        }

        // 添加 header
        prdRecord.headers().add(new RecordHeader(DataHubConstant.ATTACH_FILE_LIST, attachFileBytes));

        return getSendResult(dataDate, attachMsgDTO.getDataCode(), attachMsgDTO.getDataVersion(), jsonStr, producer, prdRecord, LogType.KAFKA_ATTACH, sysCode);
    }

    /**
     * 附件消息发送
     *
     * @param dataDate     业务日期
     * @param attachMsgDTO 附件数据请求
     * @param <T>
     * @return
     */
    public static <T> SendResult sender(String dataDate, AttachMsgDTO<T> attachMsgDTO) {
        return sender(dataDate, attachMsgDTO, null);
    }
    /**
     * 针对只有本地文件而无OBS或S3的场景，文件放数交给其分配的OBS上处理附件
     * @param dataDate 数据时间
     * @param attachFileDTO 待处理文件信息
     * @param sysCode 点对点发送对方系统ID
     */
    public static <T> SendResult senderFiles(String dataDate, AttachFileDTO<T> attachFileDTO, String sysCode){
        if (StringUtils.isBlank(dataDate)) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "业务日期不能为空");
        }
        if (attachFileDTO == null) {
            throw new DataHubException(DataHubErrorEnum.PARAM_ERROR, "附件信息不能为空");
        }
        AttachMsgDTO<T> msgDTO = new AttachMsgDTO<>();
        msgDTO.setValue(attachFileDTO.getValue());
        msgDTO.setDataCode(attachFileDTO.getDataCode());
        msgDTO.setDataVersion(attachFileDTO.getDataVersion());
        msgDTO.setAttachFileList(uploadAndGet(attachFileDTO.getAttachType(),attachFileDTO.getAttachFileList()));
        msgDTO.setPartitionKey(attachFileDTO.getPartitionKey());
        return sender(dataDate, msgDTO, sysCode);
    }
    /**
     * 针对只有本地文件而无OBS或S3的场景，文件放数交给其分配的OBS上处理附件
     * @param dataDate 数据时间
     * @param attachFileDTO 待处理文件信息,其中attachType为附件分类，业务调用方自定义，作为obs目录使用，故同一分类的使用相同的分类，若不传不会分目录存储
     */
    public static <T> SendResult senderFiles(String dataDate, AttachFileDTO<T> attachFileDTO){
        return senderFiles(dataDate,attachFileDTO,null);
    }

    /**
     *功能描述 上传并得到授权文件URL
     */
    private static List<AttachFile> uploadAndGet(String attachType,List<OnlyAttachFile> files){
        List<AttachFile> lists = new ArrayList<>(files.size());
        AttachFile af ;
        for(OnlyAttachFile f : files){
            af = new AttachFile();
            af.setFileSourceName(f.getFileSourceName());
            String objectKey = upload(ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(),
                    f.getFile(),attachType);
            log.debug("附件:{},上传obs完成，objectKey:{}",f.getFileSourceName(),objectKey);
            String tmpUrl = TempUrlHandler.buildTempUrl(ObsClientHolder.getInstance().getWriter(),
                    ConfHolder.getInstance().getConfDto().getObs().getObsW().getBucketName(),objectKey);
            log.debug("附件:{},临时授权url生成完成，url:{}", f.getFileSourceName(), tmpUrl);
            af.setFileTmpUrl(tmpUrl);
            lists.add(af);
        }
        return lists;
    }


    /**
     *功能描述: 上传文件并返回objectKey
     */
    private static String upload(String bucketName,File file,String attachType){
        String path = StringUtils.isBlank(attachType) ? DataHubConstant.ATTACH_DIR :
                String.format(FileUtil.MARKER_DIRECTORY, DataHubConstant.ATTACH_DIR , attachType);
        String objectKey =  FileUtil.objectKeyBuilder(path,
                IdUtil.generateStrId() + DataHubConstant.GROUP_SEPARATOR + file.getName());
        if (FileUtil.isFileLargerThanXMB(file)) {
            MultipartReqDTO reqDTO = new MultipartReqDTO();
            reqDTO.setBucketName(bucketName);
            reqDTO.setFile(file);
            reqDTO.setObjectKey(objectKey);
            // 超过 50MB，走分片 / 断点续传
            CompleteMultipartUploadResult result =
                    RetryUtil.executeWithRetry(() -> ObsUploader.getInstance().uploadFileProcess(reqDTO,true),
                            "大文件分片上传");
            return result.getObjectKey();
        } else {
            // 普通上传
            PutObjectRequest putRequest = new PutObjectRequest(bucketName, objectKey, file);

            PutObjectResult result = RetryUtil.executeWithRetry(() -> ObsClientHandler.putObject(putRequest),
                    "小文件上传");
            return result.getObjectKey();
        }
    }
}
