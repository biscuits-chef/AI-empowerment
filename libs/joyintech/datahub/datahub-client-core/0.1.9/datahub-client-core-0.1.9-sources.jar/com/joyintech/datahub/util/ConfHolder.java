package com.joyintech.datahub.util;

import com.joyintech.datahub.common.constant.DataHubConstant;
import com.joyintech.datahub.model.ConfDto;
import com.joyintech.datahub.model.ObsConfContent;
import com.joyintech.datahub.model.URL;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import java.util.concurrent.TimeUnit;


/**
 * 全局配置持有器
 * dataHub 全局数据维护持有者
 * 用于在系统中统一维护 ConfDto 对象
 * <p>
 * 初始化配置项：appCode、confUrl、apiKey、timeout、url、tempDirectory
 *
 * @author ChenHao
 * @date 11/8/25 15:12
 */
public class ConfHolder {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(ConfHolder.class);

    /**
     * 单例实例
     */
    private static volatile ConfHolder instance;

    /**
     * 应用编码
     */
    private volatile String appCode;

    /**
     * 应用名称
     */
    private String serverName = "default";

    /**
     * 初次配置拉取地址
     * 接口返回 ConfDto 对象
     */
    private URL confUrl;

    /**
     * 空文件通知
     */
    private String notifyIfEmpty = "N";

    /**
     * 配置解密密钥
     */
    private String confKey;

    /**
     * 心跳url
     * 接口返回 version
     */
    private String healthUrl;

    /**
     * 启动后多久开始发送心跳
     */
    private long initialDelay = 10;

    /**
     * 心跳间隔时间
     */
    private long period = 30;

    private TimeUnit unit = TimeUnit.SECONDS;

    /**
     * server 颁发的key
     */
    private String apiKey;

    private int timeout = 10;

    /**
     * 心跳地址配置
     */
    private URL url;

    private int readIdleTimeout = 60;
    private int connectTimeout = 60;

    /**
     * 本地临时目录
     * <p>
     * obs上传临时目录 ./dataHub/fileTemp/obs/
     */
    private String tempDirectory = "./dataHub/fileTemp/";

    /**
     * TODO 附件临时目录
     * 注意: 附件目录必须独立！！！ 在系统关闭时会清理该目录
     * 注意: 附件目录必须独立！！！ 在系统关闭时会清理该目录
     * 注意: 附件目录必须独立！！！ 在系统关闭时会清理该目录
     *
     * @see com.joyintech.datahub.delayed.GlobalFileDeleter shutdown() 会删除该目录下的所有文件
     * 附件默认5分钟后删除
     */
    private String attachTempDirectory = "attach/";

    /**
     * 异常堆栈跟踪深度限制
     */
    private Integer stackTraceLimit = 5;

    /**
     * =========================默认配置=========================
     */
    private String defLogUploadDataCode = "producer_log";
    private String defLogUploadVersion = "1.0";
    private String defFileNotifyDataCode = "producer_file";
    private String defFileNotifyVersion = "1.0";


    private ObsUploadConf obsUploadConf;

    /**
     * 全局配置对象
     */
    private volatile ConfDto confDto;

    /**
     * 初始化OBS配置内容
     */
    private ObsConfContent obsConfContent;

    /**
     * 私有构造函数防止外部实例化
     */
    private ConfHolder() {
    }

    /**
     * 获取单例实例（DCL 双重检查锁）
     */
    public static ConfHolder getInstance() {
        if (instance == null) {
            synchronized (ConfHolder.class) {
                if (instance == null) {
                    instance = new ConfHolder();
                }
            }
        }
        return instance;
    }

    public static synchronized void shutdown() {
        instance.confDto = null;
        instance = null;
    }

    /**
     * 初始化配置（仅在首次启动时使用）
     */
    public synchronized void init(ConfDto confDto) {
        if (this.confDto == null && confDto != null) {
            this.confDto = confDto;
        }
    }

    /**
     * 获取当前配置
     */
    public ConfDto getConfDto() {
        if (confDto == null) {
            throw new IllegalStateException("ConfDto not initialized, please call ConfHolder.init() first.");
        }
        return confDto;
    }

    public Integer getStackTraceLimit() {
        return stackTraceLimit;
    }

    public void setStackTraceLimit(Integer stackTraceLimit) {
        this.stackTraceLimit = stackTraceLimit;
    }

    /**
     * 热更新配置（允许运行时重新加载）
     */
    public synchronized void reload(ConfDto newConfDto) {
        this.confDto = newConfDto;
    }

    /**
     * 清空配置（可选，用于关闭时释放）
     */
    public synchronized void clear() {
        this.confDto = null;
    }

    public static class ObsUploadConf {
        /**
         * 并发数
         */
        private Integer taskNum = 4;
        /**
         * 分片大小
         */
        private Long partSize = 50L;
        /**
         * 是否开启分片上传进度监控
         */
        private Boolean listener = false;
        /**
         * 断点续传
         */
        private Boolean enableCheckpoint = true;

        public Integer getTaskNum() {
            return taskNum;
        }

        public void setTaskNum(Integer taskNum) {
            this.taskNum = taskNum;
        }

        public Long getPartSize() {
            return partSize;
        }

        public Long getPartSizeInBytes() {
            return partSize * 1024 * 1024;
        }

        public void setPartSize(Long partSize) {
            this.partSize = partSize;
        }

        public Boolean getListener() {
            return listener;
        }

        public void setListener(Boolean listener) {
            this.listener = listener;
        }

        public Boolean getEnableCheckpoint() {
            return enableCheckpoint;
        }

        public void setEnableCheckpoint(Boolean enableCheckpoint) {
            this.enableCheckpoint = enableCheckpoint;
        }

        @Override
        public String toString() {
            return "ObsUploadConf{" +
                    "taskNum=" + taskNum +
                    ", partSize=" + partSize +
                    ", listener=" + listener +
                    ", enableCheckpoint=" + enableCheckpoint +
                    '}';
        }
    }


    // =================getter and setter=================


    public boolean notifyIfEmpty() {
        if (StringUtils.isBlank(notifyIfEmpty) || DataHubConstant.Y_OR_N_N.equalsIgnoreCase(notifyIfEmpty)) {
            return false;
        }
        return true;
    }

    public void setNotifyIfEmpty(String notifyIfEmpty) {
        if (StringUtils.isBlank(notifyIfEmpty)) {
            log.info("[ConfHolder] notifyIfEmpty is blank, default to 'N'.");
            return;
        }
        this.notifyIfEmpty = notifyIfEmpty;
    }

    public int getReadIdleTimeout() {
        return readIdleTimeout * 1000;
    }

    public void setReadIdleTimeout(int readIdleTimeout) {
        this.readIdleTimeout = readIdleTimeout;
    }

    public int getConnectTimeout() {
        return connectTimeout * 1000;
    }

    public void setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public String getAppCode() {
        if (StringUtils.isEmpty(appCode)) {
            log.warn("[ConfHolder] appCode is empty, please ensure DataHubInitializer has been initialized.");
        }
        return appCode;
    }

    public String getAttachTempDirectory() {
        return tempDirectory + attachTempDirectory;
    }

    public void setAttachTempDirectory(String attachTempDirectory) {
        this.attachTempDirectory = attachTempDirectory;
    }

    public ObsUploadConf getObsUploadConf() {
        return obsUploadConf;
    }

    public void setObsUploadConf(ObsUploadConf obsUploadConf) {
        this.obsUploadConf = obsUploadConf;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public URL getConfUrl() {
        return confUrl;
    }

    public void setConfUrl(URL confUrl) {
        this.confUrl = confUrl;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getDefLogUploadDataCode() {
        return defLogUploadDataCode;
    }

    public void setDefLogUploadDataCode(String defLogUploadDataCode) {
        this.defLogUploadDataCode = defLogUploadDataCode;
    }

    public String getDefLogUploadVersion() {
        return defLogUploadVersion;
    }

    public void setDefLogUploadVersion(String defLogUploadVersion) {
        this.defLogUploadVersion = defLogUploadVersion;
    }

    public String getDefFileNotifyDataCode() {
        return defFileNotifyDataCode;
    }

    public void setDefFileNotifyDataCode(String defFileNotifyDataCode) {
        this.defFileNotifyDataCode = defFileNotifyDataCode;
    }

    public String getDefFileNotifyVersion() {
        return defFileNotifyVersion;
    }

    public void setDefFileNotifyVersion(String defFileNotifyVersion) {
        this.defFileNotifyVersion = defFileNotifyVersion;
    }

    public String getTempDirectory() {
        return tempDirectory;
    }

    public void setTempDirectory(String tempDirectory) {
        this.tempDirectory = tempDirectory;
    }

    public String getHealthUrl() {
        return healthUrl;
    }

    public void setHealthUrl(String healthUrl) {
        this.healthUrl = healthUrl;
    }

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public long getInitialDelay() {
        return initialDelay;
    }

    public void setInitialDelay(long initialDelay) {
        this.initialDelay = initialDelay;
    }

    public long getPeriod() {
        return period;
    }

    public void setPeriod(long period) {
        this.period = period;
    }

    public TimeUnit getUnit() {
        return unit;
    }

    public void setUnit(TimeUnit unit) {
        this.unit = unit;
    }

    public ObsConfContent getObsConfContent() {
        return obsConfContent;
    }

    public String getConfKey() {
        return confKey;
    }

    public void setConfKey(String confKey) {
        this.confKey = confKey;
    }

    public void setObsConfContent(ObsConfContent obsConfContent) {
        this.obsConfContent = obsConfContent;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }
}