package com.joyintech.datahub.file;

import java.util.List;
import java.util.Map;

/**
 * Copyright (C),2002-2025, 安徽兆尹信息科技股份有限公司<br/>
 * FileName: MapFieldExtractor.java <br/>
 * Author: zy22350 <br/>
 * Date:  2025/12/13 16:58 <br/>
 * Description: Map专用转化器 <br/>
 * History: //修改记录 <br/>（可选）
 * <author/>   <time/>   <version/>    <desc/> <br/>
 * 修改人姓名  修改时间    版本号        描述  <br/>
 */
public class MapFieldExtractor implements FieldExtractor<Map<String, Object>> {
    private final List<String> fieldOrder; // 字段顺序列表
    private final boolean allowNullValue;  // 是否允许空值

    public MapFieldExtractor(List<String> fieldOrder) {
        this(fieldOrder, true);
    }

    public MapFieldExtractor(List<String> fieldOrder, boolean allowNullValue) {
        this.fieldOrder = fieldOrder;
        this.allowNullValue = allowNullValue;
    }

    @Override
    public List<String> extractFields(Map<String, Object> data) {
        if (data == null) {
            throw new IllegalArgumentException("Map 数据不能为 null");
        }

        if (fieldOrder == null || fieldOrder.isEmpty()) {
            throw new IllegalStateException("字段顺序未配置");
        }

        List<String> fields = new java.util.ArrayList<>();
        for (String fieldName : fieldOrder) {
            Object value = data.get(fieldName);
            if (value == null) {
                if (allowNullValue) {
                    fields.add("");
                } else {
                    throw new IllegalStateException("字段 " + fieldName + " 值为 null");
                }
            } else {
                fields.add(value.toString());
            }
        }
        return fields;
    }

    /**
     * 获取字段顺序配置
     */
    public List<String> getFieldOrder() {
        return fieldOrder;
    }
}
