
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="UserInfoQryRsltType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UserBscInfo" type="{http://esb.spdbbiz.com/services/S120030044}UserBscInfoType" minOccurs="0"/>
 *         &lt;element name="UserAdvInfo" type="{http://esb.spdbbiz.com/services/S120030044}UserAdvInfoType" minOccurs="0"/>
 *         &lt;element name="UserCpcInfo" type="{http://esb.spdbbiz.com/services/S120030044}UserCpcInfoType" minOccurs="0"/>
 *         &lt;element name="InstInfoList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="InstInfo" type="{http://esb.spdbbiz.com/services/S120030044}InstInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="GrpInfoList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="GrpInfo" type="{http://esb.spdbbiz.com/services/S120030044}GrpInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OrgCpcInfoList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="OrgCpcInfo" type="{http://esb.spdbbiz.com/services/S120030044}OrgCpcInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserInfoQryRsltType", propOrder = {
    "userBscInfo",
    "userAdvInfo",
    "userCpcInfo",
    "instInfoList",
    "grpInfoList",
    "orgCpcInfoList"
})
public class UserInfoQryRsltType {

    @XmlElement(name = "UserBscInfo")
    protected UserBscInfoType userBscInfo;
    @XmlElement(name = "UserAdvInfo")
    protected UserAdvInfoType userAdvInfo;
    @XmlElement(name = "UserCpcInfo")
    protected UserCpcInfoType userCpcInfo;
    @XmlElement(name = "InstInfoList")
    protected InstInfoList instInfoList;
    @XmlElement(name = "GrpInfoList")
    protected GrpInfoList grpInfoList;
    @XmlElement(name = "OrgCpcInfoList")
    protected OrgCpcInfoList orgCpcInfoList;

    /**
     * 
     * @return
     *     possible object is
     *     {@link UserBscInfoType }
     *     
     */
    public UserBscInfoType getUserBscInfo() {
        return userBscInfo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link UserBscInfoType }
     *     
     */
    public void setUserBscInfo(UserBscInfoType value) {
        this.userBscInfo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link UserAdvInfoType }
     *     
     */
    public UserAdvInfoType getUserAdvInfo() {
        return userAdvInfo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link UserAdvInfoType }
     *     
     */
    public void setUserAdvInfo(UserAdvInfoType value) {
        this.userAdvInfo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link UserCpcInfoType }
     *     
     */
    public UserCpcInfoType getUserCpcInfo() {
        return userCpcInfo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link UserCpcInfoType }
     *     
     */
    public void setUserCpcInfo(UserCpcInfoType value) {
        this.userCpcInfo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link InstInfoList }
     *     
     */
    public InstInfoList getInstInfoList() {
        return instInfoList;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link InstInfoList }
     *     
     */
    public void setInstInfoList(InstInfoList value) {
        this.instInfoList = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link GrpInfoList }
     *     
     */
    public GrpInfoList getGrpInfoList() {
        return grpInfoList;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link GrpInfoList }
     *     
     */
    public void setGrpInfoList(GrpInfoList value) {
        this.grpInfoList = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link OrgCpcInfoList }
     *     
     */
    public OrgCpcInfoList getOrgCpcInfoList() {
        return orgCpcInfoList;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link OrgCpcInfoList }
     *     
     */
    public void setOrgCpcInfoList(OrgCpcInfoList value) {
        this.orgCpcInfoList = value;
    }


    /**
     * 
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="GrpInfo" type="{http://esb.spdbbiz.com/services/S120030044}GrpInfoType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "grpInfo"
    })
    public static class GrpInfoList {

        @XmlElement(name = "GrpInfo")
        protected List<GrpInfoType> grpInfo;

        /**
         * Gets the value of the grpInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the grpInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getGrpInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GrpInfoType }
         * 
         * 
         */
        public List<GrpInfoType> getGrpInfo() {
            if (grpInfo == null) {
                grpInfo = new ArrayList<GrpInfoType>();
            }
            return this.grpInfo;
        }

    }


    /**
     * 
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="InstInfo" type="{http://esb.spdbbiz.com/services/S120030044}InstInfoType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "instInfo"
    })
    public static class InstInfoList {

        @XmlElement(name = "InstInfo")
        protected List<InstInfoType> instInfo;

        /**
         * Gets the value of the instInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the instInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getInstInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link InstInfoType }
         * 
         * 
         */
        public List<InstInfoType> getInstInfo() {
            if (instInfo == null) {
                instInfo = new ArrayList<InstInfoType>();
            }
            return this.instInfo;
        }

    }


    /**
     * 
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="OrgCpcInfo" type="{http://esb.spdbbiz.com/services/S120030044}OrgCpcInfoType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "orgCpcInfo"
    })
    public static class OrgCpcInfoList {

        @XmlElement(name = "OrgCpcInfo")
        protected List<OrgCpcInfoType> orgCpcInfo;

        /**
         * Gets the value of the orgCpcInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the orgCpcInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOrgCpcInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link OrgCpcInfoType }
         * 
         * 
         */
        public List<OrgCpcInfoType> getOrgCpcInfo() {
            if (orgCpcInfo == null) {
                orgCpcInfo = new ArrayList<OrgCpcInfoType>();
            }
            return this.orgCpcInfo;
        }

    }

}
