
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="UserCpcInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CoreUserFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CoreRlId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CoreCashLmt" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CoreTranLmt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserCpcInfoType", propOrder = {
    "coreUserFlag",
    "coreRlId",
    "coreCashLmt",
    "coreTranLmt"
})
public class UserCpcInfoType {

    @XmlElement(name = "CoreUserFlag")
    protected String coreUserFlag;
    @XmlElement(name = "CoreRlId")
    protected String coreRlId;
    @XmlElement(name = "CoreCashLmt")
    protected String coreCashLmt;
    @XmlElement(name = "CoreTranLmt")
    protected String coreTranLmt;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoreUserFlag() {
        return coreUserFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoreUserFlag(String value) {
        this.coreUserFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoreRlId() {
        return coreRlId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoreRlId(String value) {
        this.coreRlId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoreCashLmt() {
        return coreCashLmt;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoreCashLmt(String value) {
        this.coreCashLmt = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoreTranLmt() {
        return coreTranLmt;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoreTranLmt(String value) {
        this.coreTranLmt = value;
    }

}
