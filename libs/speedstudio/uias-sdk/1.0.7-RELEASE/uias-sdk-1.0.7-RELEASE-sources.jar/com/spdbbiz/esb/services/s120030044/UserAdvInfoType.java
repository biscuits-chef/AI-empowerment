
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="UserAdvInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}JobTitle" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}EmployeeNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TellerNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CompanyTel" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CompanyFaxNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}Mobile" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}PagerNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}Email" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}LangCode1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}Remark" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserAdvInfoType", propOrder = {
    "jobTitle",
    "employeeNo",
    "tellerNo",
    "companyTel",
    "companyFaxNo",
    "mobile",
    "pagerNo",
    "email",
    "langCode1",
    "remark"
})
public class UserAdvInfoType {

    @XmlElement(name = "JobTitle")
    protected String jobTitle;
    @XmlElement(name = "EmployeeNo")
    protected String employeeNo;
    @XmlElement(name = "TellerNo")
    protected String tellerNo;
    @XmlElement(name = "CompanyTel")
    protected String companyTel;
    @XmlElement(name = "CompanyFaxNo")
    protected String companyFaxNo;
    @XmlElement(name = "Mobile")
    protected String mobile;
    @XmlElement(name = "PagerNo")
    protected String pagerNo;
    @XmlElement(name = "Email")
    protected String email;
    @XmlElement(name = "LangCode1")
    protected String langCode1;
    @XmlElement(name = "Remark")
    protected String remark;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitle(String value) {
        this.jobTitle = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeNo() {
        return employeeNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeNo(String value) {
        this.employeeNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTellerNo() {
        return tellerNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTellerNo(String value) {
        this.tellerNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyTel() {
        return companyTel;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyTel(String value) {
        this.companyTel = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyFaxNo() {
        return companyFaxNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyFaxNo(String value) {
        this.companyFaxNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobile(String value) {
        this.mobile = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPagerNo() {
        return pagerNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPagerNo(String value) {
        this.pagerNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLangCode1() {
        return langCode1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLangCode1(String value) {
        this.langCode1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

}
