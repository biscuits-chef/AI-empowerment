
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="RspSvcHeaderType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranDate"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranTime"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BackendSeqNo"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BackendSysId"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ReturnCode"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ReturnMsg"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}GlobalSeqNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}LangCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}PIN" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}KeyVersionNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TargetAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SourceAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}MsgEndFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}MsgSeqNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}LinkTranCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranSerialNo" minOccurs="0"/>
 *         &lt;element name="SubSvcRetInfo" type="{http://esb.spdbbiz.com/services/S120030044}SubSvcRetInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RspSvcHeaderType", propOrder = {
    "tranDate",
    "tranTime",
    "backendSeqNo",
    "backendSysId",
    "returnCode",
    "returnMsg",
    "globalSeqNo",
    "langCode",
    "tranCode",
    "pin",
    "keyVersionNo",
    "targetAdr",
    "sourceAdr",
    "msgEndFlag",
    "msgSeqNo",
    "linkTranCode",
    "tranSerialNo",
    "subSvcRetInfo"
})
public class RspSvcHeaderType {

    @XmlElement(name = "TranDate", required = true)
    protected String tranDate;
    @XmlElement(name = "TranTime", required = true)
    protected String tranTime;
    @XmlElement(name = "BackendSeqNo", required = true)
    protected String backendSeqNo;
    @XmlElement(name = "BackendSysId", required = true)
    protected String backendSysId;
    @XmlElement(name = "ReturnCode", required = true)
    protected String returnCode;
    @XmlElement(name = "ReturnMsg", required = true)
    protected String returnMsg;
    @XmlElement(name = "GlobalSeqNo")
    protected String globalSeqNo;
    @XmlElement(name = "LangCode")
    protected String langCode;
    @XmlElement(name = "TranCode")
    protected String tranCode;
    @XmlElement(name = "PIN")
    protected String pin;
    @XmlElement(name = "KeyVersionNo")
    protected String keyVersionNo;
    @XmlElement(name = "TargetAdr")
    protected String targetAdr;
    @XmlElement(name = "SourceAdr")
    protected String sourceAdr;
    @XmlElement(name = "MsgEndFlag")
    protected String msgEndFlag;
    @XmlElement(name = "MsgSeqNo")
    protected String msgSeqNo;
    @XmlElement(name = "LinkTranCode")
    protected String linkTranCode;
    @XmlElement(name = "TranSerialNo")
    protected String tranSerialNo;
    @XmlElement(name = "SubSvcRetInfo")
    protected List<SubSvcRetInfoType> subSvcRetInfo;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranDate() {
        return tranDate;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranDate(String value) {
        this.tranDate = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranTime() {
        return tranTime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranTime(String value) {
        this.tranTime = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackendSeqNo() {
        return backendSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackendSeqNo(String value) {
        this.backendSeqNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackendSysId() {
        return backendSysId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackendSysId(String value) {
        this.backendSysId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnMsg() {
        return returnMsg;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnMsg(String value) {
        this.returnMsg = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlobalSeqNo() {
        return globalSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlobalSeqNo(String value) {
        this.globalSeqNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLangCode() {
        return langCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLangCode(String value) {
        this.langCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranCode() {
        return tranCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranCode(String value) {
        this.tranCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPIN() {
        return pin;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPIN(String value) {
        this.pin = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyVersionNo() {
        return keyVersionNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyVersionNo(String value) {
        this.keyVersionNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetAdr() {
        return targetAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetAdr(String value) {
        this.targetAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceAdr() {
        return sourceAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceAdr(String value) {
        this.sourceAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgEndFlag() {
        return msgEndFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgEndFlag(String value) {
        this.msgEndFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgSeqNo() {
        return msgSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgSeqNo(String value) {
        this.msgSeqNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinkTranCode() {
        return linkTranCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinkTranCode(String value) {
        this.linkTranCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranSerialNo() {
        return tranSerialNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranSerialNo(String value) {
        this.tranSerialNo = value;
    }

    /**
     * Gets the value of the subSvcRetInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subSvcRetInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubSvcRetInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubSvcRetInfoType }
     * 
     * 
     */
    public List<SubSvcRetInfoType> getSubSvcRetInfo() {
        if (subSvcRetInfo == null) {
            subSvcRetInfo = new ArrayList<SubSvcRetInfoType>();
        }
        return this.subSvcRetInfo;
    }

}
