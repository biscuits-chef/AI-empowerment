@javax.xml.bind.annotation.XmlSchema(namespace = "http://esb.spdbbiz.com/services/S120030044", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.spdbbiz.esb.services.s120030044;
