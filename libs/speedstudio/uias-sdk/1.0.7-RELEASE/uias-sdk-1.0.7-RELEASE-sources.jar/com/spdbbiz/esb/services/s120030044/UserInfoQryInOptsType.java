
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="UserInfoQryInOptsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetUserBscInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetUserAdvInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetUserCpcInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetInstInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetUserGrpInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetRoleInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetTaskInfoFlag"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RetFrontFuncInfoFlag"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserInfoQryInOptsType", propOrder = {
    "retUserBscInfoFlag",
    "retUserAdvInfoFlag",
    "retUserCpcInfoFlag",
    "retInstInfoFlag",
    "retUserGrpInfoFlag",
    "retRoleInfoFlag",
    "retTaskInfoFlag",
    "retFrontFuncInfoFlag"
})
public class UserInfoQryInOptsType {

    @XmlElement(name = "RetUserBscInfoFlag", required = true)
    protected String retUserBscInfoFlag;
    @XmlElement(name = "RetUserAdvInfoFlag", required = true)
    protected String retUserAdvInfoFlag;
    @XmlElement(name = "RetUserCpcInfoFlag", required = true)
    protected String retUserCpcInfoFlag;
    @XmlElement(name = "RetInstInfoFlag", required = true)
    protected String retInstInfoFlag;
    @XmlElement(name = "RetUserGrpInfoFlag", required = true)
    protected String retUserGrpInfoFlag;
    @XmlElement(name = "RetRoleInfoFlag", required = true)
    protected String retRoleInfoFlag;
    @XmlElement(name = "RetTaskInfoFlag", required = true)
    protected String retTaskInfoFlag;
    @XmlElement(name = "RetFrontFuncInfoFlag", required = true)
    protected String retFrontFuncInfoFlag;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetUserBscInfoFlag() {
        return retUserBscInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetUserBscInfoFlag(String value) {
        this.retUserBscInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetUserAdvInfoFlag() {
        return retUserAdvInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetUserAdvInfoFlag(String value) {
        this.retUserAdvInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetUserCpcInfoFlag() {
        return retUserCpcInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetUserCpcInfoFlag(String value) {
        this.retUserCpcInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetInstInfoFlag() {
        return retInstInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetInstInfoFlag(String value) {
        this.retInstInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetUserGrpInfoFlag() {
        return retUserGrpInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetUserGrpInfoFlag(String value) {
        this.retUserGrpInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetRoleInfoFlag() {
        return retRoleInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetRoleInfoFlag(String value) {
        this.retRoleInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetTaskInfoFlag() {
        return retTaskInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetTaskInfoFlag(String value) {
        this.retTaskInfoFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetFrontFuncInfoFlag() {
        return retFrontFuncInfoFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetFrontFuncInfoFlag(String value) {
        this.retFrontFuncInfoFlag = value;
    }

}
