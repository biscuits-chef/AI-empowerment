
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>InstInfoType complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�����ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="InstInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstId1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstName" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstType" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BranchId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CountryCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}Remark" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TreeType" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RoleInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TaskInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}FrontFuncInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}HLevel" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstExnAttr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}UserExnAttr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ChildInsts" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ChildGrpList" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InstInfoType", propOrder = {
    "instId1",
    "instName",
    "instType",
    "branchId",
    "countryCode",
    "remark",
    "treeType",
    "roleInfo",
    "taskInfo",
    "frontFuncInfo",
    "hLevel",
    "instExnAttr",
    "userExnAttr",
    "childInsts",
    "childGrpList"
})
public class InstInfoType {

    @XmlElement(name = "InstId1")
    protected String instId1;
    @XmlElement(name = "InstName")
    protected String instName;
    @XmlElement(name = "InstType")
    protected String instType;
    @XmlElement(name = "BranchId")
    protected String branchId;
    @XmlElement(name = "CountryCode")
    protected String countryCode;
    @XmlElement(name = "Remark")
    protected String remark;
    @XmlElement(name = "TreeType")
    protected String treeType;
    @XmlElement(name = "RoleInfo")
    protected List<RoleInfoType> roleInfo;
    @XmlElement(name = "TaskInfo")
    protected List<TaskInfoType> taskInfo;
    @XmlElement(name = "FrontFuncInfo")
    protected List<FrontFuncInfoType> frontFuncInfo;
    @XmlElement(name = "HLevel")
    protected String hLevel;
    @XmlElement(name = "InstExnAttr")
    protected String instExnAttr;
    @XmlElement(name = "UserExnAttr")
    protected String userExnAttr;
    @XmlElement(name = "ChildInsts")
    protected List<InstInfoType> childInsts;
    @XmlElement(name = "ChildGrpList")
    protected List<GrpInfoType> childGrpList;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstId1() {
        return instId1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstId1(String value) {
        this.instId1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstName() {
        return instName;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstName(String value) {
        this.instName = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstType() {
        return instType;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstType(String value) {
        this.instType = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchId() {
        return branchId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchId(String value) {
        this.branchId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTreeType() {
        return treeType;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTreeType(String value) {
        this.treeType = value;
    }

    /**
     * Gets the value of the roleInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the roleInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRoleInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RoleInfoType }
     * 
     * 
     */
    public List<RoleInfoType> getRoleInfo() {
        if (roleInfo == null) {
            roleInfo = new ArrayList<RoleInfoType>();
        }
        return this.roleInfo;
    }

    /**
     * Gets the value of the taskInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taskInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaskInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaskInfoType }
     * 
     * 
     */
    public List<TaskInfoType> getTaskInfo() {
        if (taskInfo == null) {
            taskInfo = new ArrayList<TaskInfoType>();
        }
        return this.taskInfo;
    }

    /**
     * Gets the value of the frontFuncInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frontFuncInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrontFuncInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FrontFuncInfoType }
     * 
     * 
     */
    public List<FrontFuncInfoType> getFrontFuncInfo() {
        if (frontFuncInfo == null) {
            frontFuncInfo = new ArrayList<FrontFuncInfoType>();
        }
        return this.frontFuncInfo;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHLevel() {
        return hLevel;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHLevel(String value) {
        this.hLevel = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstExnAttr() {
        return instExnAttr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstExnAttr(String value) {
        this.instExnAttr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserExnAttr() {
        return userExnAttr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserExnAttr(String value) {
        this.userExnAttr = value;
    }

    /**
     * Gets the value of the childInsts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childInsts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChildInsts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InstInfoType }
     * 
     * 
     */
    public List<InstInfoType> getChildInsts() {
        if (childInsts == null) {
            childInsts = new ArrayList<InstInfoType>();
        }
        return this.childInsts;
    }

    /**
     * Gets the value of the childGrpList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childGrpList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChildGrpList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GrpInfoType }
     * 
     * 
     */
    public List<GrpInfoType> getChildGrpList() {
        if (childGrpList == null) {
            childGrpList = new ArrayList<GrpInfoType>();
        }
        return this.childGrpList;
    }

}
