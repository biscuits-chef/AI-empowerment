
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="FrontFuncInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}FuncId1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}FuncName" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}FuncTarget" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ExnTarget" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}Status" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ChildFrontFunc" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RoleId1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RoleRelTrgt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FrontFuncInfoType", propOrder = {
    "funcId1",
    "funcName",
    "funcTarget",
    "exnTarget",
    "status",
    "childFrontFunc",
    "roleId1",
    "roleRelTrgt"
})
public class FrontFuncInfoType {

    @XmlElement(name = "FuncId1")
    protected String funcId1;
    @XmlElement(name = "FuncName")
    protected String funcName;
    @XmlElement(name = "FuncTarget")
    protected String funcTarget;
    @XmlElement(name = "ExnTarget")
    protected String exnTarget;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "ChildFrontFunc")
    protected List<FrontFuncInfoType> childFrontFunc;
    @XmlElement(name = "RoleId1")
    protected String roleId1;
    @XmlElement(name = "RoleRelTrgt")
    protected String roleRelTrgt;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFuncId1() {
        return funcId1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFuncId1(String value) {
        this.funcId1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFuncName() {
        return funcName;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFuncName(String value) {
        this.funcName = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFuncTarget() {
        return funcTarget;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFuncTarget(String value) {
        this.funcTarget = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExnTarget() {
        return exnTarget;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExnTarget(String value) {
        this.exnTarget = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the childFrontFunc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childFrontFunc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChildFrontFunc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FrontFuncInfoType }
     * 
     * 
     */
    public List<FrontFuncInfoType> getChildFrontFunc() {
        if (childFrontFunc == null) {
            childFrontFunc = new ArrayList<FrontFuncInfoType>();
        }
        return this.childFrontFunc;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleId1() {
        return roleId1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleId1(String value) {
        this.roleId1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleRelTrgt() {
        return roleRelTrgt;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleRelTrgt(String value) {
        this.roleRelTrgt = value;
    }

}
