@javax.xml.bind.annotation.XmlSchema(namespace = "http://esb.spdbbiz.com/metadata", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.spdbbiz.esb.metadata;
