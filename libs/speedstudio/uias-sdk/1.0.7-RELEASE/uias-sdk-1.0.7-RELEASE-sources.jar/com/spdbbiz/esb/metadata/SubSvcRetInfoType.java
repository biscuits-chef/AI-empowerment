
package com.spdbbiz.esb.metadata;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>SubSvcRetInfoType complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="SubSvcRetInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/metadata}SubSvcSysId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/metadata}SubSvcId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/metadata}SubSvcRetCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/metadata}SubSvcRetMsg" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/metadata}RsrvContent" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubSvcRetInfoType", propOrder = {
    "subSvcSysId",
    "subSvcId",
    "subSvcRetCode",
    "subSvcRetMsg",
    "rsrvContent"
})
public class SubSvcRetInfoType {

    @XmlElement(name = "SubSvcSysId")
    protected String subSvcSysId;
    @XmlElement(name = "SubSvcId")
    protected String subSvcId;
    @XmlElement(name = "SubSvcRetCode")
    protected String subSvcRetCode;
    @XmlElement(name = "SubSvcRetMsg")
    protected String subSvcRetMsg;
    @XmlElement(name = "RsrvContent")
    protected String rsrvContent;

    /**
     * 获取subSvcSysId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcSysId() {
        return subSvcSysId;
    }

    /**
     * 设置subSvcSysId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcSysId(String value) {
        this.subSvcSysId = value;
    }

    /**
     * 获取subSvcId属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcId() {
        return subSvcId;
    }

    /**
     * 设置subSvcId属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcId(String value) {
        this.subSvcId = value;
    }

    /**
     * 获取subSvcRetCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcRetCode() {
        return subSvcRetCode;
    }

    /**
     * 设置subSvcRetCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcRetCode(String value) {
        this.subSvcRetCode = value;
    }

    /**
     * 获取subSvcRetMsg属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcRetMsg() {
        return subSvcRetMsg;
    }

    /**
     * 设置subSvcRetMsg属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcRetMsg(String value) {
        this.subSvcRetMsg = value;
    }

    /**
     * 获取rsrvContent属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsrvContent() {
        return rsrvContent;
    }

    /**
     * 设置rsrvContent属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsrvContent(String value) {
        this.rsrvContent = value;
    }

}
