
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="ReqSvcHeaderType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranDate"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranTime"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranTellerNo"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranSeqNo"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ConsumerId"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}GlobalSeqNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SourceSysId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BranchId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TerminalCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CityCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AuthrTellerNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AuthrPwd" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AuthrCardFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AuthrCardNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}LangCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}PIN" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}KeyVersionNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SysOffset1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SysOffset2" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TargetAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SourceAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}MsgEndFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}MsgSeqNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SubTranCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranMode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}TranSerialNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReqSvcHeaderType", propOrder = {
    "tranDate",
    "tranTime",
    "tranTellerNo",
    "tranSeqNo",
    "consumerId",
    "globalSeqNo",
    "sourceSysId",
    "branchId",
    "terminalCode",
    "cityCode",
    "authrTellerNo",
    "authrPwd",
    "authrCardFlag",
    "authrCardNo",
    "langCode",
    "tranCode",
    "pin",
    "keyVersionNo",
    "sysOffset1",
    "sysOffset2",
    "targetAdr",
    "sourceAdr",
    "msgEndFlag",
    "msgSeqNo",
    "subTranCode",
    "tranMode",
    "tranSerialNo"
})
public class ReqSvcHeaderType {

    @XmlElement(name = "TranDate", required = true)
    protected String tranDate;
    @XmlElement(name = "TranTime", required = true)
    protected String tranTime;
    @XmlElement(name = "TranTellerNo", required = true)
    protected String tranTellerNo;
    @XmlElement(name = "TranSeqNo", required = true)
    protected String tranSeqNo;
    @XmlElement(name = "ConsumerId", required = true)
    protected String consumerId;
    @XmlElement(name = "GlobalSeqNo")
    protected String globalSeqNo;
    @XmlElement(name = "SourceSysId")
    protected String sourceSysId;
    @XmlElement(name = "BranchId")
    protected String branchId;
    @XmlElement(name = "TerminalCode")
    protected String terminalCode;
    @XmlElement(name = "CityCode")
    protected String cityCode;
    @XmlElement(name = "AuthrTellerNo")
    protected String authrTellerNo;
    @XmlElement(name = "AuthrPwd")
    protected String authrPwd;
    @XmlElement(name = "AuthrCardFlag")
    protected String authrCardFlag;
    @XmlElement(name = "AuthrCardNo")
    protected String authrCardNo;
    @XmlElement(name = "LangCode")
    protected String langCode;
    @XmlElement(name = "TranCode")
    protected String tranCode;
    @XmlElement(name = "PIN")
    protected String pin;
    @XmlElement(name = "KeyVersionNo")
    protected String keyVersionNo;
    @XmlElement(name = "SysOffset1")
    protected String sysOffset1;
    @XmlElement(name = "SysOffset2")
    protected String sysOffset2;
    @XmlElement(name = "TargetAdr")
    protected String targetAdr;
    @XmlElement(name = "SourceAdr")
    protected String sourceAdr;
    @XmlElement(name = "MsgEndFlag")
    protected String msgEndFlag;
    @XmlElement(name = "MsgSeqNo")
    protected String msgSeqNo;
    @XmlElement(name = "SubTranCode")
    protected String subTranCode;
    @XmlElement(name = "TranMode")
    protected String tranMode;
    @XmlElement(name = "TranSerialNo")
    protected String tranSerialNo;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranDate() {
        return tranDate;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranDate(String value) {
        this.tranDate = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranTime() {
        return tranTime;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranTime(String value) {
        this.tranTime = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranTellerNo() {
        return tranTellerNo;
    }

    /**
     * ����tranTellerNo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranTellerNo(String value) {
        this.tranTellerNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranSeqNo() {
        return tranSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranSeqNo(String value) {
        this.tranSeqNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlobalSeqNo() {
        return globalSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlobalSeqNo(String value) {
        this.globalSeqNo = value;
    }

    /**
     * ��ȡsourceSysId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSysId() {
        return sourceSysId;
    }

    /**
     * ����sourceSysId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSysId(String value) {
        this.sourceSysId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchId() {
        return branchId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchId(String value) {
        this.branchId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalCode() {
        return terminalCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalCode(String value) {
        this.terminalCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityCode() {
        return cityCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityCode(String value) {
        this.cityCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthrTellerNo() {
        return authrTellerNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthrTellerNo(String value) {
        this.authrTellerNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthrPwd() {
        return authrPwd;
    }

    /**
     * ����authrPwd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthrPwd(String value) {
        this.authrPwd = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthrCardFlag() {
        return authrCardFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthrCardFlag(String value) {
        this.authrCardFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthrCardNo() {
        return authrCardNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthrCardNo(String value) {
        this.authrCardNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLangCode() {
        return langCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLangCode(String value) {
        this.langCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranCode() {
        return tranCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranCode(String value) {
        this.tranCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPIN() {
        return pin;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPIN(String value) {
        this.pin = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyVersionNo() {
        return keyVersionNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyVersionNo(String value) {
        this.keyVersionNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysOffset1() {
        return sysOffset1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysOffset1(String value) {
        this.sysOffset1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysOffset2() {
        return sysOffset2;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysOffset2(String value) {
        this.sysOffset2 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetAdr() {
        return targetAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetAdr(String value) {
        this.targetAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceAdr() {
        return sourceAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceAdr(String value) {
        this.sourceAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgEndFlag() {
        return msgEndFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgEndFlag(String value) {
        this.msgEndFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgSeqNo() {
        return msgSeqNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgSeqNo(String value) {
        this.msgSeqNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubTranCode() {
        return subTranCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubTranCode(String value) {
        this.subTranCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranMode() {
        return tranMode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranMode(String value) {
        this.tranMode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranSerialNo() {
        return tranSerialNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranSerialNo(String value) {
        this.tranSerialNo = value;
    }

}
