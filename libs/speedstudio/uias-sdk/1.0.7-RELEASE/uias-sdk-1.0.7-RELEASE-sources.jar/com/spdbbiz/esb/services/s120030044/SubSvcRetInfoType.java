
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="SubSvcRetInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SubSvcSysId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SubSvcId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SubSvcRetCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}SubSvcRetMsg" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}RsrvContent" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubSvcRetInfoType", propOrder = {
    "subSvcSysId",
    "subSvcId",
    "subSvcRetCode",
    "subSvcRetMsg",
    "rsrvContent"
})
public class SubSvcRetInfoType {

    @XmlElement(name = "SubSvcSysId")
    protected String subSvcSysId;
    @XmlElement(name = "SubSvcId")
    protected String subSvcId;
    @XmlElement(name = "SubSvcRetCode")
    protected String subSvcRetCode;
    @XmlElement(name = "SubSvcRetMsg")
    protected String subSvcRetMsg;
    @XmlElement(name = "RsrvContent")
    protected String rsrvContent;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcSysId() {
        return subSvcSysId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcSysId(String value) {
        this.subSvcSysId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcId() {
        return subSvcId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcId(String value) {
        this.subSvcId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcRetCode() {
        return subSvcRetCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcRetCode(String value) {
        this.subSvcRetCode = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubSvcRetMsg() {
        return subSvcRetMsg;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubSvcRetMsg(String value) {
        this.subSvcRetMsg = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRsrvContent() {
        return rsrvContent;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRsrvContent(String value) {
        this.rsrvContent = value;
    }

}
