
package com.spdbbiz.esb.services.s120030044;

import com.spdbbiz.esb.metadata.ReqHeaderType;
import com.spdbbiz.esb.metadata.RspHeaderType;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.spdbbiz.esb.services.s120030044 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CityExgInstId_QNAME = new QName("CityExgInstId");
    private final static QName _LinkTranCode_QNAME = new QName("LinkTranCode");
    private final static QName _InstName_QNAME = new QName("InstName");
    private final static QName _GroupName_QNAME = new QName("GroupName");
    private final static QName _RetUserBscInfoFlag_QNAME = new QName("RetUserBscInfoFlag");
    private final static QName _RetFrontFuncInfoFlag_QNAME = new QName("RetFrontFuncInfoFlag");
    private final static QName _ChildGrpList_QNAME = new QName("ChildGrpList");
    private final static QName _BackendSysId_QNAME = new QName("BackendSysId");
    private final static QName _InstType_QNAME = new QName("InstType");
    private final static QName _RsrvContent_QNAME = new QName("RsrvContent");
    private final static QName _TaskInfo_QNAME = new QName("TaskInfo");
    private final static QName _TranTime_QNAME = new QName("TranTime");
    private final static QName _LangCode1_QNAME = new QName("LangCode1");
    private final static QName _KeyVersionNo_QNAME = new QName("KeyVersionNo");
    private final static QName _FrontFuncInfo_QNAME = new QName("FrontFuncInfo");
    private final static QName _TranDate_QNAME = new QName("TranDate");
    private final static QName _AuthrCardFlag_QNAME = new QName("AuthrCardFlag");
    private final static QName _AvlDelegateFlag_QNAME = new QName("AvlDelegateFlag");
    private final static QName _AuthrTellerNo_QNAME = new QName("AuthrTellerNo");
    private final static QName _TaskCode_QNAME = new QName("TaskCode");
    private final static QName _ChildTasks_QNAME = new QName("ChildTasks");
    private final static QName _CompanyFaxNo_QNAME = new QName("CompanyFaxNo");
    private final static QName _FuncTarget_QNAME = new QName("FuncTarget");
    private final static QName _BsnInstAttr_QNAME = new QName("BsnInstAttr");
    private final static QName _RoleId1_QNAME = new QName("RoleId1");
    private final static QName _UserDomainName_QNAME = new QName("UserDomainName");
    private final static QName _MsgSeqNo_QNAME = new QName("MsgSeqNo");
    private final static QName _Mobile_QNAME = new QName("Mobile");
    private final static QName _SubSvcSysId_QNAME = new QName("SubSvcSysId");
    private final static QName _LangCode_QNAME = new QName("LangCode");
    private final static QName _CoreCashLmt_QNAME = new QName("CoreCashLmt");
    private final static QName _TranSeqNo_QNAME = new QName("TranSeqNo");
    private final static QName _CityCode_QNAME = new QName("CityCode");
    private final static QName _SubSvcRetCode_QNAME = new QName("SubSvcRetCode");
    private final static QName _RetInstInfoFlag_QNAME = new QName("RetInstInfoFlag");
    private final static QName _CoreTranLmt_QNAME = new QName("CoreTranLmt");
    private final static QName _Status_QNAME = new QName("Status");
    private final static QName _RoleName_QNAME = new QName("RoleName");
    private final static QName _ImageStmIPAdr_QNAME = new QName("ImageStmIPAdr");
    private final static QName _Remark_QNAME = new QName("Remark");
    private final static QName _JobTitle_QNAME = new QName("JobTitle");
    private final static QName _ReturnMsg_QNAME = new QName("ReturnMsg");
    private final static QName _ReturnCode_QNAME = new QName("ReturnCode");
    private final static QName _CoreUserFlag_QNAME = new QName("CoreUserFlag");
    private final static QName _SubSvcId_QNAME = new QName("SubSvcId");
    private final static QName _ChildFrontFunc_QNAME = new QName("ChildFrontFunc");
    private final static QName _ExnTarget_QNAME = new QName("ExnTarget");
    private final static QName _UserName_QNAME = new QName("UserName");
    private final static QName _RspHeader_QNAME = new QName("RspHeader");
    private final static QName _RetRoleInfoFlag_QNAME = new QName("RetRoleInfoFlag");
    private final static QName _CompanyTel_QNAME = new QName("CompanyTel");
    private final static QName _FuncId1_QNAME = new QName("FuncId1");
    private final static QName _SubSvcRetMsg_QNAME = new QName("SubSvcRetMsg");
    private final static QName _YYXTStmIPAdr_QNAME = new QName("YYXTStmIPAdr");
    private final static QName _ConsumerId_QNAME = new QName("ConsumerId");
    private final static QName _SysOffset1_QNAME = new QName("SysOffset1");
    private final static QName _RoleInfo_QNAME = new QName("RoleInfo");
    private final static QName _TranCode_QNAME = new QName("TranCode");
    private final static QName _SysOffset2_QNAME = new QName("SysOffset2");
    private final static QName _RspNewAuthrQuery_QNAME = new QName("RspNewAuthrQuery");
    private final static QName _SysUsedFlag_QNAME = new QName("SysUsedFlag");
    private final static QName _AvlBeDelegatedFlag_QNAME = new QName("AvlBeDelegatedFlag");
    private final static QName _ReqNewAuthrQuery_QNAME = new QName("ReqNewAuthrQuery");
    private final static QName _Email_QNAME = new QName("Email");
    private final static QName _TaskId1_QNAME = new QName("TaskId1");
    private final static QName _AreaCode_QNAME = new QName("AreaCode");
    private final static QName _FuncName_QNAME = new QName("FuncName");
    private final static QName _TargetAdr_QNAME = new QName("TargetAdr");
    private final static QName _AuthrPwd_QNAME = new QName("AuthrPwd");
    private final static QName _CoreRlId_QNAME = new QName("CoreRlId");
    private final static QName _EmployeeNo_QNAME = new QName("EmployeeNo");
    private final static QName _TerminalCode_QNAME = new QName("TerminalCode");
    private final static QName _TranTellerNo_QNAME = new QName("TranTellerNo");
    private final static QName _AppId_QNAME = new QName("AppId");
    private final static QName _BackendSeqNo_QNAME = new QName("BackendSeqNo");
    private final static QName _RetTaskInfoFlag_QNAME = new QName("RetTaskInfoFlag");
    private final static QName _RoleRelTrgt_QNAME = new QName("RoleRelTrgt");
    private final static QName _BsnInstCgy_QNAME = new QName("BsnInstCgy");
    private final static QName _RetUserCpcInfoFlag_QNAME = new QName("RetUserCpcInfoFlag");
    private final static QName _InstId1_QNAME = new QName("InstId1");
    private final static QName _BsnInstType_QNAME = new QName("BsnInstType");
    private final static QName _UserExnAttr_QNAME = new QName("UserExnAttr");
    private final static QName _ChildInsts_QNAME = new QName("ChildInsts");
    private final static QName _BranchId_QNAME = new QName("BranchId");
    private final static QName _TaskName_QNAME = new QName("TaskName");
    private final static QName _TranSerialNo_QNAME = new QName("TranSerialNo");
    private final static QName _UserId_QNAME = new QName("UserId");
    private final static QName _InstAdr_QNAME = new QName("InstAdr");
    private final static QName _SubTranCode_QNAME = new QName("SubTranCode");
    private final static QName _ReqHeader_QNAME = new QName("ReqHeader");
    private final static QName _AuthrCardNo_QNAME = new QName("AuthrCardNo");
    private final static QName _CNAPSBnkNo_QNAME = new QName("CNAPSBnkNo");
    private final static QName _TreeType_QNAME = new QName("TreeType");
    private final static QName _SourceAdr_QNAME = new QName("SourceAdr");
    private final static QName _TellerNo_QNAME = new QName("TellerNo");
    private final static QName _TranMode_QNAME = new QName("TranMode");
    private final static QName _InstExnAttr_QNAME = new QName("InstExnAttr");
    private final static QName _GlobalSeqNo_QNAME = new QName("GlobalSeqNo");
    private final static QName _RetUserGrpInfoFlag_QNAME = new QName("RetUserGrpInfoFlag");
    private final static QName _SourceSysId_QNAME = new QName("SourceSysId");
    private final static QName _GroupId_QNAME = new QName("GroupId");
    private final static QName _HLevel_QNAME = new QName("HLevel");
    private final static QName _RetUserAdvInfoFlag_QNAME = new QName("RetUserAdvInfoFlag");
    private final static QName _MsgEndFlag_QNAME = new QName("MsgEndFlag");
    private final static QName _PagerNo_QNAME = new QName("PagerNo");
    private final static QName _CountryCode_QNAME = new QName("CountryCode");
    private final static QName _PIN_QNAME = new QName("PIN");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.spdbbiz.esb.services.s120030044
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UserInfoQryRsltType }
     * 
     */
    public UserInfoQryRsltType createUserInfoQryRsltType() {
        return new UserInfoQryRsltType();
    }

    /**
     * Create an instance of {@link ReqNewAuthrQueryType }
     * 
     */
    public ReqNewAuthrQueryType createReqNewAuthrQueryType() {
        return new ReqNewAuthrQueryType();
    }

    /**
     * Create an instance of {@link RspNewAuthrQueryType }
     * 
     */
    public RspNewAuthrQueryType createRspNewAuthrQueryType() {
        return new RspNewAuthrQueryType();
    }

    /**
     * Create an instance of {@link RoleInfoType }
     * 
     */
    public RoleInfoType createRoleInfoType() {
        return new RoleInfoType();
    }

    /**
     * Create an instance of {@link InstInfoType }
     * 
     */
    public InstInfoType createInstInfoType() {
        return new InstInfoType();
    }

    /**
     * Create an instance of {@link FrontFuncInfoType }
     * 
     */
    public FrontFuncInfoType createFrontFuncInfoType() {
        return new FrontFuncInfoType();
    }

    /**
     * Create an instance of {@link TaskInfoType }
     * 
     */
    public TaskInfoType createTaskInfoType() {
        return new TaskInfoType();
    }

    /**
     * Create an instance of {@link GrpInfoType }
     * 
     */
    public GrpInfoType createGrpInfoType() {
        return new GrpInfoType();
    }

    /**
     * Create an instance of {@link UserInfoQryInArgsType }
     * 
     */
    public UserInfoQryInArgsType createUserInfoQryInArgsType() {
        return new UserInfoQryInArgsType();
    }

    /**
     * Create an instance of {@link UserInfoQryInOptsType }
     * 
     */
    public UserInfoQryInOptsType createUserInfoQryInOptsType() {
        return new UserInfoQryInOptsType();
    }

    /**
     * Create an instance of {@link UserCpcInfoType }
     * 
     */
    public UserCpcInfoType createUserCpcInfoType() {
        return new UserCpcInfoType();
    }

    /**
     * Create an instance of {@link UserAdvInfoType }
     * 
     */
    public UserAdvInfoType createUserAdvInfoType() {
        return new UserAdvInfoType();
    }

    /**
     * Create an instance of {@link RspSvcHeaderType }
     * 
     */
    public RspSvcHeaderType createRspSvcHeaderType() {
        return new RspSvcHeaderType();
    }

    /**
     * Create an instance of {@link SubSvcRetInfoType }
     * 
     */
    public SubSvcRetInfoType createSubSvcRetInfoType() {
        return new SubSvcRetInfoType();
    }

    /**
     * Create an instance of {@link ReqSvcHeaderType }
     * 
     */
    public ReqSvcHeaderType createReqSvcHeaderType() {
        return new ReqSvcHeaderType();
    }

    /**
     * Create an instance of {@link OrgCpcInfoType }
     * 
     */
    public OrgCpcInfoType createOrgCpcInfoType() {
        return new OrgCpcInfoType();
    }

    /**
     * Create an instance of {@link UserBscInfoType }
     * 
     */
    public UserBscInfoType createUserBscInfoType() {
        return new UserBscInfoType();
    }

    /**
     * Create an instance of {@link UserInfoQryRsltType.InstInfoList }
     * 
     */
    public UserInfoQryRsltType.InstInfoList createUserInfoQryRsltTypeInstInfoList() {
        return new UserInfoQryRsltType.InstInfoList();
    }

    /**
     * Create an instance of {@link UserInfoQryRsltType.GrpInfoList }
     * 
     */
    public UserInfoQryRsltType.GrpInfoList createUserInfoQryRsltTypeGrpInfoList() {
        return new UserInfoQryRsltType.GrpInfoList();
    }

    /**
     * Create an instance of {@link UserInfoQryRsltType.OrgCpcInfoList }
     * 
     */
    public UserInfoQryRsltType.OrgCpcInfoList createUserInfoQryRsltTypeOrgCpcInfoList() {
        return new UserInfoQryRsltType.OrgCpcInfoList();
    }

    /**
     * Create an instance of {@link ReqNewAuthrQueryType.SvcBody }
     * 
     */
    public ReqNewAuthrQueryType.SvcBody createReqNewAuthrQueryTypeSvcBody() {
        return new ReqNewAuthrQueryType.SvcBody();
    }

    /**
     * Create an instance of {@link RspNewAuthrQueryType.SvcBody }
     * 
     */
    public RspNewAuthrQueryType.SvcBody createRspNewAuthrQueryTypeSvcBody() {
        return new RspNewAuthrQueryType.SvcBody();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CityExgInstId")
    public JAXBElement<String> createCityExgInstId(String value) {
        return new JAXBElement<String>(_CityExgInstId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "LinkTranCode")
    public JAXBElement<String> createLinkTranCode(String value) {
        return new JAXBElement<String>(_LinkTranCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "InstName")
    public JAXBElement<String> createInstName(String value) {
        return new JAXBElement<String>(_InstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "GroupName")
    public JAXBElement<String> createGroupName(String value) {
        return new JAXBElement<String>(_GroupName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetUserBscInfoFlag")
    public JAXBElement<String> createRetUserBscInfoFlag(String value) {
        return new JAXBElement<String>(_RetUserBscInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetFrontFuncInfoFlag")
    public JAXBElement<String> createRetFrontFuncInfoFlag(String value) {
        return new JAXBElement<String>(_RetFrontFuncInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GrpInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ChildGrpList")
    public JAXBElement<GrpInfoType> createChildGrpList(GrpInfoType value) {
        return new JAXBElement<GrpInfoType>(_ChildGrpList_QNAME, GrpInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BackendSysId")
    public JAXBElement<String> createBackendSysId(String value) {
        return new JAXBElement<String>(_BackendSysId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "InstType")
    public JAXBElement<String> createInstType(String value) {
        return new JAXBElement<String>(_InstType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RsrvContent")
    public JAXBElement<String> createRsrvContent(String value) {
        return new JAXBElement<String>(_RsrvContent_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaskInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TaskInfo")
    public JAXBElement<TaskInfoType> createTaskInfo(TaskInfoType value) {
        return new JAXBElement<TaskInfoType>(_TaskInfo_QNAME, TaskInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranTime")
    public JAXBElement<String> createTranTime(String value) {
        return new JAXBElement<String>(_TranTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "LangCode1")
    public JAXBElement<String> createLangCode1(String value) {
        return new JAXBElement<String>(_LangCode1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "KeyVersionNo")
    public JAXBElement<String> createKeyVersionNo(String value) {
        return new JAXBElement<String>(_KeyVersionNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FrontFuncInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "FrontFuncInfo")
    public JAXBElement<FrontFuncInfoType> createFrontFuncInfo(FrontFuncInfoType value) {
        return new JAXBElement<FrontFuncInfoType>(_FrontFuncInfo_QNAME, FrontFuncInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranDate")
    public JAXBElement<String> createTranDate(String value) {
        return new JAXBElement<String>(_TranDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AuthrCardFlag")
    public JAXBElement<String> createAuthrCardFlag(String value) {
        return new JAXBElement<String>(_AuthrCardFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AvlDelegateFlag")
    public JAXBElement<String> createAvlDelegateFlag(String value) {
        return new JAXBElement<String>(_AvlDelegateFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AuthrTellerNo")
    public JAXBElement<String> createAuthrTellerNo(String value) {
        return new JAXBElement<String>(_AuthrTellerNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TaskCode")
    public JAXBElement<String> createTaskCode(String value) {
        return new JAXBElement<String>(_TaskCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaskInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ChildTasks")
    public JAXBElement<TaskInfoType> createChildTasks(TaskInfoType value) {
        return new JAXBElement<TaskInfoType>(_ChildTasks_QNAME, TaskInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CompanyFaxNo")
    public JAXBElement<String> createCompanyFaxNo(String value) {
        return new JAXBElement<String>(_CompanyFaxNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "FuncTarget")
    public JAXBElement<String> createFuncTarget(String value) {
        return new JAXBElement<String>(_FuncTarget_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BsnInstAttr")
    public JAXBElement<String> createBsnInstAttr(String value) {
        return new JAXBElement<String>(_BsnInstAttr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RoleId1")
    public JAXBElement<String> createRoleId1(String value) {
        return new JAXBElement<String>(_RoleId1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "UserDomainName")
    public JAXBElement<String> createUserDomainName(String value) {
        return new JAXBElement<String>(_UserDomainName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "MsgSeqNo")
    public JAXBElement<String> createMsgSeqNo(String value) {
        return new JAXBElement<String>(_MsgSeqNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "Mobile")
    public JAXBElement<String> createMobile(String value) {
        return new JAXBElement<String>(_Mobile_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SubSvcSysId")
    public JAXBElement<String> createSubSvcSysId(String value) {
        return new JAXBElement<String>(_SubSvcSysId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "LangCode")
    public JAXBElement<String> createLangCode(String value) {
        return new JAXBElement<String>(_LangCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CoreCashLmt")
    public JAXBElement<String> createCoreCashLmt(String value) {
        return new JAXBElement<String>(_CoreCashLmt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranSeqNo")
    public JAXBElement<String> createTranSeqNo(String value) {
        return new JAXBElement<String>(_TranSeqNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CityCode")
    public JAXBElement<String> createCityCode(String value) {
        return new JAXBElement<String>(_CityCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SubSvcRetCode")
    public JAXBElement<String> createSubSvcRetCode(String value) {
        return new JAXBElement<String>(_SubSvcRetCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetInstInfoFlag")
    public JAXBElement<String> createRetInstInfoFlag(String value) {
        return new JAXBElement<String>(_RetInstInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CoreTranLmt")
    public JAXBElement<String> createCoreTranLmt(String value) {
        return new JAXBElement<String>(_CoreTranLmt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "Status")
    public JAXBElement<String> createStatus(String value) {
        return new JAXBElement<String>(_Status_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RoleName")
    public JAXBElement<String> createRoleName(String value) {
        return new JAXBElement<String>(_RoleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ImageStmIPAdr")
    public JAXBElement<String> createImageStmIPAdr(String value) {
        return new JAXBElement<String>(_ImageStmIPAdr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "Remark")
    public JAXBElement<String> createRemark(String value) {
        return new JAXBElement<String>(_Remark_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "JobTitle")
    public JAXBElement<String> createJobTitle(String value) {
        return new JAXBElement<String>(_JobTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ReturnMsg")
    public JAXBElement<String> createReturnMsg(String value) {
        return new JAXBElement<String>(_ReturnMsg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ReturnCode")
    public JAXBElement<String> createReturnCode(String value) {
        return new JAXBElement<String>(_ReturnCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CoreUserFlag")
    public JAXBElement<String> createCoreUserFlag(String value) {
        return new JAXBElement<String>(_CoreUserFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SubSvcId")
    public JAXBElement<String> createSubSvcId(String value) {
        return new JAXBElement<String>(_SubSvcId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FrontFuncInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ChildFrontFunc")
    public JAXBElement<FrontFuncInfoType> createChildFrontFunc(FrontFuncInfoType value) {
        return new JAXBElement<FrontFuncInfoType>(_ChildFrontFunc_QNAME, FrontFuncInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ExnTarget")
    public JAXBElement<String> createExnTarget(String value) {
        return new JAXBElement<String>(_ExnTarget_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "UserName")
    public JAXBElement<String> createUserName(String value) {
        return new JAXBElement<String>(_UserName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RspHeaderType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RspHeader")
    public JAXBElement<RspHeaderType> createRspHeader(RspHeaderType value) {
        return new JAXBElement<RspHeaderType>(_RspHeader_QNAME, RspHeaderType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetRoleInfoFlag")
    public JAXBElement<String> createRetRoleInfoFlag(String value) {
        return new JAXBElement<String>(_RetRoleInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CompanyTel")
    public JAXBElement<String> createCompanyTel(String value) {
        return new JAXBElement<String>(_CompanyTel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "FuncId1")
    public JAXBElement<String> createFuncId1(String value) {
        return new JAXBElement<String>(_FuncId1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SubSvcRetMsg")
    public JAXBElement<String> createSubSvcRetMsg(String value) {
        return new JAXBElement<String>(_SubSvcRetMsg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "YYXTStmIPAdr")
    public JAXBElement<String> createYYXTStmIPAdr(String value) {
        return new JAXBElement<String>(_YYXTStmIPAdr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ConsumerId")
    public JAXBElement<String> createConsumerId(String value) {
        return new JAXBElement<String>(_ConsumerId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SysOffset1")
    public JAXBElement<String> createSysOffset1(String value) {
        return new JAXBElement<String>(_SysOffset1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RoleInfo")
    public JAXBElement<RoleInfoType> createRoleInfo(RoleInfoType value) {
        return new JAXBElement<RoleInfoType>(_RoleInfo_QNAME, RoleInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranCode")
    public JAXBElement<String> createTranCode(String value) {
        return new JAXBElement<String>(_TranCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SysOffset2")
    public JAXBElement<String> createSysOffset2(String value) {
        return new JAXBElement<String>(_SysOffset2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RspNewAuthrQueryType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RspNewAuthrQuery")
    public JAXBElement<RspNewAuthrQueryType> createRspNewAuthrQuery(RspNewAuthrQueryType value) {
        return new JAXBElement<RspNewAuthrQueryType>(_RspNewAuthrQuery_QNAME, RspNewAuthrQueryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SysUsedFlag")
    public JAXBElement<String> createSysUsedFlag(String value) {
        return new JAXBElement<String>(_SysUsedFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AvlBeDelegatedFlag")
    public JAXBElement<String> createAvlBeDelegatedFlag(String value) {
        return new JAXBElement<String>(_AvlBeDelegatedFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReqNewAuthrQueryType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ReqNewAuthrQuery")
    public JAXBElement<ReqNewAuthrQueryType> createReqNewAuthrQuery(ReqNewAuthrQueryType value) {
        return new JAXBElement<ReqNewAuthrQueryType>(_ReqNewAuthrQuery_QNAME, ReqNewAuthrQueryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "Email")
    public JAXBElement<String> createEmail(String value) {
        return new JAXBElement<String>(_Email_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TaskId1")
    public JAXBElement<String> createTaskId1(String value) {
        return new JAXBElement<String>(_TaskId1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AreaCode")
    public JAXBElement<String> createAreaCode(String value) {
        return new JAXBElement<String>(_AreaCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "FuncName")
    public JAXBElement<String> createFuncName(String value) {
        return new JAXBElement<String>(_FuncName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TargetAdr")
    public JAXBElement<String> createTargetAdr(String value) {
        return new JAXBElement<String>(_TargetAdr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AuthrPwd")
    public JAXBElement<String> createAuthrPwd(String value) {
        return new JAXBElement<String>(_AuthrPwd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CoreRlId")
    public JAXBElement<String> createCoreRlId(String value) {
        return new JAXBElement<String>(_CoreRlId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "EmployeeNo")
    public JAXBElement<String> createEmployeeNo(String value) {
        return new JAXBElement<String>(_EmployeeNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TerminalCode")
    public JAXBElement<String> createTerminalCode(String value) {
        return new JAXBElement<String>(_TerminalCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranTellerNo")
    public JAXBElement<String> createTranTellerNo(String value) {
        return new JAXBElement<String>(_TranTellerNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AppId")
    public JAXBElement<String> createAppId(String value) {
        return new JAXBElement<String>(_AppId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BackendSeqNo")
    public JAXBElement<String> createBackendSeqNo(String value) {
        return new JAXBElement<String>(_BackendSeqNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetTaskInfoFlag")
    public JAXBElement<String> createRetTaskInfoFlag(String value) {
        return new JAXBElement<String>(_RetTaskInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RoleRelTrgt")
    public JAXBElement<String> createRoleRelTrgt(String value) {
        return new JAXBElement<String>(_RoleRelTrgt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BsnInstCgy")
    public JAXBElement<String> createBsnInstCgy(String value) {
        return new JAXBElement<String>(_BsnInstCgy_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetUserCpcInfoFlag")
    public JAXBElement<String> createRetUserCpcInfoFlag(String value) {
        return new JAXBElement<String>(_RetUserCpcInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "InstId1")
    public JAXBElement<String> createInstId1(String value) {
        return new JAXBElement<String>(_InstId1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BsnInstType")
    public JAXBElement<String> createBsnInstType(String value) {
        return new JAXBElement<String>(_BsnInstType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "UserExnAttr")
    public JAXBElement<String> createUserExnAttr(String value) {
        return new JAXBElement<String>(_UserExnAttr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InstInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ChildInsts")
    public JAXBElement<InstInfoType> createChildInsts(InstInfoType value) {
        return new JAXBElement<InstInfoType>(_ChildInsts_QNAME, InstInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "BranchId")
    public JAXBElement<String> createBranchId(String value) {
        return new JAXBElement<String>(_BranchId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TaskName")
    public JAXBElement<String> createTaskName(String value) {
        return new JAXBElement<String>(_TaskName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranSerialNo")
    public JAXBElement<String> createTranSerialNo(String value) {
        return new JAXBElement<String>(_TranSerialNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "UserId")
    public JAXBElement<String> createUserId(String value) {
        return new JAXBElement<String>(_UserId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "InstAdr")
    public JAXBElement<String> createInstAdr(String value) {
        return new JAXBElement<String>(_InstAdr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SubTranCode")
    public JAXBElement<String> createSubTranCode(String value) {
        return new JAXBElement<String>(_SubTranCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReqHeaderType }{@code >}}
     * 
     */
    @XmlElementDecl(name = "ReqHeader")
    public JAXBElement<ReqHeaderType> createReqHeader(ReqHeaderType value) {
        return new JAXBElement<ReqHeaderType>(_ReqHeader_QNAME, ReqHeaderType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "AuthrCardNo")
    public JAXBElement<String> createAuthrCardNo(String value) {
        return new JAXBElement<String>(_AuthrCardNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CNAPSBnkNo")
    public JAXBElement<String> createCNAPSBnkNo(String value) {
        return new JAXBElement<String>(_CNAPSBnkNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TreeType")
    public JAXBElement<String> createTreeType(String value) {
        return new JAXBElement<String>(_TreeType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SourceAdr")
    public JAXBElement<String> createSourceAdr(String value) {
        return new JAXBElement<String>(_SourceAdr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TellerNo")
    public JAXBElement<String> createTellerNo(String value) {
        return new JAXBElement<String>(_TellerNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "TranMode")
    public JAXBElement<String> createTranMode(String value) {
        return new JAXBElement<String>(_TranMode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "InstExnAttr")
    public JAXBElement<String> createInstExnAttr(String value) {
        return new JAXBElement<String>(_InstExnAttr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "GlobalSeqNo")
    public JAXBElement<String> createGlobalSeqNo(String value) {
        return new JAXBElement<String>(_GlobalSeqNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetUserGrpInfoFlag")
    public JAXBElement<String> createRetUserGrpInfoFlag(String value) {
        return new JAXBElement<String>(_RetUserGrpInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "SourceSysId")
    public JAXBElement<String> createSourceSysId(String value) {
        return new JAXBElement<String>(_SourceSysId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "GroupId")
    public JAXBElement<String> createGroupId(String value) {
        return new JAXBElement<String>(_GroupId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "HLevel")
    public JAXBElement<String> createHLevel(String value) {
        return new JAXBElement<String>(_HLevel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "RetUserAdvInfoFlag")
    public JAXBElement<String> createRetUserAdvInfoFlag(String value) {
        return new JAXBElement<String>(_RetUserAdvInfoFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "MsgEndFlag")
    public JAXBElement<String> createMsgEndFlag(String value) {
        return new JAXBElement<String>(_MsgEndFlag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "PagerNo")
    public JAXBElement<String> createPagerNo(String value) {
        return new JAXBElement<String>(_PagerNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "CountryCode")
    public JAXBElement<String> createCountryCode(String value) {
        return new JAXBElement<String>(_CountryCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(name = "PIN")
    public JAXBElement<String> createPIN(String value) {
        return new JAXBElement<String>(_PIN_QNAME, String.class, null, value);
    }

}
