
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="UserInfoQryInArgsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}UserDomainName"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AppId"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserInfoQryInArgsType", propOrder = {
    "userDomainName",
    "appId"
})
public class UserInfoQryInArgsType {

    @XmlElement(name = "UserDomainName", required = true)
    protected String userDomainName;
    @XmlElement(name = "AppId", required = true)
    protected String appId;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserDomainName() {
        return userDomainName;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserDomainName(String value) {
        this.userDomainName = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppId() {
        return appId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppId(String value) {
        this.appId = value;
    }

}
