
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="ReqNewAuthrQueryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ReqSvcHeader" type="{http://esb.spdbbiz.com/services/S120030044}ReqSvcHeaderType"/>
 *         &lt;element name="SvcBody" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="UserInfoQryInArgs" type="{http://esb.spdbbiz.com/services/S120030044}UserInfoQryInArgsType" minOccurs="0"/>
 *                   &lt;element name="UserInfoQryInOpts" type="{http://esb.spdbbiz.com/services/S120030044}UserInfoQryInOptsType" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReqNewAuthrQueryType", propOrder = {
    "reqSvcHeader",
    "svcBody"
})
public class ReqNewAuthrQueryType {

    @XmlElement(name = "ReqSvcHeader", required = true)
    protected ReqSvcHeaderType reqSvcHeader;
    @XmlElement(name = "SvcBody")
    protected SvcBody svcBody;

    /**
     * 
     * @return
     *     possible object is
     *     {@link ReqSvcHeaderType }
     *     
     */
    public ReqSvcHeaderType getReqSvcHeader() {
        return reqSvcHeader;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link ReqSvcHeaderType }
     *     
     */
    public void setReqSvcHeader(ReqSvcHeaderType value) {
        this.reqSvcHeader = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link SvcBody }
     *     
     */
    public SvcBody getSvcBody() {
        return svcBody;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link SvcBody }
     *     
     */
    public void setSvcBody(SvcBody value) {
        this.svcBody = value;
    }


    /**
     * 
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="UserInfoQryInArgs" type="{http://esb.spdbbiz.com/services/S120030044}UserInfoQryInArgsType" minOccurs="0"/>
     *         &lt;element name="UserInfoQryInOpts" type="{http://esb.spdbbiz.com/services/S120030044}UserInfoQryInOptsType" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "userInfoQryInArgs",
        "userInfoQryInOpts"
    })
    public static class SvcBody {

        @XmlElement(name = "UserInfoQryInArgs")
        protected UserInfoQryInArgsType userInfoQryInArgs;
        @XmlElement(name = "UserInfoQryInOpts")
        protected UserInfoQryInOptsType userInfoQryInOpts;

        /**
         * 
         * @return
         *     possible object is
         *     {@link UserInfoQryInArgsType }
         *     
         */
        public UserInfoQryInArgsType getUserInfoQryInArgs() {
            return userInfoQryInArgs;
        }

        /**
         * 
         * @param value
         *     allowed object is
         *     {@link UserInfoQryInArgsType }
         *     
         */
        public void setUserInfoQryInArgs(UserInfoQryInArgsType value) {
            this.userInfoQryInArgs = value;
        }

        /**
         * 
         * @return
         *     possible object is
         *     {@link UserInfoQryInOptsType }
         *     
         */
        public UserInfoQryInOptsType getUserInfoQryInOpts() {
            return userInfoQryInOpts;
        }

        /**
         * 
         * @param value
         *     allowed object is
         *     {@link UserInfoQryInOptsType }
         *     
         */
        public void setUserInfoQryInOpts(UserInfoQryInOptsType value) {
            this.userInfoQryInOpts = value;
        }

    }

}
