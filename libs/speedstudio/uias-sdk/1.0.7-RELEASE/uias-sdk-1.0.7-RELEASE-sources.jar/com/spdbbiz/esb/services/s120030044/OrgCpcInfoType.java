
package com.spdbbiz.esb.services.s120030044;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 
 * <pre>
 * &lt;complexType name="OrgCpcInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstId1" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BsnInstType" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BsnInstAttr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}BsnInstCgy" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AreaCode" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AvlBeDelegatedFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}AvlDelegateFlag" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}InstAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CNAPSBnkNo" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}CityExgInstId" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}YYXTStmIPAdr" minOccurs="0"/>
 *         &lt;element ref="{http://esb.spdbbiz.com/services/S120030044}ImageStmIPAdr" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrgCpcInfoType", propOrder = {
    "instId1",
    "bsnInstType",
    "bsnInstAttr",
    "bsnInstCgy",
    "areaCode",
    "avlBeDelegatedFlag",
    "avlDelegateFlag",
    "instAdr",
    "cnapsBnkNo",
    "cityExgInstId",
    "yyxtStmIPAdr",
    "imageStmIPAdr"
})
public class OrgCpcInfoType {

    @XmlElement(name = "InstId1")
    protected String instId1;
    @XmlElement(name = "BsnInstType")
    protected String bsnInstType;
    @XmlElement(name = "BsnInstAttr")
    protected String bsnInstAttr;
    @XmlElement(name = "BsnInstCgy")
    protected String bsnInstCgy;
    @XmlElement(name = "AreaCode")
    protected String areaCode;
    @XmlElement(name = "AvlBeDelegatedFlag")
    protected String avlBeDelegatedFlag;
    @XmlElement(name = "AvlDelegateFlag")
    protected String avlDelegateFlag;
    @XmlElement(name = "InstAdr")
    protected String instAdr;
    @XmlElement(name = "CNAPSBnkNo")
    protected String cnapsBnkNo;
    @XmlElement(name = "CityExgInstId")
    protected String cityExgInstId;
    @XmlElement(name = "YYXTStmIPAdr")
    protected String yyxtStmIPAdr;
    @XmlElement(name = "ImageStmIPAdr")
    protected String imageStmIPAdr;

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstId1() {
        return instId1;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstId1(String value) {
        this.instId1 = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBsnInstType() {
        return bsnInstType;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBsnInstType(String value) {
        this.bsnInstType = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBsnInstAttr() {
        return bsnInstAttr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBsnInstAttr(String value) {
        this.bsnInstAttr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBsnInstCgy() {
        return bsnInstCgy;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBsnInstCgy(String value) {
        this.bsnInstCgy = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaCode() {
        return areaCode;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaCode(String value) {
        this.areaCode = value;
    }

    /**
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvlBeDelegatedFlag() {
        return avlBeDelegatedFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvlBeDelegatedFlag(String value) {
        this.avlBeDelegatedFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvlDelegateFlag() {
        return avlDelegateFlag;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvlDelegateFlag(String value) {
        this.avlDelegateFlag = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstAdr() {
        return instAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstAdr(String value) {
        this.instAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCNAPSBnkNo() {
        return cnapsBnkNo;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCNAPSBnkNo(String value) {
        this.cnapsBnkNo = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityExgInstId() {
        return cityExgInstId;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityExgInstId(String value) {
        this.cityExgInstId = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYYXTStmIPAdr() {
        return yyxtStmIPAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYYXTStmIPAdr(String value) {
        this.yyxtStmIPAdr = value;
    }

    /**
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImageStmIPAdr() {
        return imageStmIPAdr;
    }

    /**
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImageStmIPAdr(String value) {
        this.imageStmIPAdr = value;
    }

}
