package com.spdb.speedstudio.uias.authentication.utils;

public class AuthenticationUtils {
}
