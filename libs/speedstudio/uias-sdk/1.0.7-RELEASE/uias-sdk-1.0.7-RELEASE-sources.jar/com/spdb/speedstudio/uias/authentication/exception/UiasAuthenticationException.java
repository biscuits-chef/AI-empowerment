package com.spdb.speedstudio.uias.authentication.exception;

import java.io.Serializable;

public class UiasAuthenticationException extends RuntimeException implements Serializable {

    public UiasAuthenticationException() {
        super();
    }

    public UiasAuthenticationException(String message) {
        super(message);
    }

    public UiasAuthenticationException(Throwable cause) {
        super(cause);
    }

    public UiasAuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
