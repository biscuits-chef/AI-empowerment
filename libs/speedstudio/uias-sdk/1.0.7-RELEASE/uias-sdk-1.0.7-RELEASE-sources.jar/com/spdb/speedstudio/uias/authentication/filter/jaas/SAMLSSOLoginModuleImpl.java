package com.spdb.speedstudio.uias.authentication.filter.jaas;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import java.io.IOException;
import java.util.Map;


/**
 *
 */
public class SAMLSSOLoginModuleImpl implements LoginModule {

    /**
     * Callback handler to store between initialization and authentication.
     */
    private CallbackHandler callbackHandler;
    /**
     * Subject to store.
     */
    private Subject subject;

    /**
     * Login name.
     */
    private String login;

    /**
     * This implementation always return false.
     *
     * @see javax.security.auth.spi.LoginModule#abort()
     */
    @Override
    public boolean abort() throws LoginException {

        return false;
    }

    /**
     * This is where, should the entire authentication process succeeds,
     * principal would be set.
     *
     * @see javax.security.auth.spi.LoginModule#commit()
     */
    @Override
    public boolean commit() throws LoginException {

        try {

            PlainUserPrincipal user = new PlainUserPrincipal(login);
            PlainRolePrincipal role = new PlainRolePrincipal("SSORole");

            subject.getPrincipals().add(user);
            subject.getPrincipals().add(role);

            return true;

        } catch (Exception e) {

            throw new LoginException(e.getMessage());
        }
    }

    /**
     * This implementation ignores both state and options.
     *
     * @see javax.security.auth.spi.LoginModule#initialize(javax.security.auth.Subject,
     * javax.security.auth.callback.CallbackHandler, java.util.Map,
     * java.util.Map)
     */
    @Override
    public void initialize(Subject aSubject, CallbackHandler aCallbackHandler,
                           Map aSharedState, Map aOptions) {

        callbackHandler = aCallbackHandler;
        subject = aSubject;
    }

    /**
     * This method checks whether the name and the password are the same.
     *
     * @see javax.security.auth.spi.LoginModule#login()
     */
    @Override
    public boolean login() throws LoginException {

        Callback[] callbacks = getCallbacks();
        String userName = getUserName(callbacks);
        if (userName.length() < 0) {
            throw new LoginException("Authentication failed, 未获取到用户名信息!");
        }
        login = userName;

        return true;

    }

    private Callback[] getCallbacks() throws LoginException {
        if (callbackHandler == null) {
            throw new LoginException("callbackHandler is null");
        }
        Callback[] callbacks;

        callbacks = new Callback[1]; // need one for the user name

        // add in the user name callback
        callbacks[0] = new NameCallback("username: ");

        // Call the callback handler, who in turn, calls back to the
        // callback objects, handing them the user name and password.
        // These callback objects hold onto the user name and password.
        // The login module retrieves the user name and password from them later.
        try {
            callbackHandler.handle(callbacks);
        } catch (IOException | UnsupportedCallbackException e) {
            throw new LoginException(e.getMessage());
        }

        return callbacks;
    }

    private String getUserName(Callback[] callbacks) throws LoginException {
        String userName = ((NameCallback) callbacks[0]).getName();
        if (userName == null) {
            throw new LoginException("userName is null");
        }
        return userName;
    }

    /**
     * Clears subject from principal and credentials.
     *
     * @see javax.security.auth.spi.LoginModule#logout()
     */
    @Override
    public boolean logout() throws LoginException {

        try {

            PlainUserPrincipal user = new PlainUserPrincipal(login);
            PlainRolePrincipal role = new PlainRolePrincipal("SSORole");

            subject.getPrincipals().remove(user);
            subject.getPrincipals().remove(role);

            return true;

        } catch (Exception e) {

            throw new LoginException(e.getMessage());
        }
    }
}
