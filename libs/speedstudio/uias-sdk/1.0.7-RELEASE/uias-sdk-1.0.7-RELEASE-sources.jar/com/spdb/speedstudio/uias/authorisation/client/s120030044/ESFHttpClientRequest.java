package com.spdb.speedstudio.uias.authorisation.client.s120030044;

import com.spdb.esf.sdk.bean.SdkResponse;

import java.net.URI;

/**
 * esf请求封装
 */
public class ESFHttpClientRequest {

    private SdkResponse response;
    private URI uri;
    private String method;
    private int connectionTimeout;
    private int receiveTimeout;

    public ESFHttpClientRequest(URI requestUri, String method) {
        this.uri = requestUri;
        this.method = method;
    }

    public SdkResponse getResponse() {
        return response;
    }

    public void setResponse(SdkResponse response) {
        this.response = response;
    }

    public URI getUri() {
        return uri;
    }

    public void setConnectionTimeout(int timeout) {
        this.connectionTimeout = timeout;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setReceiveTimeout(int timeout) {
        this.receiveTimeout = timeout;
    }

    public int getReceiveTimeout() {
        return receiveTimeout;
    }

    public String getMethod() {
        return method;
    }
}
