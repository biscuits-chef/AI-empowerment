package com.spdb.speedstudio.uias.authorisation.client.s120030044;

import com.spdb.speedstudio.uias.authorisation.common.AuthConstant;
import com.spdb.speedstudio.uias.authorisation.config.properties.AuthorisationProperty;
import com.spdbbiz.esb.metadata.ReqHeaderType;
import com.spdbbiz.esb.metadata.RspHeaderType;
import com.spdbbiz.esb.services.s120030044.ReqNewAuthrQueryType;
import com.spdbbiz.esb.services.s120030044.RspNewAuthrQueryType;
import com.spdbbiz.esb.services.s120030044.wsdl.ESBServerPortType;
import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.message.Message;
import org.apache.cxf.transport.http.HTTPConduitFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 通过esf  sdk调用uias授权服务
 */
@Component
public class NewAuthrQueryClient_ESF {
    @Autowired
    private AuthorisationProperty authorisationProperty;
    private ESBServerPortType esbServerPortType;


    /**
     * 通过cxf调用
     * @param reqHeader
     * @param reqNewAuthrQuery
     * @return
     */
    public RspNewAuthrQueryType getUserInfoFromESF(ReqHeaderType reqHeader, ReqNewAuthrQueryType reqNewAuthrQuery) {
        JaxWsProxyFactoryBean factory = null;
        try {
            if (esbServerPortType == null) {
                factory = new JaxWsProxyFactoryBean();
                factory.setServiceClass(ESBServerPortType.class);
                Bus bus = BusFactory.newInstance().createBus();
                bus.getProperties().put(Message.SCHEMA_VALIDATION_ENABLED, false);
                bus.getProperties().put("soap.no.validate.parts", true);
                //扩展HTTPConduitFactory
                bus.setExtension(new NewESFHTTPConduitFactory(authorisationProperty), HTTPConduitFactory.class);
                factory.setBus(bus);
                factory.setServiceClass(ESBServerPortType.class);
                setLog(factory);// 日志
                factory.setProperties(propMap());// 属性设置
                factory.setAddress("http://127.0.0.1:7603/S120030044");// 这里的IP地址只做占位作用，没有实际用处，端口7603 SDK API需要用到
                esbServerPortType = (ESBServerPortType) factory.create();
            }
            /**
             * 响应头
             */
            javax.xml.ws.Holder<RspHeaderType> rspHeader = new javax.xml.ws.Holder<RspHeaderType>();

            // 调用服务对应的ServerPort
            RspNewAuthrQueryType returnInfo = esbServerPortType.newAuthrQuery(reqNewAuthrQuery,
                    reqHeader, rspHeader);
            return returnInfo;

        } catch (Exception e1) {
            e1.printStackTrace();
            return null;
        }

    }



    /**
     * JaxWsProxyFactoryBean 属性设置
     *
     * @return
     * @throws Exception
     */
    public Map<String, Object> propMap() throws Exception {
        Map<String, String> soapEvnMap = new HashMap<>();
        soapEvnMap.put(AuthConstant.ESB_D,
                AuthConstant.ESB_ADDR + AuthConstant.TAG_XG + AuthConstant.ESB_METADATA);
        soapEvnMap.put(AuthConstant.ESB_S,
                AuthConstant.ESB_ADDR + AuthConstant.TAG_SERVICE + AuthConstant.ESB_S120030044);
        Map<String, Object> propMap = new HashMap<>();
        propMap.put(AuthConstant.CXF_DOCUMENT, true);
//        propMap.put(ServiceConstant.CXF_ASYNC, ServiceConstant.CXF_ALWAYS);
        propMap.put(AuthConstant.CXF_SOAPMAP, soapEvnMap);
        return propMap;
    }

    /**
     * 报文输入输出日志
     *
     * @param jwf
     */
    public void setLog(JaxWsProxyFactoryBean jwf) {
        jwf.getInInterceptors().add(new LoggingInInterceptor());
        jwf.getOutInterceptors().add(new LoggingOutInterceptor());
    }

}
