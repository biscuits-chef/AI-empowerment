package com.spdb.speedstudio.uias.authentication.filter;

import com.spdb.speedstudio.uias.authentication.configuration.UIASAuthConfiguration;
import com.spdb.speedstudio.uias.authentication.exception.UiasAuthenticationException;
import com.spdb.speedstudio.uias.authentication.handler.SAMLSSOCallbackHandle;
import com.spdb.speedstudio.uias.authentication.service.impl.SamlAssertionConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * The type Saml auth filter.
 *
 * @author liyd
 * @version 1.2
 * @date 2023-08-22
 */
public final class SAMLAuthTomcatFilter implements Filter {
    private static final Logger LOGGER = LoggerFactory.getLogger(SAMLAuthTomcatFilter.class);

    private UIASAuthConfiguration configuration;

    private SamlAssertionConsumer consumer;

    /**
     * Instantiates a new Saml auth filter.
     */
    public SAMLAuthTomcatFilter() {
        super();
    }

    /*
     * (non-Javadoc)
     *
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    @Override
    public void init(FilterConfig config) {
        configuration = new UIASAuthConfiguration();
        configuration.setRedirectUrl(config.getInitParameter("redirectURL"));
        String _token_type = config.getInitParameter("token-type");
        if (_token_type != null && _token_type.length() != 0) {
            configuration.setTokenType(_token_type);
        }
        String _realm = config.getInitParameter("realm-name");
        if (_realm != null && _realm.length() != 0) {
            configuration.setRealm(_realm);
        }
        String _dcName = config.getInitParameter("dcName");
        if (_dcName != null && _dcName.length() != 0) {
            configuration.setDcName(_dcName);
        }
        String _cert_path = config.getInitParameter("cert_path");
        if (_cert_path != null && _cert_path.length() != 0) {
            configuration.setCertFile(_cert_path);
        }
        String _checkRecipient = config.getInitParameter("checkRecipient");
        if (_checkRecipient != null && _checkRecipient.equalsIgnoreCase("true")) {
            configuration.setCheckRecipient(true);
        }
        String _validationErrorpage = config.getInitParameter("validationErrorpage");
        if (_validationErrorpage != null && _validationErrorpage.length() != 0) {
            configuration.setValidationErrorPage(_validationErrorpage);
        }
        consumer = new SamlAssertionConsumer(configuration);
    }

    /*
     * (non-Javadoc)
     *
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String samlResponse;
        Object objParam = request.getSession(true).getAttribute("subject");

        if (objParam != null) {
            chain.doFilter(req, res);
            String uiasUserName = request.getSession(true).getAttribute("uiasUserName").toString();
            LOGGER.info("The session of subject " + uiasUserName + " already exists");
            return;
        }

        String token = request.getParameter(configuration.getTokenType());
        if (token == null) {
            String sOldUrl = request.getScheme() + "://";
            sOldUrl += request.getHeader("host");
            sOldUrl += request.getRequestURI();
            if (request.getQueryString() != null) {
                sOldUrl += "?" + request.getQueryString();
            }
            String redirectUrl = configuration.getRedirectUrl();
            String sRedirectUrl = redirectUrl.indexOf('?') != -1
                    ? redirectUrl + "&ssotarget=" + sOldUrl
                    : redirectUrl + "?ssotarget=" + sOldUrl;
            LOGGER.info("User not login , redirect user to " + sRedirectUrl);
            response.sendRedirect(response.encodeRedirectURL(sRedirectUrl));
        } else {
            if (!token.equals("")) {
                String validationErrorPage = configuration.getValidationErrorPage();
                //校验
                String userName = "";
                try {
                    userName = consumer.consume(request);
                } catch (UiasAuthenticationException e) {
                    if (!validationErrorPage.isEmpty()) {
                        showErrorPage(request, response, validationErrorPage);
                    }
                    throw new ServletException("GetIdentityName error :" + e.getMessage());
                }

                LoginContext loginContext = null;
                try {
                    loginContext = new LoginContext("jasslogin", new SAMLSSOCallbackHandle(userName));
                    loginContext.login();
                    System.out.println(userName + " login now");
                    Subject subject = loginContext.getSubject();
                    if (subject != null) {
                        request.getSession(true).setAttribute("subject", subject);
                        request.getSession(true).setAttribute("uiasUserName", userName);
                    }
                } catch (LoginException e) {
                    throw new ServletException(e);
                }
                chain.doFilter(request, response);
                LOGGER.info("[process:UIAS认证][message:用户{} UIAS认证 SAMLResponse安全校验成功]", userName);
            }
        }
    }

    /**
     *
     */
    private void showErrorPage(HttpServletRequest request, HttpServletResponse response, String pageName) {
        try {
            request.getRequestDispatcher(pageName).forward(request, response);
        } catch (IOException | ServletException e) {
            LOGGER.error("showErrorPage error :" + e.getMessage());
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see javax.servlet.Filter#destroy()
     */
    @Override
    public void destroy() {
    }

}
