package com.spdb.speedstudio.uias.authorisation.common;

import org.springframework.stereotype.Component;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * 
 *证书加载
 */
@Component("SSLManager")
public class SSLManager {
	//信任证书 new java.security.cert.X509Certificate[] {}
 	private TrustManager[] trustManagers = new TrustManager[] { 
 		new X509TrustManager() {
			@Override
			public void checkClientTrusted(
					java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
					String paramString)
					throws java.security.cert.CertificateException {
			}
			@Override
			public void checkServerTrusted(
					java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
					String paramString)
					throws java.security.cert.CertificateException {
			}
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[] {};
			}
 		}
 	};

	public TrustManager[] getTrustManagers() {
		return trustManagers;
	}
}
