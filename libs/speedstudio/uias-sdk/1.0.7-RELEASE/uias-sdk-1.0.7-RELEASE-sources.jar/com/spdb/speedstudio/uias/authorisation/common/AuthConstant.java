package com.spdb.speedstudio.uias.authorisation.common;

public class AuthConstant {
    /**
     * 符号集合
     */
    //:
    public final static String TAG_MH = ":";
    ///
    public final static String TAG_XG = "/";
    //urn
    public final static String TAG_URN = "urn";
    ///services/
    public final static String TAG_SERVICE = "/services/";
    /**
     * ESB
     */
    //D
    public final static String ESB_D = "d";
    //s
    public final static String ESB_S = "s";

    public final static String ESB_SOAP = "soap";

    public final static String ESB_SOAP_ADDR = "http://schemas.xmlsoap.org/soap/envelope/";

    public final static String ESB_XSD = "xsd";

    public final static String ESB_XSD_ADDR = "http://www.w3.org/2001/XMLSchema";

    public final static String ESB_SOAPENC = "soapenc";

    public final static String ESB_SOAPENC_ADDR = "http://schemas.xmlsoap.org/soap/encoding/";

    public final static String ESB_METADATA = "metadata";

    public final static String ESB_ADDR = "http://esb.spdbbiz.com";

    public final static String HTTPS_ESB_ADDR="https://esb.spdbbiz.com";

    public final static String ESB_PORT = "7701";

    public final static String HTTPS_ESB_PORT = "7443";

    public final static String ESB_S120020030 = "S120020030";

    public final static String ESB_S120020030_SERVICEMETHOD = "MsgSendSvc";

    public final static String ESB_S120030044 = "S120030044";

    public final static String ESB_S120030044_SERVICEMETHOD = "NewAuthrQuery";

    public final static String ESB_S120020030_PATH = "com.spdbbiz.esb.services.s120020030.wsdl.ESBServerPortType";

    public final static String ESB_S120030044_PATH = "com.spdbbiz.esb.services.s120030044.wsdl.ESBServerPortType";

    public final static String ESB_REQSVCHEADER = "ReqSvcHeader";

    /**
     * cxf配置
     */
    //
    public final static String CXF_DOCUMENT = "org.apache.cxf.stax.force-start-document";
    //是否异步
    public final static String CXF_ASYNC = "use.async.http.conduit";

    public final static String CXF_ALWAYS = "always";

    public final static String CXF_SOAPMAP = "soap.env.ns.map";
}
