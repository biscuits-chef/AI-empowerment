package com.spdb.speedstudio.uias.authorisation.client.s120030044;

import com.spdb.speedstudio.uias.authorisation.config.properties.AuthorisationProperty;
import org.apache.cxf.Bus;
import org.apache.cxf.service.model.EndpointInfo;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transport.http.HTTPConduitFactory;
import org.apache.cxf.transport.http.HTTPTransportFactory;
import org.apache.cxf.ws.addressing.EndpointReferenceType;

import java.io.IOException;

public class NewESFHTTPConduitFactory implements HTTPConduitFactory {
    private AuthorisationProperty authorisationProperty;

    public NewESFHTTPConduitFactory(AuthorisationProperty authorisationProperty) {
        this.authorisationProperty = authorisationProperty;
    }

    @Override
    public HTTPConduit createConduit(HTTPTransportFactory f, Bus b, EndpointInfo localInfo, EndpointReferenceType target) throws IOException {
        return new NewESFHTTPConduit(b, localInfo, target, authorisationProperty);
    }
}
