package com.spdb.speedstudio.uias.authorisation.client.s120030044;

import com.spdb.speedstudio.uias.authorisation.common.AuthConstant;
import com.spdb.speedstudio.uias.authorisation.common.SSLManager;
import com.spdb.speedstudio.uias.authorisation.config.properties.AuthorisationProperty;
import com.spdb.speedstudio.uias.authorisation.jaxwsfactory.NewJaxWsproxyBean;
import com.spdbbiz.esb.metadata.ReqHeaderType;
import com.spdbbiz.esb.metadata.RspHeaderType;
import com.spdbbiz.esb.services.s120030044.ReqNewAuthrQueryType;
import com.spdbbiz.esb.services.s120030044.RspNewAuthrQueryType;
import com.spdbbiz.esb.services.s120030044.wsdl.ESBServerPortType;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 每一个服务方法创建一个Client类，继承AbstractClient
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
@Component
public class NewAuthrQueryClient {

	@Autowired
	private AuthorisationProperty authorisationProperty;

	/**
	 * ESB调用接口，由CXF生成
	 */
	private ESBServerPortType esbServerPortType;

	@Autowired
	private NewJaxWsproxyBean newJaxWsproxyBean;

	@Autowired
	private SSLManager sSLManager;




	private static final Logger logger = LoggerFactory.getLogger(NewAuthrQueryClient.class);



	public RspNewAuthrQueryType doTran(ReqHeaderType reqHeader, ReqNewAuthrQueryType reqNewAuthrQuery) {

		// 建立响应头
		javax.xml.ws.Holder<RspHeaderType> rspHeader = new javax.xml.ws.Holder<RspHeaderType>();
		Map soapEvnMap = new HashMap();
		soapEvnMap.put(AuthConstant.ESB_D,
				AuthConstant.ESB_ADDR + AuthConstant.TAG_XG + AuthConstant.ESB_METADATA);
		soapEvnMap.put(AuthConstant.ESB_S,
				AuthConstant.ESB_ADDR + AuthConstant.TAG_SERVICE + AuthConstant.ESB_S120030044);
		JaxWsProxyFactoryBean jwf = null;
		try {
			jwf = newJaxWsproxyBean.createJaxWsbean(AuthConstant.ESB_S120030044_PATH, soapEvnMap);
		} catch (Exception e1) {
			logger.error("创建JaxWsProxyFactoryBean异常:{}",e1.getMessage());
			e1.printStackTrace();
			return null;
		}

		// String httpsFlag =
		// PropertiesUtil.getValue("bankAuthority-config.properties",
		// "HttpsFlag");
		String httpsFlag = authorisationProperty.getHttpsFlag();

		boolean https = false;
		if (httpsFlag != null) {
			https = httpsFlag.matches("true");
		}
		if (https) {
			logger.debug("通过https协议调用授权交易{}", AuthConstant.ESB_S120030044);
			jwf.setAddress(authorisationProperty.getESB_SERVER_ADDR() + AuthConstant.TAG_MH + AuthConstant.HTTPS_ESB_PORT
					+ AuthConstant.TAG_SERVICE + AuthConstant.ESB_S120030044);
			Object port = jwf.create();
			Client client = ClientProxy.getClient(port);
			HTTPConduit httpconduit = (HTTPConduit) client.getConduit();
			TLSClientParameters tlsclientparameters = httpconduit.getTlsClientParameters();
			if (tlsclientparameters == null) {
				tlsclientparameters = new TLSClientParameters();
			}
			tlsclientparameters.setSecureSocketProtocol(authorisationProperty.getProtocolFlag());
			tlsclientparameters.setDisableCNCheck(true);
			if (client != null) {
				HTTPClientPolicy policy = new HTTPClientPolicy();
				policy.setConnectionTimeout(Long.valueOf(authorisationProperty.getConnectionTimeout()));
				policy.setReceiveTimeout(Long.valueOf(authorisationProperty.getReceiveTimeout()));
				httpconduit.setClient(policy);
			}
			try {
				tlsclientparameters.setTrustManagers(sSLManager.getTrustManagers());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			httpconduit.setTlsClientParameters(tlsclientparameters);
			esbServerPortType = (ESBServerPortType) port;
		} else {
			logger.debug("通过http协议调用授权交易{}",AuthConstant.ESB_S120030044);
			jwf.setAddress(authorisationProperty.getESB_SERVER_ADDR() + AuthConstant.TAG_MH + AuthConstant.ESB_PORT
					+ AuthConstant.TAG_SERVICE + AuthConstant.ESB_S120030044);

			Object port = jwf.create();
			Client client = ClientProxy.getClient(port);
			if (client != null) {
				HTTPConduit httpconduit = (HTTPConduit) client.getConduit();
				HTTPClientPolicy policy = new HTTPClientPolicy();
				policy.setConnectionTimeout(Long.valueOf(authorisationProperty.getConnectionTimeout()));
				policy.setReceiveTimeout(Long.valueOf(authorisationProperty.getReceiveTimeout()));
				httpconduit.setClient(policy);
			}
			esbServerPortType = (ESBServerPortType) port;
		}

		// 调用服务对应的ServerPort
		RspNewAuthrQueryType rspNewAuthrQueryType = esbServerPortType.newAuthrQuery(reqNewAuthrQuery, reqHeader,
				rspHeader);
		if (rspNewAuthrQueryType != null) {
			logger.debug("授权交易{}调用成功,response为{}",AuthConstant.ESB_S120030044, rspNewAuthrQueryType);
			return rspNewAuthrQueryType;
		}
		return null;
	}

}