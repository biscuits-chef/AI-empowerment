package com.spdb.speedstudio.uias.authentication.entity;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.joda.time.DateTime;

import java.io.Serializable;

public class User implements Serializable {

    private final String nameid;
    private final String Onameid;
    private final String authenticationResponseIssuingEntityName;
    private final String authenticationAssertionIssuingEntityName;
    private final String authenticationResponseID;
    private final String authenticationAssertionID;
    private final DateTime authenticationResponseIssueInstant;
    private final DateTime authenticationAssertionIssueInstant;
    private final DateTime authenticationIssueInstant;

    public User(String nameid, String Onameid, String authenticationResponseIssuingEntityName,
                String authenticationAssertionIssuingEntityName,
                String authenticationResponseID,
                String authenticationAssertionID,
                DateTime authenticationResponseIssueInstant,
                DateTime authenticationAssertionIssueInstant,
                DateTime authenticationIssueInstant
    ) {
        super();
        this.nameid = nameid;
        this.Onameid = Onameid;
        this.authenticationResponseIssuingEntityName = authenticationResponseIssuingEntityName;
        this.authenticationAssertionIssuingEntityName = authenticationAssertionIssuingEntityName;
        this.authenticationResponseID = authenticationResponseID;
        this.authenticationAssertionID = authenticationAssertionID;
        this.authenticationResponseIssueInstant = authenticationResponseIssueInstant;
        this.authenticationAssertionIssueInstant = authenticationAssertionIssueInstant;
        this.authenticationIssueInstant = authenticationIssueInstant;

    }

    public String getAuthenticationResponseIssuingEntityName() {
        return authenticationResponseIssuingEntityName;
    }

    public String getAuthenticationAssertionIssuingEntityName() {
        return authenticationAssertionIssuingEntityName;
    }

    public DateTime getAuthenticationResponseIssueInstant() {
        return authenticationResponseIssueInstant;
    }

    public DateTime getAuthenticationAssertionIssueInstant() {
        return authenticationAssertionIssueInstant;
    }

    public DateTime getAuthenticationIssueInstant() {
        return authenticationIssueInstant;
    }

    public String getAuthenticationResponseID() {
        return authenticationResponseID;
    }

    public String getAuthenticationAssertionID() {
        return authenticationAssertionID;
    }

    public String getOnameId() {
        String id = Onameid;
        if (Onameid != null && Onameid.contains("@"))
            id = Onameid.split("@")[0];
        return id;
    }

    public String getBnameId() {
        String id = nameid;
        if (nameid != null && nameid.contains("@"))
            id = nameid.split("@")[0];
        return id;
    }

    /**
     * Returns true if this object's name is equal to the name of the passed in arg.
     */
    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }

        if (obj.getClass() != getClass()) {
            return false;
        }
        User rhs = (User) obj;
        return new EqualsBuilder()
                .append(nameid, rhs.nameid)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(517, 43).
                append(nameid).toHashCode();

    }

    @Override
    public String toString() {

        return new ToStringBuilder(this).
                append("nameid", nameid).
                append("Onameid", Onameid).
                append("authenticationResponseIssuingEntityName", authenticationResponseIssuingEntityName).
                append("authenticationAssertionIssuingEntityName", authenticationAssertionIssuingEntityName).
                append("authenticationResponseID", authenticationResponseID).
                append("authenticationAssertionID", authenticationAssertionID).
                append("authenticationResponseIssueInstant", authenticationResponseIssueInstant).
                append("authenticationAssertionIssueInstant", authenticationAssertionIssueInstant).
                append("authenticationIssueInstant", authenticationIssueInstant).
                toString();
    }

}
