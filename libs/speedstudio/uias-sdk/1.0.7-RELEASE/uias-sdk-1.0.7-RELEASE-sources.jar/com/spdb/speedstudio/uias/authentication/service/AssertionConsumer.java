package com.spdb.speedstudio.uias.authentication.service;

import com.spdb.speedstudio.uias.authentication.configuration.UIASAuthConfiguration;
import com.spdb.speedstudio.uias.authentication.entity.User;

import javax.naming.AuthenticationException;
import javax.servlet.http.HttpServletRequest;

/**
 * The interface Assertion consumer.
 * SAML报文断言消费者接口
 *
 * <p> 接口描述:
 * 用于 UIAS 认证完成后,对回调请求请求中的 SAML响应报文即 Assertions(断言)校验
 * </p>
 *
 * <p> 功能描述: </p>
 *  <ul>
 *       <li>
 *  		1.获取 SAML 响应报文
 *  			通常断言是通过 BASE64 编码后在回调请求中保存,参数为: SAMLResponse
 *  		</li>
 *  	    <li>
 *  		2.对报文内容进行校验
 *  			在接收到 SAML响应报文后,解析获取对应的 XMLObject
 *  			通过 OpenSaml 提供的校验套件进行字段校验
 *  			依据签名信息中指定的算法、使用签名信息中指定的 IDP 验签证书，对原文和签名值进行验证
 *  			通过对报文进行有效性检验(时效性/接收者)
 *  		</li>
 *       <li>
 *  		3.返回用户信息
 *  			最终返回用户名/用户信息
 *  	    </li>
 *  </ul>
 *
 * <p> 异常抛出:
 *         其中可能会在解析/校验过程中发生异常,产生 Throwable 对象抛出
 * 	       通过异常 Message 信息进行查看报错描述,也可以在异常堆栈中进行查看具体报错代码堆栈信息
 * </p>
 *
 * <p>
 * 相关配置:
 * 		配置项可参考: {@link UIASAuthConfiguration}
 * </p>
 *
 * <p>
 * 		默认框架实现可参考 {@link com.spdb.speedstudio.uias.authentication.service.impl.SamlAssertionConsumer}
 * 	</p>
 *
 * @author xxx
 * @version 1.0.0
 * @date 2023-08-17
 */
public interface AssertionConsumer {

    /**
     * Consume user.
     * 校验SAML报文,返回用户名信息
     *
     * @param samlResponse the str response SAML报文
     * @return the user	用户信息/用户名
     * @throws AuthenticationException 异常 Message 字段中可以看出异常信息描述
     */
    String consume(String samlResponse) throws AuthenticationException;

    /**
     * Consume user.
     * 从请求获取SAML响应报文,并校验SAML报文,返回用户名信息
     *
     * @param request UIAS回调请求
     * @return 用户名
     * @throws Exception 异常 Message 字段中可以看出异常信息描述
     */
    String consume(HttpServletRequest request) throws AuthenticationException;

    /**
     * Gets user info.
     * 校验SAML报文,返回用户信息
     *
     * @param samlResponse the saml response SAML响应报文
     * @return the user info	用户信息
     * @throws Exception 异常 Message 字段中可以看出异常信息描述
     */
    User getUserInfo(String samlResponse) throws AuthenticationException;

    /**
     * Gets user info.
     * 从请求获取SAML响应报文,并校验SAML报文,返回用户信息
     *
     * @param request the request UIAS回调请求
     * @return the user info	用户信息
     * @throws Exception 异常 Message 字段中可以看出异常信息描述
     */
    User getUserInfo(HttpServletRequest request) throws AuthenticationException;

    /**
     * 传递 UIAS 认证相关配置信息
     *
     * @param configuration
     */
    void setConfiguration(UIASAuthConfiguration configuration);
}
