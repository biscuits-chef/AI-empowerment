package com.spdb.speedstudio.uias.authentication.configuration;


/**
 * UIAS相关配置信息
 *
 * @author yuql3
 * @version 1.0.0
 * @date 2023-08-18
 */
public class UIASAuthConfiguration {
    /**
     * IDP公钥证书路径
     */
    private String certFile = "classpath:idp-2023.cer";
    /**
     * SAML请求参数
     */
    private String tokenType = "SAMLResponse";
    /**
     * 需要获取哪个域的账号名作为用户标识
     */
    private String dcName = "biz";
    /**
     * 作用域
     */
    private String realm = "myrealm";
    /**
     * 是否校验Recipient字段
     */
    private Boolean isCheckRecipient = true;
    /**
     * UIAS 重定向地址
     */
    private String redirectUrl = "";
    /**
     * 重定向地址,用于接收者校验
     */
    private String ssoTarget = "";
    /**
     * 登陆错误提示页面
     */
    private String validationErrorPage = "";

    public String getCertFile() {
        return certFile;
    }

    public void setCertFile(String certFile) {
        this.certFile = certFile;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getDcName() {
        return dcName;
    }

    public void setDcName(String dcName) {
        this.dcName = dcName;
    }

    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public Boolean getCheckRecipient() {
        return isCheckRecipient;
    }

    public void setCheckRecipient(Boolean checkRecipient) {
        isCheckRecipient = checkRecipient;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getSsoTarget() {
        return ssoTarget;
    }

    public void setSsoTarget(String ssoTarget) {
        this.ssoTarget = ssoTarget == null ? "" : ssoTarget;
    }

    public String getValidationErrorPage() {
        return validationErrorPage;
    }

    public void setValidationErrorPage(String validationErrorPage) {
        this.validationErrorPage = validationErrorPage;
    }
}
