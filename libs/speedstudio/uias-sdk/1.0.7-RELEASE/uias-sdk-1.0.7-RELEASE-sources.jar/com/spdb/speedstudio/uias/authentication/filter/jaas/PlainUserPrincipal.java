package com.spdb.speedstudio.uias.authentication.filter.jaas;

import java.io.Serializable;
import java.security.Principal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.User;
import org.apache.catalina.UserDatabase;

public class PlainUserPrincipal implements User, Serializable {

	private String username;
	private Set roles = new HashSet();

	public PlainUserPrincipal(String u) {
		this.username = u;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return username;
	}

	@Override
	public void addGroup(Group arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addRole(Role role) {
		roles.add(role);

	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return username;
	}

	@Override
	public Iterator getGroups() {

		return null;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator getRoles() {

		return roles.iterator();
	}

	@Override
	public UserDatabase getUserDatabase() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return username;
	}

	@Override
	public boolean isInGroup(Group arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isInRole(Role role) {

		if (1 == 1) {
			return true;
		}

		if (!roles.isEmpty()) {
			Iterator it = roles.iterator();
			while (it.hasNext()) {
				Role rol = (Role) it.next();
				if (rol.getName() != null
						&& rol.getName().equals(role.getName())) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public void removeGroup(Group arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeGroups() {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeRole(Role arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeRoles() {
		roles.clear();

	}

	@Override
	public void setFullName(String arg0) {
		setUsername(username);

	}

	@Override
	public void setPassword(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setUsername(String arg0) {
		this.username = arg0;

	}

}