package com.spdb.speedstudio.uias.authentication.filter.jaas;

import java.io.Serializable;

import java.security.Principal;

import org.apache.catalina.Role;
import org.apache.catalina.UserDatabase;

public class PlainRolePrincipal implements Role, Serializable {

	private String roleName;

	public PlainRolePrincipal(String name) {
		this.roleName = name;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return getRolename();
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return " some role";
	}

	@Override
	public String getRolename() {
		// TODO Auto-generated method stub
		return roleName;
	}

	@Override
	public UserDatabase getUserDatabase() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setDescription(String arg0) {

	}

	@Override
	public void setRolename(String arg0) {
		roleName = arg0;

	}

}