package com.spdb.speedstudio.uias.authentication.filter;

import com.spdb.speedstudio.uias.authentication.configuration.UIASAuthConfiguration;
import com.spdb.speedstudio.uias.authentication.service.AssertionConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.naming.AuthenticationException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * SpringSecurity 认证拦截器 UIAS实现
 * <p>
 *     <ul>
 *         <li>
 *             1.拦截UIAS回调请求
 *         </li>
 *         <li>
 *             2.校验 SAML 响应报文
 *         </li>
 *         <li>
 *              3.若认证成功，初始化 AuthenticationToken(认证载体):其中 principal 为用户名信息
 *                最终在在请求中设置标志位 ISAUTH_FLAG {@code request.setAttribute(ISAUTH_FLAG, true);}
 *         </li>
 *     </ul>
 * </p>
 *
 */
@SuppressWarnings("all")
public class SAMLAuthSpringSecurityFilter extends BasicAuthenticationFilter {
    private static final Logger logger = LoggerFactory.getLogger(SAMLAuthSpringSecurityFilter.class);

    private AssertionConsumer consumer;
    private UIASAuthConfiguration configuration;

    public static final String ISAUTH_FLAG = "__UIAS_AUTH";

    public SAMLAuthSpringSecurityFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        String certFileName = configuration.getCertFile();
        if (certFileName == null || certFileName.isEmpty()) {
            certFileName = "classpath:idp-2023.cer";
            logger.debug("config default certificate path:" + certFileName);
        }

        String requestToken = request.getParameter(configuration.getTokenType());

        if (requestToken != null) {
            String userName = null;
            userName = checkToken(requestToken);
            logger.debug("[process:UIAS认证][message:用户{} UIAS认证 SAMLResponse安全校验通过]", userName);
            if ((userName != null) && !"".equals(userName)) {
                Authentication authenticationed = new UsernamePasswordAuthenticationToken(userName, null, null);
                //认证成功，设置Authentication
                SecurityContextHolder.getContext().setAuthentication(authenticationed);
                logger.debug("[process:UIAS认证][message:UIAS用户{} 统一认证通过...]", userName);
                request.setAttribute(ISAUTH_FLAG, true);
                chain.doFilter(request, response);
            } else {
                chain.doFilter(request, response);
            }
        } else {
            chain.doFilter(request, response);
        }
    }


    /**
     * Check token string.
     * 校验 SAML 响应报文
     *
     * @param requestToken the request token
     * @return the string
     */
    public String checkToken(String requestToken) throws BadCredentialsException{
        try {
            String token = new String(Base64.getDecoder().decode(requestToken.getBytes(StandardCharsets.UTF_8)));
            return consumer.consume(token);
        } catch (Exception e) {
            logger.error("[process:UIAS认证][message:UIAS认证 SAMLResponse安全校验失败]", e);
            BadCredentialsException exception =
                    new BadCredentialsException("SAMLResponse校验失败");
            throw exception;
        }
    }

    public AssertionConsumer getConsumer() {
        return consumer;
    }

    public void setConsumer(AssertionConsumer consumer) {
        this.consumer = consumer;
    }

    public UIASAuthConfiguration getConfiguration() {
        return configuration;
    }

    public void setConfiguration(UIASAuthConfiguration configuration) {
        this.configuration = configuration;
    }
}
