package com.spdb.speedstudio.uias.authentication.saml.validate;

import com.spdb.speedstudio.uias.authentication.exception.UiasAuthenticationException;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.validation.ValidationException;
import org.opensaml.xml.validation.ValidatorSuite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.security.Key;
import java.security.KeyException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.List;

/**
 * SAML 校验套件
 * <p>
 * 包含 SAML 报文格式校验及证书验签
 * </p>
 *
 * @author yuql3
 * @version 1.0.0
 * @date 2023 -08-17
 */
public class SAML2ValidatorSuite {
    private static final Logger LOGGER = LoggerFactory.getLogger(SAML2ValidatorSuite.class);

    /**
     * Test that a formal URI expresses the same algorithm as a conventional
     * short name such as "DSA" or "RSA".
     * 加密方式判断 是否为DSA/RSA
     *
     * @param algUri  the alg uri
     * @param algName the alg name
     * @return the boolean
     */
    static boolean algEquals(String algUri, String algName) {
        return (algName.equalsIgnoreCase("DSA") && algUri
                .equalsIgnoreCase(SignatureMethod.DSA_SHA1))
                || (algName.equalsIgnoreCase("RSA") && algUri
                .equalsIgnoreCase("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"));
    }

    /**
     * Validate.
     * SAML 报文校验
     * 包含报文格式及字段校验 && 报文签名RSA验签
     *
     * @param samlResponse the saml response
     * @param path         the path
     * @throws ValidationException the validation exception
     */
    public void validate(Response samlResponse, String path) throws ValidationException {

        if (!samlResponse.isSigned()) {
            throw new ValidationException("Cannot find Signature element");
        }

        //获取相关校验套件
        ValidatorSuite schemaValidator = Configuration
                .getValidatorSuite("saml2-core-schema-validator");
        //报文字段格式校验
        schemaValidator.validate(samlResponse);
        //获取相关校验套件
        ValidatorSuite specValidator = Configuration
                .getValidatorSuite("saml2-core-spec-validator");
        //报文规范校验
        specValidator.validate(samlResponse);
        try {
            Document doc = asDOMDocument(samlResponse);
            Element target = doc.getDocumentElement();
            //报文验签
            verifySamlSignature(target, path);
        } catch (UiasAuthenticationException | ParserConfigurationException | MarshallingException e) {
            // TODO Auto-generated catch block
            LOGGER.error("SamlResponse报文校验失败: ", e);
            throw new ValidationException("Invalid SAML2ValidatorSuite validate :" + e.getMessage());
        }
    }

    /**
     * 解析 Response 对象,进行报文校验
     * @param object
     * @return
     * @throws ParserConfigurationException
     * @throws MarshallingException
     */
    public Document asDOMDocument(XMLObject object) throws ParserConfigurationException, MarshallingException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Marshaller out = Configuration.getMarshallerFactory().getMarshaller(object);
        out.marshall(object, document);
        return document;
    }

    /**
     * Verify saml signature.
     * SAML 验签
     *
     * @param target the target
     * @param path   the path
     * @throws UiasAuthenticationException the uias authentication exception
     */
    public void verifySamlSignature(Element target, String path) throws UiasAuthenticationException {
        try {
            String providerName = System.getProperty("jsr105Provider",
                    "org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI");
            XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM", (Provider) Class
                    .forName(providerName).newInstance());
            target.setIdAttribute("ID", true);
            //获取签名响应消息的证书
            NodeList nl = target.getElementsByTagNameNS(XMLSignature.XMLNS,
                    "Signature");
            if (nl.getLength() == 0) {
                throw new UiasAuthenticationException("Cannot find Signature element");
            }
            SAMLSignedObject sso = new SAMLSignedObject(path);
            if (sso.getCert() == null) {
                throw new UiasAuthenticationException("please check the certFile path!");
            }
            DOMValidateContext context = new DOMValidateContext(sso.getKey(),
                    nl.item(0));

            XMLSignature signature = factory.unmarshalXMLSignature(context);
            //证书验签
            if (!signature.validate(context)) {
                throw new UiasAuthenticationException("Signature is invalidate");
            }
        } catch (Exception e) {
            throw new UiasAuthenticationException("Signature is invalidate :" + e.getMessage());
        }

    }

    /**
     * KeySelector that can handle KeyValue and X509Data info.
     */
    private static class KeyValueKeySelector extends KeySelector {
        @Override
        public KeySelectorResult select(KeyInfo keyInfo,
                                        Purpose purpose, AlgorithmMethod method,
                                        XMLCryptoContext context) throws KeySelectorException {
            if (keyInfo == null) {
                throw new KeySelectorException("Null KeyInfo object!");
            }

            SignatureMethod sm = (SignatureMethod) method;
            List list = keyInfo.getContent();

            for (Object o : list) {
                XMLStructure xmlStructure = (XMLStructure) o;
                PublicKey pk = null;
                try {
                    if (xmlStructure instanceof KeyValue) {
                        pk = ((KeyValue) xmlStructure).getPublicKey();
                    } else if (xmlStructure instanceof X509Data) {
                        for (Object data : ((X509Data) xmlStructure)
                                .getContent()) {
                            if (data instanceof X509Certificate) {
                                pk = ((X509Certificate) data).getPublicKey();
                            }
                        }
                    }
                } catch (KeyException ke) {
                    throw new KeySelectorException(ke);
                }

                if (algEquals(sm.getAlgorithm(), pk.getAlgorithm())) {
                    return new SimpleKeySelectorResult(pk);
                }
            }

            throw new KeySelectorException("No KeyValue element found!");
        }
    }

    /**
     * Data structure returned by the key selector to the validation context.
     */
    private static class SimpleKeySelectorResult implements KeySelectorResult {
        private PublicKey pk;

        /**
         * Instantiates a new Simple key selector result.
         *
         * @param pk the pk
         */
        SimpleKeySelectorResult(PublicKey pk) {
            this.pk = pk;
        }

        @Override
        public Key getKey() {
            return pk;
        }
    }

}