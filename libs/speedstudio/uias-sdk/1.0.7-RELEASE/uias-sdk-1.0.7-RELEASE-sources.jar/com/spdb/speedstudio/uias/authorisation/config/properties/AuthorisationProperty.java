package com.spdb.speedstudio.uias.authorisation.config.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


@Configuration("AuthorisationProperty")
@PropertySource(
        name = "AuthorizationProperty",
        value = {"classpath:authorisation.properties"},
        encoding = "utf-8",
        ignoreResourceNotFound = true
)
public class AuthorisationProperty {

    /**
     * ESB服务IP地址
     */
    @Value("${uias.authority.ESB_SERVER_ADDR:http://esb.spdbbiz.com}")
    private String ESB_SERVER_ADDR = "http://esb.spdbbiz.com";

    /**
     * 授权交易，是否使用https,默认false
     */
    @Value("${uias.authority.HttpsFlag:false}")
    private String HttpsFlag = "false";
    /**
     * 协议类型
     */
    @Value("${uias.authority.ProtocolFlag:TLSv1.2}")
    private String ProtocolFlag = "TLSv1.2";
    /**
     * 连接超时
     */
    @Value("${uias.authority.ConnectionTimeout:60000}")
    private int ConnectionTimeout = 60000;
    /**
     * 接收超时
     */
    @Value("${uias.authority.ReceiveTimeout:60000}")
    private int ReceiveTimeout = 60000;

    /**
     * 是否通过esf调用
     */
    @Value("${uias.authority.byESF:true}")
    private boolean byESF = true;



    public String getESB_SERVER_ADDR() {
        return ESB_SERVER_ADDR;
    }

    public void setESB_SERVER_ADDR(String ESB_SERVER_ADDR) {
        this.ESB_SERVER_ADDR = ESB_SERVER_ADDR;
    }

    public String getHttpsFlag() {
        return HttpsFlag;
    }

    public void setHttpsFlag(String httpsFlag) {
        this.HttpsFlag = httpsFlag;
    }

    public String getProtocolFlag() {
        return ProtocolFlag;
    }

    public void setProtocolFlag(String protocolFlag) {
        this.ProtocolFlag = protocolFlag;
    }

    public int getConnectionTimeout() {
        return ConnectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.ConnectionTimeout = connectionTimeout;
    }

    public int getReceiveTimeout() {
        return ReceiveTimeout;
    }

    public void setReceiveTimeout(int receiveTimeout) {
        this.ReceiveTimeout = receiveTimeout;
    }

    public boolean isByESF() {
        return byESF;
    }

    public void setByESF(boolean byESF) {
        this.byESF = byESF;
    }


}
