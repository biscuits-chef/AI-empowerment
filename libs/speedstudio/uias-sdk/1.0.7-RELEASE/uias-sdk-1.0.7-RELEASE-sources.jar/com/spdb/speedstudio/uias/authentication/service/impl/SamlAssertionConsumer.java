package com.spdb.speedstudio.uias.authentication.service.impl;

import com.spdb.speedstudio.uias.authentication.configuration.UIASAuthConfiguration;
import com.spdb.speedstudio.uias.authentication.entity.User;
import com.spdb.speedstudio.uias.authentication.exception.UiasAuthenticationException;
import com.spdb.speedstudio.uias.authentication.saml.validate.SAML2ValidatorSuite;
import com.spdb.speedstudio.uias.authentication.service.AssertionConsumer;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.schema.XSAny;
import org.opensaml.xml.schema.XSString;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

/**
 * SAML 响应报文校验
 *
 * @author yuql3
 * @version 1.0.0
 * @date 2023 -08-17
 */
public class SamlAssertionConsumer implements AssertionConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(SamlAssertionConsumer.class);

    private UIASAuthConfiguration configuration;

    /**
     * Instantiates a new Saml assertion consumer.
     * 部分检验依赖配置相关信息
     *
     * @param configuration the configuration UIAS校验相关配置信息
     */
    public SamlAssertionConsumer(UIASAuthConfiguration configuration) {
        this.configuration = configuration;
    }

    @Override
    public String consume(String samlStr) throws UiasAuthenticationException {
        try {
            //获取 SAML 响应报文对象
            Response samlResponse = getSamlResponse(samlStr);
            //Assertions即断言，是安全信息的载体，
            // 通常由断言签发者(Issuer)、主体（Subject）、关于该主体的一组声明（Statements)以及声明生效的条件（Conditions）四部分构成
            //认证声明：Authentication Statements，用于描述主体在什么时间通过什么方式被认证通过。
            //属性声明：Attribute Statements ，用于描述主体的其它属性信息，比如主体的姓名、昵称、主体隶属的组织信息等。
            Assertion assertion = samlResponse.getAssertions().get(0);
            //SAML报文内容校验
            samlCheck(samlResponse, assertion);
            //获取用户名
            String oUser = getAttValue(assertion.getAttributeStatements(), "ouid");
            String bUser = assertion.getSubject().getNameID().getValue();
            return getIdentityName(bUser, oUser);
        } catch (UiasAuthenticationException | ValidationException ve) {
            LOGGER.error("Invalid SAML Response Message :", ve);
            throw new UiasAuthenticationException("Invalid SAML Response Message :" + ve.getMessage());
        }
    }

    @Override
    public String consume(HttpServletRequest request) throws UiasAuthenticationException {
        String requestToken = request.getParameter(configuration.getTokenType());
        if (configuration.getSsoTarget().isEmpty()) {
            configuration.setSsoTarget(request.getRequestURL().toString());
        }
        if (requestToken != null) {
            //报文转码
            return consume(new String(Base64.getDecoder().decode(requestToken.getBytes(StandardCharsets.UTF_8))));
        }
        return null;
    }

    @Override
    public User getUserInfo(String samlResponse) throws UiasAuthenticationException {
        try {
            Response response = getSamlResponse(samlResponse);
            Assertion assertion = response.getAssertions().get(0);
            AuthnStatement authnStatement = assertion.getAuthnStatements().get(0);

            samlCheck(response, assertion);

            String oUser = getAttValue(assertion.getAttributeStatements(), "ouid");
            User user = getUserInfo(assertion, response, oUser, authnStatement);
            return user;
        } catch (ValidationException ve) {
            LOGGER.error("Invalid SAML Response Message :", ve);
            throw new UiasAuthenticationException("Invalid SAML Response Message :" + ve.getMessage());
        }
    }

    @Override
    public User getUserInfo(HttpServletRequest request) throws UiasAuthenticationException {
        String requestToken = request.getParameter(configuration.getTokenType());
        if (configuration.getSsoTarget().isEmpty()) {
            configuration.setSsoTarget(request.getRequestURL().toString());
        }
        if (requestToken != null) {
            //报文转码
            return getUserInfo(new String(Base64.getDecoder().decode(requestToken.getBytes(StandardCharsets.UTF_8))));
        }
        return null;
    }

    @Override
    public void setConfiguration(UIASAuthConfiguration configuration) {
        this.configuration = configuration;
    }

    /**
     * 获取SAML响应报文 xml 对象
     *
     * @param samlResponse
     * @return
     */
    private Response getSamlResponse(String samlResponse) {
        Response response = null;
        try {
            //OpenSAML初始化
            DefaultBootstrap.bootstrap();
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setNamespaceAware(true);
            //防XML外部实体注入
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(samlResponse.getBytes(StandardCharsets.UTF_8)));
            response = (org.opensaml.saml2.core.Response) Configuration.getUnmarshallerFactory()
                    .getUnmarshaller(doc.getDocumentElement())
                    .unmarshall(doc.getDocumentElement());
        } catch (Exception e) {
            throw new UiasAuthenticationException("Invalid SAML Response Message :"
                    + e.getMessage());
        }
        return response;
    }

    /**
     * SAML 报文校验
     *
     * @param samlResponse
     * @param assertion
     * @throws ValidationException
     */
    private void samlCheck(Response samlResponse, Assertion assertion) throws ValidationException {
        //创建相关 SAML2ValidatorSuite
        SAML2ValidatorSuite validatorSuite = new SAML2ValidatorSuite();
        //报文校验(报文格式及验签)
        validatorSuite.validate(samlResponse, configuration.getCertFile());
        //校验报文响应状态是否为成功
        checkResponseStatus(samlResponse);
        //获取属性声明
        List<SubjectConfirmation> subjectConfirmations = assertion.getSubject().getSubjectConfirmations();
        SubjectConfirmationData subjectConfirmationData = subjectConfirmations.get(0).getSubjectConfirmationData();
        // 登陆时间校验
        checkLoginTime(subjectConfirmationData);
        // 接收者校验
        if (configuration.getCheckRecipient()) {
            checkRecipient(subjectConfirmationData, configuration.getSsoTarget());
        }
    }

    /**
     * SAML报文校验完成后,生成对应的 User 对象
     *
     * @param assertion
     * @param samlResponse
     * @param ouid
     * @param authnStatement
     * @return
     */
    private User getUserInfo(Assertion assertion, Response samlResponse, String ouid, AuthnStatement authnStatement) {
        return new User(assertion.getSubject().getNameID().getValue(), ouid,
                samlResponse.getIssuer().getValue(), assertion.getIssuer()
                .getValue(), samlResponse.getID(), assertion.getID(),
                samlResponse.getIssueInstant(), assertion.getIssueInstant(),
                authnStatement.getAuthnInstant());
    }


    /**
     * Gets att value.
     * 获取指定 attribute 值
     *
     * @param attributeStatements the attribute statements
     * @param attName             the att name
     * @return the att value
     */
    public String getAttValue(List<AttributeStatement> attributeStatements, String attName) {
        String returnVal = "";
        for (AttributeStatement attributeStatement : attributeStatements) {
            for (Attribute attribute : attributeStatement.getAttributes()) {
                if (attName.equalsIgnoreCase(attribute.getName())) {
                    returnVal = getAttValue(attribute);
                    return returnVal;
                }
            }
        }
        return returnVal;
    }

    /**
     * 获取 attribute Value
     *
     * @param attribute
     * @return
     */
    private String getAttValue(Attribute attribute) {
        List<XMLObject> values = attribute.getAttributeValues();
        if (values == null || values.isEmpty()) {
            return null;
        }
        XMLObject xmlValue = values.get(0);
        if (xmlValue != null) {
            if (xmlValue instanceof XSAny) {
                return ((XSAny) xmlValue).getTextContent();
            } else {
                XSString value = (XSString) values.get(0);
                return value.getValue();
            }
        } else {
            return null;
        }
    }

    /**
     * SAML 响应报文状态码校验
     *
     * @param samlResponse
     * @throws UiasAuthenticationException
     */
    private void checkResponseStatus(Response samlResponse) throws UiasAuthenticationException {
        if (StatusCode.SUCCESS_URI.equals(StringUtils.trim(samlResponse.getStatus().getStatusCode().getValue()))) {
            additionalValidationChecksOnSuccessfulResponse(samlResponse);
        } else {
            StringBuilder extraInformation = extractExtraInformation(samlResponse);
            throw new UiasAuthenticationException("Identity Provider has failed the authentication.");
        }
    }

    /**
     * 校验报文中相关字段是否都存在
     * 报文格式校验
     *
     * @param samlResponse
     * @throws UiasAuthenticationException
     */
    private void additionalValidationChecksOnSuccessfulResponse(Response samlResponse) throws UiasAuthenticationException {
        // saml validator suite does not check for assertions on successful
        // auths
        if (samlResponse.getAssertions().isEmpty()) {
            throw new UiasAuthenticationException("Successful Response did not contain any assertions");
        } else if (samlResponse.getAssertions().get(0).getAuthnStatements().isEmpty()) {
            // nor authnStatements
            throw new UiasAuthenticationException("Successful Response did not contain an assertions with an AuthnStatement");
        } else if (samlResponse.getAssertions().get(0).getAttributeStatements().isEmpty()) {
            // we require at attribute statements
            throw new UiasAuthenticationException("Successful Response did not contain an assertions with an AttributeStatements");
        } else if (samlResponse.getIssuer() == null) {
            // we will require an issuer
            //用于标识请求消息的实际签发者,通常情况下是URI格式
            throw new UiasAuthenticationException("Successful Response did not contain any Issuer");
        }
    }

    private StringBuilder extractExtraInformation(Response samlResponse) {
        StringBuilder extraInformation = new StringBuilder();
        if (samlResponse.getStatus().getStatusCode().getStatusCode() != null) {
            extraInformation.append(samlResponse.getStatus().getStatusCode().getStatusCode().getValue());
        }
        if (samlResponse.getStatus().getStatusMessage() != null) {
            if (extraInformation.length() > 0) {
                extraInformation.append("  -  ");
            }
            extraInformation.append(samlResponse.getStatus().getStatusMessage());
        }
        return extraInformation;
    }

    /**
     * Gets identity name.
     * 根据User对象获取用户名字段
     *
     * @param user the user
     * @return the identity name
     */
    public String getIdentityName(User user) {
        return getIdentityName(user.getOnameId(), user.getBnameId());
    }

    /**
     * Gets identity name.
     * 获取用户名信息,需要判断哪个域的账号名作为用户标识
     *
     * @param bUser the b user
     * @param oUser the o user
     * @return the identity name
     * @throws UiasAuthenticationException the uias authentication exception
     */
    public String getIdentityName(String bUser, String oUser) throws UiasAuthenticationException {
        try {
            String userName = "Empty";

            String dcName = configuration.getDcName();
            if (dcName.isEmpty()) {
                LOGGER.info("dcName is Null!");
                return userName;
            }
            if (dcName.equalsIgnoreCase("work")) {
                if (oUser == null || oUser.length() == 0) {
                    LOGGER.info("Ouid is not exist!");
                }
                userName = oUser;
            } else {
                if (bUser == null || bUser.length() == 0) {
                    LOGGER.info("Buid is not exist!");
                }
                userName = bUser;
            }
            return userName;
        } catch (UiasAuthenticationException ex) {
            LOGGER.error("Invalid GetIdentityName :", ex);
            throw new UiasAuthenticationException("Invalid GetIdentityName :" + ex.getMessage());
        }
    }

    /**
     * 判断登录时间是否在NotBefore与NotOnOrAfter之间
     * SAML 报文中 SubjectConfirmationData 会保存报文有效时间段
     * 校验当前时间是否在报文中对应时间段内
     *
     * @param subjectConfirmationData 认证声明
     * @throws UiasAuthenticationException 自定义校验异常信息
     */
    public void checkLoginTime(SubjectConfirmationData subjectConfirmationData) throws UiasAuthenticationException {
        DateTime notBefore = subjectConfirmationData.getNotBefore();
        DateTime notOnOrAfter = subjectConfirmationData.getNotOnOrAfter();
        DateTime now = DateTime.now();
        if (notBefore != null) {
            if (now.plusMinutes(5).isBefore(notBefore.getMillis())) {
                throw new UiasAuthenticationException(
                        "Invalid SAML Response Message : " + now.plusMinutes(5) + " is should not before " + notBefore);
            }
        }
        if (notOnOrAfter != null) {
            if (now.minusMinutes(5).isAfter(notOnOrAfter.getMillis())) {
                throw new UiasAuthenticationException(
                        "Invalid SAML Response Message : " + now.minusMinutes(5) + " is should not after " + notOnOrAfter);
            }
        }
    }

    /**
     * 接收者校验(Recipient)
     * 校验用户配置的回调地址(回调请求URL)是否与报文中的接收者地址相匹配
     *
     * @param subjectConfirmationData
     * @param ssoTarget
     * @throws UiasAuthenticationException
     */
    private void checkRecipient(SubjectConfirmationData subjectConfirmationData, String ssoTarget) throws UiasAuthenticationException {
        String recipient = subjectConfirmationData.getRecipient();
        if (!ssoTarget.contains(recipient)) {
            throw new UiasAuthenticationException(
                    "Invalid SAML Response Message : " + recipient +
                            " is illegal, should include by " + ssoTarget);
        }
    }

}
