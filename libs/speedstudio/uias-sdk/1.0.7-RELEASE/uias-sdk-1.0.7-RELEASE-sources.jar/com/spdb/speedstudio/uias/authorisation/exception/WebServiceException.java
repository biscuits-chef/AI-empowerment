package com.spdb.speedstudio.uias.authorisation.exception;

public class WebServiceException extends Exception {
    private static final long serialVersionUID = -2282764605091431187L;
    public String errorCode;
    public String errorMsg;

    public WebServiceException(String errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

}
