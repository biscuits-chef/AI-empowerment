package com.spdb.speedstudio.uias.authorisation.service;

import com.spdb.speedstudio.uias.authorisation.client.s120030044.NewAuthrQueryClient;
import com.spdb.speedstudio.uias.authorisation.client.s120030044.NewAuthrQueryClient_ESF;
import com.spdb.speedstudio.uias.authorisation.config.properties.AuthorisationProperty;
import com.spdb.speedstudio.uias.authorisation.exception.WebServiceException;
import com.spdbbiz.esb.metadata.ReqHeaderType;
import com.spdbbiz.esb.services.s120030044.ReqNewAuthrQueryType;
import com.spdbbiz.esb.services.s120030044.RspNewAuthrQueryType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
@DependsOn("AuthorisationProperty")
public class NewAuthrQueryService {

	@Autowired
    private NewAuthrQueryClient newAuthrQueryClient;

    @Autowired
    private NewAuthrQueryClient_ESF newAuthrQueryClient_esf;


    private AuthorisationProperty authorisationProperty;

    @Autowired
    public NewAuthrQueryService(AuthorisationProperty authorisationProperty) {
        this.authorisationProperty = authorisationProperty;
        String esbAddr = System.getenv("ESB_SERVER_ADDR");
        if (esbAddr != null && !(esbAddr.isEmpty())){
            authorisationProperty.setESB_SERVER_ADDR(esbAddr);
        }
    }



    /**
     * 调用授权交易
     * @param reqHeader
     * @param reqNewAuthrQuery
     * @return
     * @throws WebServiceException
     */
    public RspNewAuthrQueryType queryNewAuthrService(ReqHeaderType reqHeader, ReqNewAuthrQueryType reqNewAuthrQuery) {
        RspNewAuthrQueryType RspNewAuthrQuery = authorisationProperty.isByESF() ? newAuthrQueryClient_esf.getUserInfoFromESF(reqHeader, reqNewAuthrQuery) : newAuthrQueryClient.doTran(reqHeader, reqNewAuthrQuery);
        return RspNewAuthrQuery;
    }


}
