package com.spdb.speedstudio.uias.authentication.handler;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

/**
 * The type Saml SSO callback handle.
 *
 * @author yuql3
 * @version 1.0.0
 * @date 2023-08-22
 */
public class SAMLSSOCallbackHandle implements CallbackHandler {
    /**
     *
     */
    private String userName;


    /**
     * Instantiates a new Samlsso callback handle.
     *
     * @param user the user
     */
    public SAMLSSOCallbackHandle(String user) {
        // TODO Auto-generated constructor stub
        userName = user;
    }

    @Override
    public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
        // loop over the callbacks
        for (int i = 0; i < callbacks.length; i++) {
            Callback callback = callbacks[i];
            // we only handle NameCallbacks
            if (!(callback instanceof NameCallback)) {
                throw new UnsupportedCallbackException(callback,
                        "Unrecognized Callback");
            }

            // send the user name to the name callback:
            NameCallback nameCallback = (NameCallback) callback;
            nameCallback.setName(userName);
        }
    }
}
