package com.spdb.speedstudio.uias.authorisation.client.s120030044;

import com.spdb.esf.sdk.api.EndPointInvokerApi;
import com.spdb.esf.sdk.bean.SdkResponse;
import com.spdb.speedstudio.uias.authorisation.config.properties.AuthorisationProperty;
import org.apache.cxf.Bus;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.message.Message;
import org.apache.cxf.service.model.EndpointInfo;
import org.apache.cxf.transport.http.Address;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transport.https.HttpsURLConnectionInfo;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.addressing.EndpointReferenceType;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.io.*;
import java.net.URI;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.Map;

/**
 * 重写http通道
 */
public class NewESFHTTPConduit extends HTTPConduit {

    private AuthorisationProperty authorisationProperty;

    public NewESFHTTPConduit(Bus b, EndpointInfo ei, EndpointReferenceType t, AuthorisationProperty authorisationProperty) throws IOException {
        super(b, ei, t);
        this.authorisationProperty = authorisationProperty;
    }

    @Override
    protected void setupConnection(Message message, Address address, HTTPClientPolicy csPolicy) throws IOException {

        URI uri = address.getURI();
        int ctimeout = authorisationProperty.getConnectionTimeout();
        int rtimeout = authorisationProperty.getReceiveTimeout();

        // If the HTTP_REQUEST_METHOD is not set, the default is "POST".
        String httpRequestMethod = (String)message.get(Message.HTTP_REQUEST_METHOD);
        if (httpRequestMethod == null) {
            httpRequestMethod = "POST";
            message.put(Message.HTTP_REQUEST_METHOD, "POST");
        }

        final ESFHttpClientRequest request = new ESFHttpClientRequest(uri, httpRequestMethod);
        request.setConnectionTimeout(ctimeout);
        request.setReceiveTimeout(rtimeout);

        message.put(ESFHttpClientRequest.class, request);
    }


    @Override
    protected OutputStream createOutputStream(Message message, boolean needToCacheRequest, boolean isChunking, int chunkThreshold) throws IOException {
        ESFHttpClientRequest entity = message.get(ESFHttpClientRequest.class);
        return new InnerWrappedOutputStream(message,
                needToCacheRequest,
                isChunking,
                chunkThreshold,
                getConduitName(),
                entity.getUri()
        );
    }


    class InnerWrappedOutputStream extends WrappedOutputStream {

        final HTTPClientPolicy csPolicy;
        ESFHttpClientRequest entity;
        volatile ByteArrayInputStream bais;
        SdkResponse sdkResponse;

        protected InnerWrappedOutputStream(Message outMessage, boolean possibleRetransmit, boolean isChunking, int chunkThreshold, String conduitName, URI url) {
            super(outMessage, possibleRetransmit, isChunking, chunkThreshold, conduitName, url);
            csPolicy = getClient(outMessage);
            entity = outMessage.get(ESFHttpClientRequest.class);
        }

        @Override
        protected void setupWrappedStream() throws IOException {
            wrappedStream = new ByteArrayOutputStream();
        }

        protected TLSClientParameters findTLSClientParameters(Message outMessage) {
            TLSClientParameters clientParameters = outMessage.get(TLSClientParameters.class);
            if (clientParameters == null) {
                clientParameters = getTlsClientParameters();
            }
            if (clientParameters == null) {
                clientParameters = new TLSClientParameters();
            }
            return clientParameters;
        }

        @Override
        protected HttpsURLConnectionInfo getHttpsURLConnectionInfo() throws IOException {
            TLSClientParameters tlsClientParameters = findTLSClientParameters(outMessage);
            SSLSession session = tlsClientParameters.getSslContext().createSSLEngine().getSession();
            HostnameVerifier verifier = tlsClientParameters.getHostnameVerifier();

            if (!verifier.verify(url.getHost(), session)) {
                throw new IOException("Could not verify host " + url.getHost());
            }

            String method = (String)outMessage.get(Message.HTTP_REQUEST_METHOD);
            String cipherSuite = null;
            Certificate[] localCerts = null;
            Principal principal = null;
            Certificate[] serverCerts = null;
            Principal peer = null;
            if (session != null) {
                cipherSuite = session.getCipherSuite();
                localCerts = session.getLocalCertificates();
                principal = session.getLocalPrincipal();
                serverCerts = session.getPeerCertificates();
                peer = session.getPeerPrincipal();
            }

            return new HttpsURLConnectionInfo(url, method, cipherSuite, localCerts, principal, serverCerts, peer);
        }

        private void connect() {
            byte[] bytes = ((ByteArrayOutputStream) wrappedStream).toByteArray();
            Map<String, String> params = new HashMap<>();
            sdkResponse = EndPointInvokerApi.doInvoke(bytes,"post", params, "/S120030044", 7603, entity.getConnectionTimeout(), entity.getReceiveTimeout());
        }

        @Override
        protected void setProtocolHeaders() throws IOException {

        }

        @Override
        protected void setFixedLengthStreamingMode(int i) {

        }

        @Override
        protected int getResponseCode() throws IOException {
            connect();
            return sdkResponse.getCode();
        }

        @Override
        protected String getResponseMessage() throws IOException {
            return sdkResponse.getMsg();
        }

        @Override
        protected void updateResponseHeaders(Message inMessage) throws IOException {
            inMessage.put(Message.CONTENT_TYPE, "text/xml;charset=UTF-8");
        }

        @Override
        protected void handleResponseAsync() throws IOException {

        }

        @Override
        protected void closeInputStream() throws IOException {
            bais.close();
        }

        @Override
        protected boolean usingProxy() {
            return false;
        }

        @Override
        protected InputStream getInputStream() throws IOException {
            bais = new ByteArrayInputStream(sdkResponse.getRespData());
            return bais;
        }

        @Override
        protected InputStream getPartialResponse() throws IOException {
            bais = new ByteArrayInputStream(sdkResponse.getRespData());
            return bais;
        }

        @Override
        protected void setupNewConnection(String newURL) throws IOException {

        }

        // 转播 stream
        @Override
        protected void retransmitStream() throws IOException {
        }

        @Override
        protected void updateCookiesBeforeRetransmit() throws IOException {
        }

        @Override
        public void thresholdReached() throws IOException {

        }

    }
}
