package com.spdb.speedstudio.uias.authentication.filter;

import com.spdb.speedstudio.uias.authentication.configuration.UIASAuthConfiguration;
import com.spdb.speedstudio.uias.authentication.service.impl.SamlAssertionConsumer;
import org.apache.xml.security.utils.Base64;
import org.joda.time.DateTime;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.*;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import weblogic.servlet.security.ServletAuthentication;

import javax.security.auth.login.LoginException;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

/**
 * 类描述
 *
 * @author yuql3
 * @date 2023-08-24
 * @version 1.0.0
 */
public final class SAMLAuthWeblogicFilter implements Filter {
    private static final Logger LOGGER = LoggerFactory.getLogger(SAMLAuthWeblogicFilter.class);

    private UIASAuthConfiguration configuration;
    private SamlAssertionConsumer consumer;
    private int gapMinutes = 5;

    public SAMLAuthWeblogicFilter() {
        super();
    }


    @Override
    public void init(FilterConfig config) throws ServletException {
        configuration = new UIASAuthConfiguration();
        configuration.setRedirectUrl(config.getInitParameter("redirectURL"));
        String _token_type = config.getInitParameter("token-type");
        if (_token_type != null && _token_type.length() != 0) {
            configuration.setTokenType(_token_type);
        }
        String _realm = config.getInitParameter("realm-name");
        if (_realm != null && _realm.length() != 0) {
            configuration.setRealm(_realm);
        }
        String _dcName = config.getInitParameter("dcName");
        if (_dcName != null && _dcName.length() != 0) {
            configuration.setDcName(_dcName);
        }
        String _cert_path = config.getInitParameter("cert_path");
        if (_cert_path != null && _cert_path.length() != 0) {
            configuration.setCertFile(_cert_path);
        }
        String _checkRecipient = config.getInitParameter("checkRecipient");
        if (_checkRecipient != null && _checkRecipient.equalsIgnoreCase("true")) {
            configuration.setCheckRecipient(true);
        }
        String _validationErrorpage = config.getInitParameter("validationErrorpage");
        if (_validationErrorpage != null && _validationErrorpage.length() != 0) {
            configuration.setValidationErrorPage(_validationErrorpage);
        }
        consumer = new SamlAssertionConsumer(configuration);
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        System.out.println("doFilter start");
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        if (request.getRemoteUser() != null && request.getRemoteUser().isEmpty()) {
            chain.doFilter(req, res);
            return;
        }
        System.out.println("getRemoteUser is null or empty");

        String token = request.getParameter(configuration.getTokenType());
        if (token == null) {
            String sOldUrl = request.getScheme() + "://";
            sOldUrl += request.getHeader("host");
            sOldUrl += request.getRequestURI();
            if (request.getQueryString() != null) {
                sOldUrl += "?" + request.getQueryString();
            }
            String redirectURL = configuration.getRedirectUrl();
            String sRedirectUrl = redirectURL.indexOf('?') != -1 ?
                    redirectURL + "&ssotarget=" + sOldUrl : redirectURL + "?ssotarget=" + sOldUrl;
            System.out.println("User not login , redirect user to " + sRedirectUrl);
            response.sendRedirect(response.encodeRedirectURL(sRedirectUrl));
        } else {
            String validationErrorpage = configuration.getValidationErrorPage();
            try {
                SubjectConfirmationData data = getSubjectConfirmationData(token);
                checkLoginTime(data);
                if (configuration.getCheckRecipient()) {
                    checkRecipient(data, request.getRequestURL().toString());
                }
                HttpServletRequest wrappedRequest = wrapRequest(request, token);
                ServletAuthentication.assertIdentity(wrappedRequest, response, configuration.getRealm());
                request.getSession(true).setAttribute("uiasUserName", request.getRemoteUser());
                chain.doFilter(request, response);
            } catch (LoginException ex) {
                if (validationErrorpage.length() != 0) {
                    showErrorPage(request, response, validationErrorpage);
                }
                throw new ServletException(ex);
            } catch (Exception ve) {
                throw new ServletException(ve);
            }
        }
    }

    private void showErrorPage(HttpServletRequest request, HttpServletResponse response, String PageName) {
        try {
            request.getRequestDispatcher(PageName).forward(request, response);
        } catch (Exception e) {
            System.out.println("showErrorPage error " + e.getMessage());
        }
    }

    @Override
    public void destroy() {

    }

    private HttpServletRequest wrapRequest(HttpServletRequest request, String token) {
        final String mytoken = token;
        return new HttpServletRequestWrapper(request) {
            @Override
            public String getHeader(String name) {
                return (name.equalsIgnoreCase(configuration.getTokenType())) ? mytoken : super.getHeader(name);
            }

            @Override
            public Enumeration getHeaderNames() {
                if (mytoken != null)
                    return new MyEnumeration(super.getHeaderNames());
                else
                    return super.getHeaderNames();
            }
        };
    }

    private SubjectConfirmationData getSubjectConfirmationData(String token) throws LoginException {
        try {
            DefaultBootstrap.bootstrap();
            String decodedSAMLToken = new String(Base64.decode(token));
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(decodedSAMLToken.getBytes()));
            Configuration.getUnmarshallerFactory().getUnmarshaller(doc.getDocumentElement()).unmarshall(doc.getDocumentElement());
            Response samlResponse = (Response) Configuration.getUnmarshallerFactory().getUnmarshaller(doc.getDocumentElement()).unmarshall(doc.getDocumentElement());
            Assertion assertion = samlResponse.getAssertions().get(0);
            Subject subject = assertion.getSubject();
            List<SubjectConfirmation> subjectConfirmations = subject.getSubjectConfirmations();
            return subjectConfirmations.get(0).getSubjectConfirmationData();
        } catch (Exception ve) {
            ve.printStackTrace();
            throw new LoginException("getSubjectConfirmationData Error");
        }
    }

    ;

    // 判断登录时间是否在NotBefore与NotOnOrAfter之间
    private void checkLoginTime(SubjectConfirmationData subjectConfirmationData) throws Exception {
        DateTime notBefore = subjectConfirmationData.getNotBefore();
        DateTime notOnOrAfter = subjectConfirmationData.getNotOnOrAfter();
        DateTime now = DateTime.now();
        if (notBefore != null) {
            if (now.plusMinutes(gapMinutes).isBefore(notBefore.getMillis())) {
                throw new ValidationException("checkLoginTime error , Invalid SAML Response : NotBefore field " + notBefore + " is later than " + now.plusMinutes(gapMinutes));
            }
        }
        if (notOnOrAfter != null) {
            if (now.minusMinutes(gapMinutes).isAfter(notOnOrAfter.getMillis())) {
                throw new ValidationException("checkLoginTime error , Invalid SAML Response : NotOnOrAfter field " + notOnOrAfter + " is early than " + now.minusMinutes(gapMinutes));
            }
        }
    }

    private void checkRecipient(SubjectConfirmationData subjectConfirmationData, String ssoTarget) throws Exception {
        String recipient = subjectConfirmationData.getRecipient();
        if (ssoTarget == null) {
            throw new ValidationException("checkRecipient error , ssoTarget is null !");
        }
        if (!ssoTarget.contains(recipient)) {
            throw new ValidationException("checkRecipient error , Invalid SAML Response : " + recipient + " is illegal, should be included by " + ssoTarget);
        }
    }

    private static class MyEnumeration implements Enumeration {
        Enumeration enu;
        boolean nomore;

        public MyEnumeration(Enumeration enu) {
            this.enu = enu;
            this.nomore = false;
        }

        @Override
        public boolean hasMoreElements() {
            boolean hasMore = enu.hasMoreElements();
            return (hasMore == false && nomore == false) ?
                    nomore = true : hasMore;
        }

        @Override
        public Object nextElement() {
            if (nomore) return "SAMLResponse";
            return enu.nextElement();
        }
    }
}
