package com.spdb.speedstudio.uias.authorisation.jaxwsfactory;

import com.spdb.speedstudio.uias.authorisation.common.AuthConstant;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings({"rawtypes" , "unchecked"})
@Component
public class NewJaxWsproxyBean {

	
	public JaxWsProxyFactoryBean createJaxWsbean (String className, Map soapEvnMap) throws Exception {
            // 获取CXF生成的接口类
			Class clazz = Class
            		.forName(className);
            JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
            factory.setServiceClass(clazz);
            //日志
            factory.getInInterceptors().add(new LoggingInInterceptor());
            factory.getOutInterceptors().add(new LoggingOutInterceptor());
            // 属性设置
            Map propMap = new HashMap();
            propMap.put(AuthConstant.CXF_DOCUMENT, true);
//            propMap.put(ServiceConstant.CXF_ASYNC, ServiceConstant.CXF_ALWAYS);
            propMap.put(AuthConstant.CXF_SOAPMAP, soapEvnMap);
            factory.setProperties(propMap);
            return factory;
	}

}
