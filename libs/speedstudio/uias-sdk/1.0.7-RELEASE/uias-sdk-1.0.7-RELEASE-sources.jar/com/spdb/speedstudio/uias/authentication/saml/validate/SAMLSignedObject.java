package com.spdb.speedstudio.uias.authentication.saml.validate;

import com.spdb.speedstudio.uias.authentication.exception.UiasAuthenticationException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.Reference;
import org.apache.xml.security.signature.SignedInfo;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.opensaml.common.SAMLException;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.w3c.dom.Element;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class SAMLSignedObject implements Cloneable {
    private static final Logger logger = LoggerFactory.getLogger(SAMLSignedObject.class);
    private XMLSignature sig = null;
    private String responseId;
    private String certPath;

    public SAMLSignedObject(String path) {
        certPath = path;
    }

    public Object getNativeSignature() {
        return sig;
    }

    public void setId(String id) {
        responseId = id;
    }

    public Certificate getCert() throws UiasAuthenticationException {
        // cert_path="c:\\data\\idp.cer";
        Certificate cert;
        if (certPath.toLowerCase().startsWith("classpath:")) {
            String fileName = certPath.substring(certPath.toLowerCase().indexOf("classpath:") + "classpath:".length());
            try (InputStream fis = new ClassPathResource(fileName).getInputStream()) {
                return getCert(fis);
            } catch (IOException | CertificateException e) {
                throw new UiasAuthenticationException("证书加载失败:" + e.getMessage());
            }
        } else {
            try (InputStream fis = new FileInputStream(certPath)) {
                return getCert(fis);
            } catch (IOException | CertificateException e) {
                throw new UiasAuthenticationException("证书加载失败:" + e.getMessage());
            }

        }
    }

    private Certificate getCert(InputStream fis) throws CertificateException {
        CertificateFactory factory = CertificateFactory
                .getInstance("X.509");
        return factory.generateCertificate(fis);
    }

    public void verify(Element e) {
        try {
            verify(getCert(), e);
        } catch (UiasAuthenticationException ex) {
            logger.error("", ex);
        }

    }

    public void verify(Certificate cert, Element e) throws UiasAuthenticationException {
        if (e != null) {
            try {
                sig = new XMLSignature(e, "");
            } catch (XMLSecurityException ex) {
                throw new UiasAuthenticationException(
                        "SAMLSignedObject.fromDOM() detected an XML security exception: "
                                + ex.getMessage(), ex);
            }
        }
        verify(cert.getPublicKey());
    }

    public Key getKey() {
        try {
            return getCert().getPublicKey();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.error("", e);
        }
        return null;
    }

    /**
     * Verifies the signature using the keying material provided
     *
     * @param k A secret or public key to use in verifying the signature
     * @throws SAMLException Thrown if the signature is invalid or if an error occurs
     */
    public void verify(Key k) throws UiasAuthenticationException {
        try {
            // Validate the signature content by checking for specific
            // Transforms.
            boolean valid = false;
            SignedInfo si = sig.getSignedInfo();
            si.setId(responseId);
            if (si.getLength() == 1) {
                Reference ref = si.item(0);
                if (ref.getURI() == null || ref.getURI().equals("")
                        || ref.getURI().equals("#" + responseId)) {
                    Transforms trans = ref.getTransforms();
                    for (int i = 0; i < trans.getLength(); i++) {
                        if (trans
                                .item(i)
                                .getURI()
                                .equals(Transforms.TRANSFORM_ENVELOPED_SIGNATURE))
                            valid = true;
                        else if (!trans
                                .item(i)
                                .getURI()
                                .equals(Transforms.TRANSFORM_C14N_EXCL_OMIT_COMMENTS)) {
                            valid = false;
                            break;
                        }
                    }
                }
            }

            if (!valid)
                throw new UiasAuthenticationException(
                        "SAMLSignedObject.verify() detected an invalid signature profile");

            // If k is null, try and find a key inside the signature.
            if (k == null) {
                k = sig.getKeyInfo().getPublicKey();
            }

            if (!sig.checkSignatureValue(k))
                throw new UiasAuthenticationException(
                        "SAMLSignedObject.verify() failed to validate signature value");
            BasicX509Credential x509Credential = new BasicX509Credential();

            x509Credential.setEntityCertificate((X509Certificate) getCert());
            x509Credential.getEntityCertificateChain().add(
                    (X509Certificate) getCert());
            SignatureValidator signatureValidator = new SignatureValidator(
                    x509Credential);

            signatureValidator.validate((Signature) si);

        } catch (XMLSecurityException e) {
            throw new UiasAuthenticationException(
                    "SAMLSignedObject.verify() detected an XML security exception: "
                            + e.getMessage(), e);
        } catch (NoSuchMethodError e) {
            throw new UiasAuthenticationException(
                    "SAMLSignedObject.verify() java.lang.NoSuchMethodError: "
                            + e.getMessage(), e);
        } catch (Exception e) {
            throw new UiasAuthenticationException(
                    "SAMLSignedObject.verify() exception: "
                            + e.getMessage(), e);
        }
    }

}
